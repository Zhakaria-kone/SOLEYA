<?php
// app/Services/ReservationService.php

namespace App\Services;

use App\Models\Reservation;
use App\Models\Room;
use App\Models\Client;
use App\Models\Payment;
use App\Models\AuditLog;
use App\Helpers\Format;
use Exception;

class ReservationService
{
    private Reservation $reservationModel;
    private Room $roomModel;
    private Client $clientModel;
    private Payment $paymentModel;

    public function __construct()
    {
        $this->reservationModel = new Reservation();
        $this->roomModel = new Room();
        $this->clientModel = new Client();
        $this->paymentModel = new Payment();
    }

    public function create(array $data, array $user): array
    {
        $clientId = (int)($data['client_id'] ?? 0);
        $roomId = (int)($data['room_id'] ?? 0);
        $arrival = $data['arrival_date'] ?? '';
        $departure = $data['departure_date'] ?? '';
        $guests = max(1, (int)($data['guests'] ?? 1));
        $status = $data['status'] ?? 'CONFIRMEE';
        $notes = $data['notes'] ?? '';
        $discount = max(0, (int)($data['discount_amount'] ?? 0));
        $extra = max(0, (int)($data['extra_amount'] ?? 0));
        $deposit = max(0, (int)($data['deposit_amount'] ?? 0));

        if ($departure <= $arrival) {
            throw new Exception('La date de départ doit être strictement postérieure à la date d’arrivée.');
        }

        $client = $this->clientModel->find($clientId);
        if (!$client) {
            throw new Exception('Client introuvable.');
        }

        $room = $this->roomModel->find($roomId);
        if (!$room) {
            throw new Exception('Chambre introuvable.');
        }

        if ($guests > (int)$room['capacity']) {
            throw new Exception("La {$room['number']} accepte au maximum {$room['capacity']} personne(s).");
        }

        if ($room['status'] === 'MAINTENANCE' && in_array($status, ['CONFIRMEE', 'EN_COURS'])) {
            throw new Exception("La {$room['number']} est actuellement en maintenance et indisponible.");
        }

        // Vérification anti-chevauchement
        if (in_array($status, ['CONFIRMEE', 'EN_COURS'])) {
            $conflict = $this->reservationModel->checkOverlap($roomId, $arrival, $departure);
            if ($conflict) {
                throw new Exception("Double réservation bloquée : la {$room['number']} est déjà réservée du " . Format::date($conflict['arrival_date']) . " au " . Format::date($conflict['departure_date']) . " pour {$conflict['first_name']} {$conflict['last_name']}.");
            }
        }

        $nights = Format::diffDays($arrival, $departure);
        // Tarif appliqué : utilise celui fourni s'il est spécifié, sinon le tarif journalier actuel de la chambre
        $rate = isset($data['rate_applied']) && (int)$data['rate_applied'] > 0 ? (int)$data['rate_applied'] : (int)$room['daily_rate'];
        $total = ($nights * $rate) + $extra - $discount;

        $resId = $this->reservationModel->create([
            'client_id' => $clientId,
            'room_id' => $roomId,
            'arrival_date' => $arrival,
            'departure_date' => $departure,
            'guests' => $guests,
            'rate_applied' => $rate,
            'nights' => $nights,
            'discount_amount' => $discount,
            'extra_amount' => $extra,
            'total_amount' => $total,
            'deposit_amount' => $deposit,
            'status' => $status,
            'notes' => $notes,
            'created_at' => Format::today()
        ]);

        // Si acompte immédiat
        if ($deposit > 0) {
            $methodId = (int)($data['payment_method_id'] ?? 1);
            $accountId = (int)($data['financial_account_id'] ?? 1);
            $this->paymentModel->create([
                'reference' => $this->paymentModel->nextReference(),
                'type' => 'PAIEMENT',
                'payment_date' => Format::today(),
                'payment_time' => date('H:i'),
                'reservation_id' => $resId,
                'client_id' => $clientId,
                'invoice_id' => null,
                'amount' => $deposit,
                'payment_method_id' => $methodId,
                'financial_account_id' => $accountId,
                'transaction_ref' => 'Acompte réservation',
                'author_name' => $user['name']
            ]);
        }

        $this->roomModel->syncStatus($roomId);
        AuditLog::log("Création réservation #{$resId}", "Chambre {$room['number']} pour {$client['first_name']} {$client['last_name']}", $user['name']);

        return $this->reservationModel->findWithDetails($resId);
    }

    public function checkin(int $id, array $user): array
    {
        $res = $this->reservationModel->find($id);
        if (!$res) throw new Exception('Réservation introuvable.');

        $room = $this->roomModel->find($res['room_id']);
        if (in_array($room['status'], ['A_NETTOYER', 'MAINTENANCE'])) {
            throw new Exception("Impossible d'effectuer le check-in : la chambre est en statut {$room['status']}.");
        }

        // Vérifier s'il n'y a pas un autre séjour actuellement EN_COURS dans la même chambre
        $other = Reservation::queryOne("SELECT id FROM `reservations` WHERE `room_id` = :rid AND `status` = 'EN_COURS' AND `id` != :id LIMIT 1", [
            'rid' => $res['room_id'],
            'id' => $id
        ]);
        if ($other) {
            throw new Exception("Cette chambre est encore occupée par un autre séjour en cours (#{$other['id']}).");
        }

        $this->reservationModel->update($id, ['status' => 'EN_COURS']);
        $this->roomModel->update($res['room_id'], ['status' => 'OCCUPEE']);

        AuditLog::log("Check-in réservation #{$id}", "Client installé en {$room['number']}", $user['name']);
        return $this->reservationModel->findWithDetails($id);
    }

    public function checkout(int $id, array $user): array
    {
        $res = $this->reservationModel->find($id);
        if (!$res) throw new Exception('Réservation introuvable.');

        $this->reservationModel->update($id, ['status' => 'TERMINEE']);
        // Règle PRD 233 & 615 : Le départ déclenche obligatoirement le statut À NETTOYER
        $this->roomModel->update($res['room_id'], ['status' => 'A_NETTOYER']);

        $room = $this->roomModel->find($res['room_id']);
        AuditLog::log("Check-out réservation #{$id}", "Départ enregistré, {$room['number']} marquée À NETTOYER", $user['name']);

        return $this->reservationModel->findWithDetails($id);
    }

    public function extend(int $id, string $newDeparture, array $user): array
    {
        $res = $this->reservationModel->find($id);
        if (!$res) throw new Exception('Réservation introuvable.');

        if ($newDeparture <= $res['departure_date']) {
            throw new Exception('La nouvelle date de départ doit être strictement postérieure à l’actuelle.');
        }

        // Vérifier si la chambre est libre sur l'extension
        $conflict = $this->reservationModel->checkOverlap($res['room_id'], $res['arrival_date'], $newDeparture, $id);
        if ($conflict) {
            throw new Exception("Impossible de prolonger : la chambre est déjà réservée à partir du " . Format::date($conflict['arrival_date']) . " pour {$conflict['first_name']} {$conflict['last_name']}.");
        }

        $nights = Format::diffDays($res['arrival_date'], $newDeparture);
        $total = ($nights * (int)$res['rate_applied']) + (int)$res['extra_amount'] - (int)$res['discount_amount'];

        $this->reservationModel->update($id, [
            'departure_date' => $newDeparture,
            'nights' => $nights,
            'total_amount' => $total
        ]);

        AuditLog::log("Prolongation réservation #{$id}", "Nouvelle date de départ : " . Format::date($newDeparture), $user['name']);
        return $this->reservationModel->findWithDetails($id);
    }

    public function cancel(int $id, array $user): array
    {
        $res = $this->reservationModel->find($id);
        if (!$res) throw new Exception('Réservation introuvable.');

        $this->reservationModel->update($id, ['status' => 'ANNULEE']);
        $this->roomModel->syncStatus($res['room_id']);

        AuditLog::log("Annulation réservation #{$id}", "Réservation annulée", $user['name']);
        return $this->reservationModel->findWithDetails($id);
    }
}
