<?php
// app/Models/PaymentMethod.php

namespace App\Models;

class PaymentMethod extends Model
{
    protected string $table = 'payment_methods';
}
