<?php
// config/app.php

return [
    'name' => 'Residence Manager',
    'env' => 'development',
    'timezone' => 'Africa/Abidjan',
    'currency' => 'FCFA',
    'session_name' => 'rm_session_id',
    'session_lifetime' => 86400 * 7, // 7 jours
    'api_prefix' => '/api'
];
