/* RESIDENCE MANAGER - Pages : tableau de bord, chambres, réservations, clients, séjours */
const PERIODS = {
  today: 'Aujourd’hui',
  week: 'Cette semaine',
  month: 'Ce mois-ci',
  quarter: 'Ce trimestre',
  year: 'Cette année',
  last30: '30 derniers jours',
  custom: 'Période personnalisée'
};
const PERIOD = JSON.parse(sessionStorage.getItem('rm_period') || '{"key":"last30"}');
const MONTHS = ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'];
const DAYS = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];

function periodRange(p = PERIOD) {
  const t = new Date(TODAY + 'T00:00:00'), y = t.getFullYear(), m = t.getMonth();
  switch (p.key) {
    case 'today': return [TODAY, TODAY];
    case 'week': { const wd = (t.getDay() + 6) % 7; const a = addDays(TODAY, -wd); return [a, addDays(a, 6)]; }
    case 'month': return [iso(new Date(y, m, 1)), iso(new Date(y, m + 1, 0))];
    case 'quarter': { const q = Math.floor(m / 3) * 3; return [iso(new Date(y, q, 1)), iso(new Date(y, q + 3, 0))]; }
    case 'year': return [`${y}-01-01`, `${y}-12-31`];
    case 'custom': return [p.from || addDays(TODAY, -29), p.to || TODAY];
    default: return [addDays(TODAY, -29), TODAY];
  }
}

function buckets([a, b], key = PERIOD.key) {
  const out = [];
  if (key === 'today') return [{ label: 'Aujourd’hui', a, b }];
  if (key === 'week') {
    for (let i = 0; i < 7; i++) {
      const d = addDays(a, i);
      out.push({ label: DAYS[new Date(d + 'T00:00:00').getDay()], a: d, b: d });
    }
    return out;
  }
  if (key === 'quarter' || key === 'year') {
    const s = new Date(a + 'T00:00:00');
    const n = key === 'year' ? 12 : 3;
    for (let i = 0; i < n; i++) {
      const f = new Date(s.getFullYear(), s.getMonth() + i, 1);
      const l = new Date(s.getFullYear(), s.getMonth() + i + 1, 0);
      out.push({ label: MONTHS[f.getMonth()], a: iso(f), b: iso(l) });
    }
    return out;
  }
  const days = diffDays(a, b) + 1, n = 4, step = Math.ceil(days / n);
  for (let i = 0; i < n; i++) {
    const s = addDays(a, i * step);
    if (s > b) break;
    const e = addDays(s, step - 1) > b ? b : addDays(s, step - 1);
    out.push({ label: key === 'month' || key === 'last30' ? 'Sem. ' + (i + 1) : fshort(s), a: s, b: e });
  }
  return out;
}

const inR = (d, [a, b]) => d >= a && d <= b;
const sumPay = r => DB.s.payments.filter(p => inR(p.date, r)).reduce((s, p) => s + p.amount, 0);
const sumExp = r => DB.s.expenses.filter(e => e.paidAmount && inR(e.date, r)).reduce((s, e) => s + e.paidAmount, 0)
  + DB.s.supplierPayments.filter(p => inR(p.date, r)).reduce((s, p) => s + p.amount, 0);
const caOf = r => DB.s.reservations.filter(x => !['ANNULEE', 'NO_SHOW'].includes(x.status) && inR(x.arrival, r)).reduce((s, x) => s + resTotal(x), 0);

/* ===================== TABLEAU DE BORD ===================== */
function pageDashboard(el) {
  const S = DB.s, R = periodRange(), len = diffDays(R[0], R[1]) + 1, PR = [addDays(R[0], -len), addDays(R[0], -1)];
  const cnt = st => S.rooms.filter(r => r.status === st).length, total = S.rooms.length;
  const occ = cnt('OCCUPEE'), free = S.rooms.filter(r => !r.status || r.status === 'LIBRE' || r.status === 'DISPONIBLE').length, res = cnt('RESERVEE'), clean = cnt('A_NETTOYER'), maint = cnt('MAINTENANCE');
  const occPct = total ? Math.round(occ / total * 100) : 0;
  const freePct = total ? Math.round(free / total * 100) : 0;
  const upcoming = S.reservations.filter(r => ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status) && r.departure > TODAY);
  const ca = caOf(R), caP = caOf(PR), delta = caP ? Math.round((ca - caP) / caP * 100) : 0;
  const arrivals = S.reservations.filter(r => r.arrival === TODAY && ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status)).length;
  const departs = S.reservations.filter(r => r.departure === TODAY && r.status === 'EN_COURS').length;
  const receivables = S.invoices.reduce((a, i) => a + invBalance(i), 0);
  const debts = S.purchases.reduce((a, p) => a + purchTotal(p) - purchPaid(p), 0);
  const income = sumPay(R), spent = sumExp(R);
  const tre = treasury();

  const stay = S.reservations
    .filter(r => ['EN_COURS', 'CONFIRMEE', 'EN_ATTENTE'].includes(r.status))
    .sort((a, b) => (a.status === 'EN_COURS' ? 0 : 1) - (b.status === 'EN_COURS' ? 0 : 1) || a.arrival.localeCompare(b.arrival))
    .slice(0, 4);
  const stBadge = { EN_COURS: ['En cours', 'sb-green'], CONFIRMEE: ['Réservé', 'sb-blue'], EN_ATTENTE: ['À venir', 'sb-orange'] };

  const ops = [
    ...S.payments.map(p => ({
      ts: p.date + ' ' + (p.time || '12:00'),
      icon: 'bi-currency-dollar',
      c: 'green',
      t: (p.amount < 0 ? 'Remboursement' : 'Encaissement') + ' – ' + fcfa(Math.abs(p.amount)),
      s: (DB.find('reservations', p.resId) ? roomNum(DB.find('reservations', p.resId).roomId) : clientName(p.clientId)) + ' • ' + fdate(p.date) + ' ' + (p.time || ''),
      ok: true
    })),
    ...S.purchases.map(p => ({
      ts: p.date + ' 13:20',
      icon: 'bi-cart-fill',
      c: 'red',
      t: 'Achat – ' + (p.items[0] ? p.items[0].label : 'Articles'),
      s: supplierName(p.supplierId) + ' • ' + fdate(p.date),
      ok: false
    })),
    ...S.expenses.filter(e => e.paidAmount).map(e => ({
      ts: e.date + ' ' + (e.time || '12:45'),
      icon: 'bi-file-earmark-text-fill',
      c: 'orange',
      t: 'Dépense – ' + e.category,
      s: fdate(e.date) + ' ' + (e.time || ''),
      ok: false
    })),
    ...S.invoices.map(i => ({
      ts: i.date + ' 10:00',
      icon: 'bi-file-earmark-check-fill',
      c: 'blue',
      t: 'Facture N°' + i.number,
      s: 'Client ' + clientName(i.clientId) + ' • ' + fdate(i.date),
      ok: true
    }))
  ].sort((a, b) => b.ts.localeCompare(a.ts)).slice(0, 4);

  const stat = (cls, icon, label, val, sub) => `
    <div class="stat ${cls}">
      <div class="stat-ico"><i class="bi ${icon}"></i></div>
      <div>
        <div class="stat-l">${label}</div>
        <div class="stat-v">${val}</div>
        ${sub ? `<div class="stat-s">${sub}</div>` : ''}
      </div>
    </div>
  `;

  // Grille directe de toutes les chambres (sans regroupement par etage)
  const roomsGrid = `
    <div class="rooms-direct-grid">
      ${S.rooms.map(r => {
        const st = roomSt(r.status);
        const occInfo = getCurrentOccupant(r.id);
        const occTitle = occInfo && occInfo.client ? `Occupant : ${occInfo.client.first} ${occInfo.client.last}` : `Statut : ${st[0]}`;
        const occSub = occInfo && occInfo.client ? `${occInfo.client.last}` : st[0];
        return `
          <button type="button" class="tile t-${st[1]}" data-act="room.details" data-id="${r.id}" title="${esc(occTitle)}">
            <b>${esc(r.number)}</b>
            <span>${esc(occSub)}</span>
            <small>${fmt(r.daily)} /j</small>
          </button>
        `;
      }).join('')}
    </div>
  `;

  el.innerHTML = `
    <div class="stats">
      ${stat('s-blue', 'bi-door-closed', 'Chambres totales', total)}
      ${stat('s-green', 'bi-check-circle-fill', 'Occupées', occ, `(${occPct}%)`)}
      ${stat('s-amber', 'bi-door-open', 'Libres', free, `(${freePct}%)`)}
      ${stat('s-purple', 'bi-calendar-event', 'Réservations', upcoming.length, '(à venir)')}
      ${stat('s-green2', 'bi-bar-chart-fill', 'Chiffre d’affaires', fcfa(ca), `<i class="bi bi-arrow-${delta >= 0 ? 'up' : 'down'}"></i> ${delta >= 0 ? '+' : ''}${delta}%`)}
    </div>
    <div class="mini-kpis">
      <span><i class="bi bi-box-arrow-in-right"></i> Arrivées du jour <b>${arrivals}</b></span>
      <span><i class="bi bi-box-arrow-right"></i> Départs du jour <b>${departs}</b></span>
      <span><i class="bi bi-wrench"></i> Maintenance <b>${maint}</b></span>
      <span><i class="bi bi-bucket"></i> À nettoyer <b>${clean}</b></span>
      <span><i class="bi bi-cash-coin"></i> Encaissements <b>${fcfa(income)}</b></span>
      <span><i class="bi bi-cash-stack"></i> Dépenses payées <b>${fcfa(spent)}</b></span>
    </div>
    <div class="row g-3 mb-3">
      <div class="col-xl-6">
        <div class="card-box h-100">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="card-title-x">Évolution financière</h6>
            <span class="text-muted small">${PERIODS[PERIOD.key]}</span>
          </div>
          <div class="chart-wrap"><canvas id="chFin"></canvas></div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="card-box h-100">
          <h6 class="card-title-x">Statut des chambres</h6>
          <div class="donut-wrap">
            <canvas id="chDonut"></canvas>
            <div class="donut-c"><b>${occPct}%</b><span>Occupées</span></div>
          </div>
          <ul class="legend-list">
            <li><i style="background:#198754"></i>Occupées<b>${occ}</b></li>
            <li><i style="background:#2563EB"></i>Libres<b>${free}</b></li>
            <li><i style="background:#60a5fa"></i>Réservées<b>${res}</b></li>
            <li><i style="background:#E6A23C"></i>À nettoyer<b>${clean}</b></li>
            <li><i style="background:#8b3fb8"></i>Maintenance<b>${maint}</b></li>
          </ul>
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="card-box h-100">
          <div class="d-flex justify-content-between">
            <h6 class="card-title-x">Calendrier des séjours</h6>
            <a href="#/reservations" class="small text-decoration-none">Voir tout →</a>
          </div>
          ${stay.map(r => {
            const n = clientName(r.clientId);
            const b = stBadge[r.status];
            return `
              <div class="stay-item">
                ${avatar(n)}
                <div class="flex-grow-1">
                  <b>${esc(n)}</b>
                  <div class="small text-muted">${roomNum(r.roomId)} • ${fshort(r.arrival)} – ${fshort(r.departure)}</div>
                </div>
                <span class="sbadge ${b[1]}">${b[0]}</span>
              </div>
            `;
          }).join('') || '<p class="text-muted small mt-3">Aucun séjour</p>'}
        </div>
      </div>
    </div>
    <div class="row g-3">
      <div class="col-xl-6">
        <div class="card-box h-100">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="card-title-x mb-0">Plan des chambres</h6>
            <small class="text-muted"><i class="bi bi-hand-index-thumb"></i> Cliquez sur une chambre pour voir l'occupant</small>
          </div>
          ${roomsGrid}
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="card-box h-100">
          <div class="d-flex justify-content-between">
            <h6 class="card-title-x">Dernières opérations</h6>
            <a href="#/payments" class="small text-decoration-none">Voir tout →</a>
          </div>
          ${ops.map(o => `
            <div class="op-item">
              <span class="op-ico oi-${o.c}"><i class="bi ${o.icon}"></i></span>
              <div class="flex-grow-1">
                <b>${esc(o.t)}</b>
                <div class="small text-muted">${esc(o.s)}</div>
              </div>
              <i class="bi ${o.ok ? 'bi-check-circle-fill text-success' : 'bi-dash-circle-fill text-danger'}"></i>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="treasury h-100">
          <div class="d-flex gap-3 align-items-center">
            <i class="bi bi-wallet2 fs-1 text-warning"></i>
            <div>
              <div class="small">Trésorerie actuelle</div>
              <div class="fs-4 fw-bold">${fcfa(tre)}</div>
              <div class="small text-success-emphasis tre-up">↑ ${income >= spent ? '+' : ''}${fcfa(income - spent)} sur la période</div>
            </div>
          </div>
          <div class="tre-chart"><canvas id="chTre"></canvas></div>
          <div class="tre-line"><span>Créances clients</span><b>${fcfa(receivables)}</b></div>
          <div class="tre-line"><span>Dettes fournisseurs</span><b>${fcfa(debts)}</b></div>
          <div class="tre-line"><span>Résultat estimé</span><b>${fcfa(ca - spent)}</b></div>
        </div>
      </div>
    </div>
  `;

  const bk = buckets(R);
  const rec = bk.map(b => sumPay([b.a, b.b])), dep = bk.map(b => sumExp([b.a, b.b])), resu = rec.map((v, i) => v - dep[i]);
  const ds = (l, d, c) => ({ label: l, data: d, borderColor: c, backgroundColor: c, tension: .35, pointRadius: 4, pointBackgroundColor: '#fff', pointBorderWidth: 2 });

  mkChart($('#chFin'), {
    type: 'line',
    data: { labels: bk.map(b => b.label), datasets: [ds('Recettes', rec, '#2563EB'), ds('Dépenses', dep, '#E6A23C'), ds('Résultat', resu, '#198754')] },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', align: 'start', labels: { usePointStyle: true, boxWidth: 8 } },
        tooltip: { callbacks: { label: c => c.dataset.label + ' : ' + fcfa(c.parsed.y) } }
      },
      scales: { y: { ticks: { callback: v => v >= 1e6 ? v / 1e6 + 'M' : v >= 1e3 ? v / 1e3 + 'k' : v } } }
    }
  });

  mkChart($('#chDonut'), {
    type: 'doughnut',
    data: {
      labels: ['Occupées', 'Libres', 'Réservées', 'À nettoyer', 'Maintenance'],
      datasets: [{ data: [occ, free, res, clean, maint], backgroundColor: ['#198754', '#2563EB', '#60a5fa', '#E6A23C', '#8b3fb8'], borderWidth: 2 }]
    },
    options: { cutout: '68%', plugins: { legend: { display: false } } }
  });

  let run = tre;
  const pts = [];
  for (let i = bk.length - 1; i >= 0; i--) {
    pts.unshift(run);
    run -= rec[i] - dep[i];
  }

  mkChart($('#chTre'), {
    type: 'line',
    data: { labels: bk.map(b => b.label), datasets: [{ data: pts, borderColor: '#60a5fa', backgroundColor: 'rgba(96,165,250,.3)', fill: true, tension: .35, pointRadius: 3 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } } }
  });
}

/* ===================== CHAMBRES ===================== */
let ROOM_VIEW = 'plan';
const roomAvail = r => {
  const occ = getCurrentOccupant(r.id);
  if (r.status === 'MAINTENANCE') return '<span class="text-danger fw-semibold">Indisponible (Maintenance)</span>';
  if (r.status === 'A_NETTOYER') return '<span class="text-warning fw-semibold">À nettoyer</span>';
  if (occ && occ.type === 'current' && occ.client) {
    return `<span class="text-primary fw-semibold"><i class="bi bi-person-fill"></i> ${esc(occ.client.first + ' ' + occ.client.last)}</span> (jusqu'au ${fdate(occ.reservation.departure)})`;
  }
  if (occ && occ.type === 'upcoming' && occ.client) {
    return `<span class="text-info fw-semibold"><i class="bi bi-calendar-check"></i> ${esc(occ.client.first + ' ' + occ.client.last)}</span> (du ${fdate(occ.reservation.arrival)})`;
  }
  return '<span class="text-success"><i class="bi bi-check-circle"></i> Disponible</span>';
};

const roomsCfg = {
  key: 'rooms',
  coll: 'rooms',
  singular: 'chambre',
  addLabel: 'Ajouter une chambre',
  remove: true,
  perPage: 12,
  canRemove: () => true,
  rows: () => DB.s.rooms,
  search: r => `${r.number} ${(DB.find('roomTypes', r.typeId) || {}).name} ${r.status}`,
  cols: [
    { l: 'Nom de chambre', f: r => `<b>${esc(r.number)}</b>` },
    { l: 'Catégorie', f: r => `<span class="badge text-bg-light border">${esc((DB.find('roomTypes', r.typeId) || {}).name || 'Standard')}</span>` },
    { l: 'Capacité / Superficie', f: r => `${r.capacity} pers.${r.area ? ` • ${r.area} m²` : ''}` },
    { l: 'Tarif / jour', f: r => `<b class="text-primary">${fcfa(r.daily)}</b>` },
    { l: 'Hebdo / Mois', f: r => `<small class="text-muted">${fcfa(r.weekly)} /sem<br>${fcfa(r.monthly)} /mois</small>` },
    { l: 'Statut', f: r => roomBadge(r.status) },
    { l: 'Occupant / Disponibilité', f: r => roomAvail(r) }
  ],
  actions: r => `
    <button class="btn btn-sm btn-outline-info" title="Voir l'occupant" data-act="room.details" data-id="${r.id}"><i class="bi bi-person-lines-fill"></i></button>
    ${r.status === 'A_NETTOYER' ? `<button class="btn btn-sm btn-success" title="Valider le ménage" data-act="room.clean" data-id="${r.id}"><i class="bi bi-check2"></i> Ménage</button> ` : ''}
    ${r.status === 'MAINTENANCE' ? `<button class="btn btn-sm btn-outline-success" data-act="room.maint" data-id="${r.id}" title="Fin de maintenance"><i class="bi bi-wrench"></i></button> ` : (!['OCCUPEE'].includes(r.status) ? `<button class="btn btn-sm btn-outline-warning" data-act="room.maint" data-id="${r.id}" title="Mettre en maintenance"><i class="bi bi-wrench"></i></button> ` : '')}
  `,
  fields: [
    { k: 'number', label: 'Nom de la chambre (ex: Chambre 101, Suite Orchidée)', required: true, col: 6 },
    { k: 'typeId', label: 'Catégorie de la chambre', type: 'select', numeric: true, required: true, options: () => DB.s.roomTypes.map(t => ({ v: t.id, l: t.name })), col: 6 },
    { k: 'capacity', label: 'Capacité maximale (personnes)', type: 'number', min: 1, col: 4 },
    { k: 'area', label: 'Superficie (m²)', type: 'number', col: 4 },
    { k: 'status', label: 'Statut opérationnel', type: 'select', options: Object.keys(ROOM_ST).map(k => ({ v: k, l: ROOM_ST[k][0] })), col: 4 },
    { k: 'daily', label: 'Tarif journalier personnalisé (FCFA)', type: 'number', min: 0, col: 4 },
    { k: 'weekly', label: 'Tarif hebdomadaire (FCFA)', type: 'number', min: 0, col: 4 },
    { k: 'monthly', label: 'Tarif mensuel (FCFA)', type: 'number', min: 0, col: 4 },
    { k: 'equipment', label: 'Équipements inclus', col: 12 },
    { k: 'description', label: 'Description & notes', type: 'textarea', col: 12 }
  ],
  defaults: () => {
    const firstType = DB.s.roomTypes[0] || { id: 1, daily: 25000, weekly: 150000, monthly: 500000, capacity: 2 };
    return {
      typeId: firstType.id,
      capacity: firstType.capacity || 2,
      status: 'LIBRE',
      daily: firstType.daily || 25000,
      weekly: firstType.weekly || 150000,
      monthly: firstType.monthly || 500000
    };
  },
  onInput: (form, d) => {
    if (form.dataset.t !== String(d.typeId)) {
      if (form.dataset.t) {
        const t = DB.find('roomTypes', d.typeId);
        if (t) {
          form.elements.daily.value = t.daily;
          form.elements.weekly.value = t.weekly;
          form.elements.monthly.value = t.monthly;
          form.elements.capacity.value = t.capacity;
        }
      }
      form.dataset.t = String(d.typeId);
    }
  },
  validate: (d, cur) => DB.s.rooms.some(r => r.number.toLowerCase() === d.number.toLowerCase() && (!cur || r.id !== cur.id)) ? 'Ce nom de chambre existe déjà.' : null
};

CRUD.rooms = roomsCfg;
roomsCfg.state = { q: '', page: 1 };

ACT.roomview = (v) => { ROOM_VIEW = v; renderPage(); };
ACT['room.clean'] = async id => {
  try {
    if (typeof API !== 'undefined') await API.cleanRoom(id);
  } catch (e) {
    console.warn('API clean error:', e);
  }
  DB.upd('rooms', id, { status: 'LIBRE' });
  syncRoom(Number(id));
  DB.log('Ménage validé : ' + roomNum(Number(id)));
  toast('Ménage validé, chambre remise à disposition');
  renderPage();
};
ACT['room.maint'] = async id => {
  const r = DB.find('rooms', id);
  try {
    if (typeof API !== 'undefined') await API.maintenanceRoom(id);
  } catch (e) {
    console.warn('API maint error:', e);
  }
  if (r.status === 'MAINTENANCE') {
    r.status = 'LIBRE';
    DB.save();
    syncRoom(r.id);
    toast('Maintenance terminée');
  } else {
    DB.upd('rooms', id, { status: 'MAINTENANCE' });
    toast('Chambre mise en maintenance', 'warning');
  }
  DB.log('Maintenance : ' + r.number);
  renderPage();
};

function pageRooms(el) {
  const tabs = `
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <div class="btn-group">
        <button class="btn btn-${ROOM_VIEW === 'plan' ? 'primary' : 'outline-primary'}" data-act="roomview" data-id="plan"><i class="bi bi-grid-3x3-gap"></i> Plan visuel</button>
        <button class="btn btn-${ROOM_VIEW === 'list' ? 'primary' : 'outline-primary'}" data-act="roomview" data-id="list"><i class="bi bi-list-ul"></i> Liste détaillée</button>
      </div>
      <div class="d-flex align-items-center gap-2">
        <span class="badge text-bg-light border px-3 py-2 fs-6"><i class="bi bi-door-closed text-primary me-1"></i> <b>${DB.s.rooms.length}</b> chambre(s) au total</span>
        <button class="btn btn-primary" data-act="crud" data-key="rooms" data-op="add"><i class="bi bi-plus-lg me-1"></i> Ajouter une chambre</button>
      </div>
    </div>
  `;

  if (ROOM_VIEW === 'list') return el.innerHTML = tabs + crudHtml(roomsCfg);

  const legend = Object.keys(ROOM_ST).map(k => `<span class="me-3">${roomBadge(k)}</span>`).join('');

  el.innerHTML = tabs + `
    <div class="card-box">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div>${legend}</div>
        <small class="text-muted"><i class="bi bi-info-circle me-1"></i> Cliquez sur une chambre pour la modifier, voir l'occupant ou la supprimer</small>
      </div>
      <div class="rooms-direct-grid big">
        ${DB.s.rooms.map(r => {
          const st = roomSt(r.status);
          const occ = getCurrentOccupant(r.id);
          const hasOcc = r.status === 'OCCUPEE' && occ && occ.client;
          return `
            <button type="button" class="tile t-${st[1]}" data-act="room.details" data-id="${r.id}" title="Cliquez pour afficher, modifier ou supprimer la chambre ${esc(r.number)}">
              <b>${esc(r.number)}</b>
              <span>${hasOcc ? esc(occ.client.first + ' ' + occ.client.last) : st[0]}</span>
              <small>${fmt(r.daily)} /j</small>
              ${hasOcc ? `<span class="badge bg-dark-subtle text-dark mt-1 px-1 py-0 small"><i class="bi bi-person-fill"></i> Occupant</span>` : ''}
            </button>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

/* ===================== RÉSERVATIONS ===================== */
let RES_TAB = 'list', CAL_START = addDays(TODAY, -2);
const activeRes = r => ['EN_ATTENTE', 'CONFIRMEE', 'EN_COURS'].includes(r.status);
const syncAll = () => DB.s.rooms.forEach(r => syncRoom(r.id));

const resCfg = {
  key: 'reservations',
  coll: 'reservations',
  singular: 'réservation',
  addLabel: 'Nouvelle réservation',
  perPage: 10,
  rows: () => [...DB.s.reservations].sort((a, b) => b.arrival.localeCompare(a.arrival)),
  search: r => `${clientName(r.clientId)} ${roomNum(r.roomId)} ${r.status}`,
  cols: [
    { l: 'Client', f: r => `<b>${esc(clientName(r.clientId))}</b>` },
    { l: 'Chambre', f: r => `<b>${roomNum(r.roomId)}</b>` },
    { l: 'Séjour', f: r => `${fdate(r.arrival)} → ${fdate(r.departure)}<div class="small text-muted">${r.nights} nuit(s)</div>` },
    { l: 'Total', f: r => fcfa(resTotal(r)) },
    { l: 'Payé', f: r => fcfa(resPaid(r)) },
    { l: 'Solde', f: r => { const b = resBalance(r); return `<span class="${b > 0 ? 'text-danger fw-semibold' : 'text-success'}">${fcfa(b)}</span>`; } },
    { l: 'Statut', f: r => badge(RES_ST, r.status) }
  ],
  actions: r => {
    const b = (a, i, t, c = 'outline-primary') => `<button class="btn btn-sm btn-${c}" title="${t}" data-act="${a}" data-id="${r.id}"><i class="bi ${i}"></i></button> `;
    let h = '';
    if (r.status === 'EN_ATTENTE') h += b('res.confirm', 'bi-check2-circle', 'Confirmer', 'outline-success');
    if (r.status === 'CONFIRMEE') h += b('res.checkin', 'bi-box-arrow-in-right', 'Check-in (Installation)', 'success');
    if (r.status === 'EN_COURS') h += b('res.checkout', 'bi-box-arrow-right', 'Check-out (Départ)', 'warning') + b('res.extend', 'bi-calendar-plus', 'Prolonger');
    if (activeRes(r) || r.status === 'TERMINEE') h += b('res.pay', 'bi-cash', 'Enregistrer un paiement', 'outline-success') + b('res.invoice', 'bi-file-earmark-text', 'Facturer');
    if (['EN_ATTENTE', 'CONFIRMEE'].includes(r.status)) h += b('res.cancel', 'bi-x-circle', 'Annuler', 'outline-danger');
    return h;
  },
  fields: [
    { k: 'clientId', label: 'Client', type: 'select', numeric: true, required: true, empty: true, options: () => DB.s.clients.map(c => ({ v: c.id, l: c.first + ' ' + c.last })) },
    { k: 'roomId', label: 'Chambre', type: 'select', numeric: true, required: true, empty: true, options: () => DB.s.rooms.map(r => ({ v: r.id, l: `${r.number} — ${(DB.find('roomTypes', r.typeId) || {}).name} (${fmt(r.daily)} /j)` })) },
    { k: 'arrival', label: 'Date d’arrivée', type: 'date', required: true, col: 4 },
    { k: 'departure', label: 'Date de départ', type: 'date', required: true, col: 4 },
    { k: 'guests', label: 'Nombre de personnes', type: 'number', min: 1, col: 4 },
    { k: 'rate', label: 'Tarif appliqué / nuit', type: 'number', min: 0, col: 3 },
    { k: 'discount', label: 'Remise', type: 'number', min: 0, col: 3 },
    { k: 'extra', label: 'Frais supplémentaires', type: 'number', min: 0, col: 3 },
    { k: 'deposit', label: 'Acompte versé', type: 'number', min: 0, col: 3 },
    { k: 'status', label: 'Statut', type: 'select', options: Object.keys(RES_ST).map(k => ({ v: k, l: RES_ST[k][0] })) },
    { k: 'calc', label: 'Calcul automatique', type: 'info', col: 6 },
    { k: 'notes', label: 'Observations', type: 'textarea', col: 12 }
  ],
  defaults: () => ({ arrival: TODAY, departure: addDays(TODAY, 1), guests: 1, rate: 0, discount: 0, extra: 0, deposit: 0, status: 'CONFIRMEE' }),
  onInput: (form, d) => {
    if (form.dataset.room !== String(d.roomId)) {
      if (d.roomId && (form.dataset.room !== undefined || !Number(form.elements.rate.value))) {
        form.elements.rate.value = (DB.find('rooms', d.roomId) || {}).daily || 0;
        d.rate = Number(form.elements.rate.value);
      }
      form.dataset.room = String(d.roomId);
    }
    const n = Math.max(0, diffDays(d.arrival, d.departure));
    $('#f_calc', form).innerHTML = `<b>${n}</b> nuit(s) × ${fcfa(d.rate)} + ${fcfa(d.extra)} − ${fcfa(d.discount)} = <b>${fcfa(n * d.rate + d.extra - d.discount)}</b>`;
  },
  validate: (d, cur) => {
    if (d.departure <= d.arrival) return 'La date de départ doit être strictement postérieure à la date d’arrivée.';
    const room = DB.find('rooms', d.roomId);
    if (room && d.guests > room.capacity) return `${room.number} accepte au maximum ${room.capacity} personne(s).`;
    if (room && room.status === 'MAINTENANCE' && ['CONFIRMEE', 'EN_COURS'].includes(d.status)) return 'Cette chambre est en maintenance et ne peut pas être réservée.';
    if (['CONFIRMEE', 'EN_COURS'].includes(d.status)) {
      const c = overlap(d.roomId, d.arrival, d.departure, cur && cur.id);
      if (c) return `<b>Double réservation bloquée :</b> la chambre ${roomNum(c.roomId)} est déjà réservée du ${fdate(c.arrival)} au ${fdate(c.departure)} pour ${esc(clientName(c.clientId))}.`;
    }
    return null;
  },
  before: (d, cur) => {
    d.nights = diffDays(d.arrival, d.departure);
    d.total = resTotal(d);
    if (!cur) d.createdAt = TODAY;
  },
  after: o => {
    if (o.deposit > 0 && !DB.s.payments.some(p => p.resId === o.id)) {
      DB.add('payments', {
        ref: DB.ref('PAY', 'payments'),
        type: 'PAIEMENT',
        date: TODAY,
        time: new Date().toTimeString().slice(0, 5),
        resId: o.id,
        clientId: o.clientId,
        invoiceId: null,
        amount: o.deposit,
        methodId: 1,
        accountId: 1,
        txRef: 'Acompte réservation',
        author: SESSION.name
      });
    }
    syncAll();
  }
};

CRUD.reservations = resCfg;
resCfg.state = { q: '', page: 1 };

const setRes = (id, patch, msg) => {
  DB.upd('reservations', id, patch);
  syncAll();
  DB.log(`${msg} (réservation #${id})`);
  toast(msg);
  renderPage();
};

ACT['res.confirm'] = id => {
  const r = DB.find('reservations', id);
  const c = overlap(r.roomId, r.arrival, r.departure, r.id);
  if (c) return toast('Chevauchement avec une autre réservation confirmée', 'danger');
  setRes(id, { status: 'CONFIRMEE' }, 'Réservation confirmée');
};
ACT['res.checkin'] = async id => {
  const r = DB.find('reservations', id);
  const o = DB.s.reservations.find(x => x.roomId === r.roomId && x.status === 'EN_COURS');
  const room = DB.find('rooms', r.roomId);
  if (o) return toast('La chambre est encore occupée par un autre client', 'danger');
  if (['A_NETTOYER', 'MAINTENANCE'].includes(room.status)) return toast('Chambre indisponible : ' + roomSt(room.status)[0], 'danger');
  
  try {
    if (typeof API !== 'undefined') await API.checkin(id);
  } catch (e) {
    console.warn('API checkin error:', e);
  }
  if (room) room.current_occupant = null;
  setRes(id, { status: 'EN_COURS' }, 'Check-in enregistré (client installé)');
};
ACT['res.checkout'] = id => {
  const r = DB.find('reservations', id);
  const go = async () => {
    try {
      if (typeof API !== 'undefined') await API.checkout(id);
    } catch (e) {
      console.warn('API checkout error:', e);
    }
    DB.upd('reservations', id, { status: 'TERMINEE' });
    DB.upd('rooms', r.roomId, { status: 'A_NETTOYER', current_occupant: null });
    DB.log('Check-out : ' + roomNum(r.roomId));
    toast('Check-out validé — chambre marquée À NETTOYER', 'warning');
    renderPage();
  };
  resBalance(r) > 0 ? confirmBox(`Solde restant impayé : <b>${fcfa(resBalance(r))}</b>. Valider quand même le départ ?`, go, 'Valider départ', 'btn-warning') : go();
};
ACT['res.cancel'] = id => confirmBox('Annuler cette réservation ?', async () => {
  try {
    if (typeof API !== 'undefined') await API.cancelReservation(id);
  } catch (e) {
    console.warn('API cancel error:', e);
  }
  setRes(id, { status: 'ANNULEE' }, 'Réservation annulée');
}, 'Annuler', 'btn-danger');
ACT['res.extend'] = id => {
  const r = DB.find('reservations', id);
  openForm({
    title: 'Prolonger le séjour',
    size: 'modal-sm',
    fields: [{ k: 'departure', label: 'Nouvelle date de départ', type: 'date', required: true, col: 12 }],
    values: { departure: addDays(r.departure, 1) },
    onSubmit: async d => {
      if (d.departure <= r.departure) return 'La nouvelle date doit être postérieure.';
      const c = overlap(r.roomId, r.arrival, d.departure, r.id);
      if (c) return 'Chambre déjà réservée pour un autre client à partir du ' + fdate(c.arrival);
      const n = diffDays(r.arrival, d.departure);
      try {
        if (typeof API !== 'undefined') await API.extendReservation(id, d.departure);
      } catch (e) {
        console.warn('API extend error:', e);
      }
      DB.upd('reservations', id, { departure: d.departure, nights: n });
      DB.log('Prolongation séjour #' + id);
      toast('Séjour prolongé avec succès');
      renderPage();
    }
  });
};
ACT['res.pay'] = id => openPaymentForm(Number(id));
ACT['res.invoice'] = async id => {
  const r = DB.find('reservations', id);
  let inv = DB.s.invoices.find(i => i.resId === r.id && i.status !== 'ANNULEE');
  if (!inv) {
    try {
      if (typeof API !== 'undefined') {
        const srvInv = await API.invoiceFromReservation(r.id);
        if (srvInv) {
          inv = DB.add('invoices', {
            id: srvInv.id,
            number: srvInv.number,
            type: srvInv.type,
            date: srvInv.issue_date,
            clientId: srvInv.client_id,
            resId: srvInv.reservation_id,
            items: srvInv.items || reservationLines(DB.s, r),
            taxRate: 0,
            status: srvInv.status,
            terms: srvInv.terms || ''
          });
        }
      }
    } catch (e) {
      console.warn('API invoice error:', e);
    }
    if (!inv) {
      inv = DB.add('invoices', {
        number: DB.ref('FAC', 'invoices').replace(/-(\d+)$/, (m, n) => '-' + n.slice(1)),
        type: 'FACTURE',
        date: TODAY,
        clientId: r.clientId,
        resId: r.id,
        items: reservationLines(DB.s, r),
        taxRate: DB.s.building.taxRate,
        status: 'EMISE',
        terms: DB.s.building.terms
      });
      DB.s.payments.filter(p => p.resId === r.id && !p.invoiceId).forEach(p => { p.invoiceId = inv.id; });
      DB.save();
    }
    DB.log('Facture ' + inv.number + ' générée');
  }
  showInvoice(inv.id);
};
ACT.restab = t => { RES_TAB = t; renderPage(); };
ACT.calnav = n => { CAL_START = addDays(CAL_START, Number(n)); renderPage(); };
ACT.caltoday = () => { CAL_START = addDays(TODAY, -2); renderPage(); };

function resCalendar() {
  const N = 14, days = [...Array(N)].map((_, i) => addDays(CAL_START, i));
  const head = days.map(d => {
    const dt = new Date(d + 'T00:00:00');
    return `<th class="${d === TODAY ? 'today' : ''}"><small>${DAYS[dt.getDay()]}</small><br>${d.slice(8)}</th>`;
  }).join('');

  const rows = DB.s.rooms.map(r => `
    <tr>
      <td class="cal-room">${esc(r.number)}</td>
      ${days.map(d => {
        const x = DB.s.reservations.find(z => z.roomId === r.id && ['CONFIRMEE', 'EN_COURS', 'EN_ATTENTE', 'TERMINEE'].includes(z.status) && z.arrival <= d && d < z.departure);
        const cls = x ? 'c-' + x.status : (r.status === 'MAINTENANCE' && d >= TODAY ? 'c-MAINT' : '');
        return `<td class="cal-cell ${cls} ${d === TODAY ? 'today' : ''}" ${x ? `title="${esc(clientName(x.clientId))} — ${fdate(x.arrival)} → ${fdate(x.departure)}"` : ''}>${x && (x.arrival === d || d === CAL_START) ? esc(clientName(x.clientId).split(' ').pop()) : ''}</td>`;
      }).join('')}
    </tr>
  `).join('');

  return `
    <div class="card-box">
      <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="btn-group">
          <button class="btn btn-outline-secondary" data-act="calnav" data-id="-7"><i class="bi bi-chevron-left"></i> Précédent</button>
          <button class="btn btn-outline-secondary" data-act="caltoday">Aujourd’hui</button>
          <button class="btn btn-outline-secondary" data-act="calnav" data-id="7">Suivant <i class="bi bi-chevron-right"></i></button>
        </div>
        <div class="small">
          <span class="lg c-CONFIRMEE"></span> Confirmée
          <span class="lg c-EN_COURS"></span> En cours
          <span class="lg c-EN_ATTENTE"></span> En attente
          <span class="lg c-TERMINEE"></span> Terminée
          <span class="lg c-MAINT"></span> Maintenance
        </div>
      </div>
      <div class="table-responsive">
        <table class="cal-table">
          <thead><tr><th>Chambre</th>${head}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>
  `;
}

function pageReservations(el) {
  const tabs = `
    <ul class="nav nav-pills mb-3">
      <li class="nav-item"><a href="#" class="nav-link ${RES_TAB === 'list' ? 'active' : ''}" data-act="restab" data-id="list"><i class="bi bi-list-check me-1"></i> Liste</a></li>
      <li class="nav-item"><a href="#" class="nav-link ${RES_TAB === 'cal' ? 'active' : ''}" data-act="restab" data-id="cal"><i class="bi bi-calendar3 me-1"></i> Calendrier de disponibilité</a></li>
    </ul>
  `;
  el.innerHTML = tabs + (RES_TAB === 'cal' ? resCalendar() : crudHtml(resCfg));
}

/* ===================== CLIENTS ===================== */
const cliBalance = c => DB.s.reservations.filter(r => r.clientId === c.id && !['ANNULEE', 'NO_SHOW'].includes(r.status)).reduce((a, r) => a + Math.max(0, resBalance(r)), 0);

const clientsCfg = {
  key: 'clients',
  coll: 'clients',
  singular: 'client',
  addLabel: 'Nouveau client',
  remove: true,
  canRemove: c => !DB.s.reservations.some(r => r.clientId === c.id),
  rows: () => [...DB.s.clients].sort((a, b) => b.id - a.id),
  search: c => `${c.first} ${c.last} ${c.phone} ${c.email} ${c.idNumber}`,
  cols: [
    { l: 'Client', f: c => `<div class="d-flex align-items-center gap-2">${avatar(c.first + ' ' + c.last)}<div><b>${esc(c.first + ' ' + c.last)}</b><div class="small text-muted">${esc(c.nationality || '')}</div></div></div>` },
    { l: 'Téléphone', f: c => esc(c.phone) },
    { l: 'E-mail', f: c => esc(c.email) },
    { l: 'Pièce d’identité', f: c => esc((c.idType || '') + ' ' + (c.idNumber || '')) },
    { l: 'Séjours', f: c => DB.s.reservations.filter(r => r.clientId === c.id).length },
    { l: 'Solde dû', f: c => { const b = cliBalance(c); return `<span class="${b > 0 ? 'text-danger fw-semibold' : 'text-muted'}">${fcfa(b)}</span>`; } }
  ],
  actions: c => `<button class="btn btn-sm btn-outline-primary" title="Historique" data-act="client.view" data-id="${c.id}"><i class="bi bi-eye"></i></button> `,
  fields: [
    { k: 'last', label: 'Nom', required: true },
    { k: 'first', label: 'Prénoms', required: true },
    { k: 'phone', label: 'Téléphone', type: 'tel', required: true },
    { k: 'email', label: 'E-mail', type: 'email' },
    { k: 'address', label: 'Adresse' },
    { k: 'nationality', label: 'Nationalité' },
    { k: 'idType', label: 'Type de pièce', type: 'select', options: ['CNI', 'Passeport', 'Permis de conduire', 'Carte consulaire', 'Autre'].map(x => ({ v: x, l: x })) },
    { k: 'idNumber', label: 'N° de pièce d’identité' },
    { k: 'notes', label: 'Observations', type: 'textarea', col: 12 }
  ],
  defaults: () => ({ idType: 'CNI', nationality: 'Ivoirienne' }),
  validate: (d, cur) => {
    const n = s => s.replace(/\s/g, '');
    const dup = DB.s.clients.find(c => (!cur || c.id !== cur.id) && n(c.phone) === n(d.phone));
    return dup ? `Un client (${esc(dup.first + ' ' + dup.last)}) est déjà enregistré avec ce numéro.` : null;
  },
  before: (d, cur) => { if (!cur) d.createdAt = TODAY; }
};

CRUD.clients = clientsCfg;
clientsCfg.state = { q: '', page: 1 };

ACT['client.view'] = id => {
  const c = DB.find('clients', id),
    rs = DB.s.reservations.filter(r => r.clientId === c.id),
    ps = DB.s.payments.filter(p => p.clientId === c.id),
    is = DB.s.invoices.filter(i => i.clientId === c.id);

  showModal(`
    <div class="modal-header"><h5 class="modal-title">${esc(c.first + ' ' + c.last)}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <p class="text-muted mb-3">${esc(c.phone)} • ${esc(c.email || '—')} • ${esc(c.idType + ' ' + c.idNumber)} • Client depuis le ${fdate(c.createdAt)}</p>
      <div class="row g-2 mb-3">
        <div class="col"><div class="mini-card">Séjours<b>${rs.length}</b></div></div>
        <div class="col"><div class="mini-card">Payé<b>${fcfa(ps.reduce((a, p) => a + p.amount, 0))}</b></div></div>
        <div class="col"><div class="mini-card">Solde restant<b class="text-danger">${fcfa(cliBalance(c))}</b></div></div>
      </div>
      <h6>Réservations</h6>
      <table class="table table-sm"><tbody>${rs.map(r => `<tr><td>${roomNum(r.roomId)}</td><td>${fdate(r.arrival)} → ${fdate(r.departure)}</td><td>${fcfa(resTotal(r))}</td><td>${badge(RES_ST, r.status)}</td></tr>`).join('') || '<tr><td class="text-muted">Aucune</td></tr>'}</tbody></table>
      <h6>Paiements</h6>
      <table class="table table-sm"><tbody>${ps.map(p => `<tr><td>${p.ref}</td><td>${fdate(p.date)}</td><td>${methodName(p.methodId)}</td><td class="text-end">${fcfa(p.amount)}</td></tr>`).join('') || '<tr><td class="text-muted">Aucun</td></tr>'}</tbody></table>
      <h6>Factures</h6>
      <table class="table table-sm"><tbody>${is.map(i => `<tr><td>${i.number}</td><td>${fdate(i.date)}</td><td class="text-end">${fcfa(invTotals(i).ttc)}</td><td class="text-end">${fcfa(invBalance(i))}</td></tr>`).join('') || '<tr><td class="text-muted">Aucune</td></tr>'}</tbody></table>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline-primary" data-act="client.statement" data-id="${c.id}"><i class="bi bi-printer"></i> Relevé client</button>
      <button class="btn btn-light" data-bs-dismiss="modal">Fermer</button>
    </div>
  `, 'modal-lg');
};

ACT['client.statement'] = id => {
  const c = DB.find('clients', id), b = DB.s.building;
  const lines = [
    ...DB.s.invoices.filter(i => i.clientId === c.id && i.status !== 'ANNULEE').map(i => ({ d: i.date, l: 'Facture ' + i.number, debit: invTotals(i).ttc, credit: 0 })),
    ...DB.s.payments.filter(p => p.clientId === c.id).map(p => ({ d: p.date, l: (p.amount < 0 ? 'Remboursement ' : 'Paiement ') + p.ref, debit: 0, credit: p.amount }))
  ].sort((a, b) => a.d.localeCompare(b.d));

  let sol = 0;
  printDoc(`
    <div class="doc">
      <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
        <div class="d-flex align-items-start gap-3">
          <img src="assets/logo.jpg" alt="Logo" class="doc-logo" style="width:64px;height:64px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0;flex-shrink:0;">
          <div>
            <h3 class="mb-0 fw-bold">${esc(b.name)}</h3>
            <p class="small text-muted mb-0">${esc(b.address)}, ${esc(b.city)} — ${esc(b.phone)}</p>
          </div>
        </div>
        <div class="text-end">
          <h4 class="mb-0 text-primary">RELEVÉ DE COMPTE CLIENT</h4>
          <small class="text-muted">Édité le ${fdate(TODAY)}</small>
        </div>
      </div>
      <hr class="my-3">
      <p><b>Client :</b> ${esc(c.first + ' ' + c.last)} — ${esc(c.phone)}</p>
      <table class="table table-sm">
        <thead><tr><th>Date</th><th>Opération</th><th class="text-end">Débit</th><th class="text-end">Crédit</th><th class="text-end">Solde</th></tr></thead>
        <tbody>${lines.map(x => { sol += x.debit - x.credit; return `<tr><td>${fdate(x.d)}</td><td>${esc(x.l)}</td><td class="text-end">${x.debit ? fcfa(x.debit) : ''}</td><td class="text-end">${x.credit ? fcfa(x.credit) : ''}</td><td class="text-end">${fcfa(sol)}</td></tr>`; }).join('')}</tbody>
      </table>
      <h5 class="text-end mt-3">Solde restant dû : ${fcfa(sol)}</h5>
    </div>
  `);
};

function pageClients(el) { el.innerHTML = crudHtml(clientsCfg); }

/* ===================== SÉJOURS ===================== */
let STAY_F = 'current';
const stayRows = () => {
  const R = DB.s.reservations;
  return ({
    current: R.filter(r => r.status === 'EN_COURS'),
    arrivals: R.filter(r => r.arrival === TODAY && ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status)),
    departures: R.filter(r => r.departure === TODAY && r.status === 'EN_COURS'),
    upcoming: R.filter(r => ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status) && r.arrival > TODAY),
    history: R.filter(r => ['TERMINEE', 'ANNULEE', 'NO_SHOW'].includes(r.status))
  })[STAY_F].sort((a, b) => b.arrival.localeCompare(a.arrival));
};

const staysCfg = {
  ...resCfg,
  state: { q: '', page: 1 },
  key: 'stays',
  add: false,
  edit: false,
  rows: stayRows,
  toolbar: () => `
    <select class="form-select" data-chg="stayfilter">
      ${[['current', 'Séjours en cours'], ['arrivals', 'Arrivées du jour'], ['departures', 'Départs du jour'], ['upcoming', 'Arrivées à venir'], ['history', 'Historique']].map(o => `<option value="${o[0]}" ${STAY_F === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}
    </select>
  `
};

ACT.stayfilter = v => { STAY_F = v; staysCfg.state.page = 1; renderPage(); };
function pageStays(el) {
  staysCfg.toolbar = () => `
    <select class="form-select" data-chg="stayfilter">
      ${[['current', 'Séjours en cours'], ['arrivals', 'Arrivées du jour'], ['departures', 'Départs du jour'], ['upcoming', 'Arrivées à venir'], ['history', 'Historique']].map(o => `<option value="${o[0]}" ${STAY_F === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}
    </select>
  `;
  el.innerHTML = crudHtml(staysCfg);
}
