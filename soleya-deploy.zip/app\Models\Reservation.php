<?php
// app/Models/Reservation.php

namespace App\Models;

class Reservation extends Model
{
    protected string $table = 'reservations';

    public function allWithDetails(?string $filter = null): array
    {
        $where = "1=1";
        $params = [];

        if ($filter === 'current') {
            $where .= " AND r.status = 'EN_COURS'";
        } elseif ($filter === 'arrivals') {
            $where .= " AND r.arrival_date = CURDATE() AND r.status IN ('CONFIRMEE', 'EN_ATTENTE')";
        } elseif ($filter === 'departures') {
            $where .= " AND r.departure_date = CURDATE() AND r.status = 'EN_COURS'";
        } elseif ($filter === 'upcoming') {
            $where .= " AND r.arrival_date > CURDATE() AND r.status IN ('CONFIRMEE', 'EN_ATTENTE')";
        } elseif ($filter === 'history') {
            $where .= " AND r.status IN ('TERMINEE', 'ANNULEE', 'NO_SHOW')";
        }

        $sql = "
            SELECT 
                r.*,
                c.first_name,
                c.last_name,
                c.phone AS client_phone,
                c.email AS client_email,
                rm.number AS room_name,
                rm.status AS room_status,
                t.name AS room_type_name,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.reservation_id = r.id), 0) AS paid_amount
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            INNER JOIN `rooms` rm ON r.room_id = rm.id
            INNER JOIN `room_types` t ON rm.type_id = t.id
            WHERE {$where}
            ORDER BY r.arrival_date DESC, r.id DESC
        ";

        $rows = self::query($sql, $params);
        foreach ($rows as &$row) {
            $row['room_number'] = $row['room_name'];
            $row['balance_due'] = max(0, (int)$row['total_amount'] - (int)$row['paid_amount']);
            $row['client_full_name'] = $row['first_name'] . ' ' . $row['last_name'];
        }
        return $rows;
    }

    public function findWithDetails(int $id): ?array
    {
        $sql = "
            SELECT 
                r.*,
                c.first_name,
                c.last_name,
                c.phone AS client_phone,
                c.email AS client_email,
                rm.number AS room_name,
                rm.status AS room_status,
                t.name AS room_type_name,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.reservation_id = r.id), 0) AS paid_amount
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            INNER JOIN `rooms` rm ON r.room_id = rm.id
            INNER JOIN `room_types` t ON rm.type_id = t.id
            WHERE r.id = :id
            LIMIT 1
        ";
        $row = self::queryOne($sql, ['id' => $id]);
        if ($row) {
            $row['room_number'] = $row['room_name'];
            $row['balance_due'] = max(0, (int)$row['total_amount'] - (int)$row['paid_amount']);
            $row['client_full_name'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['payments'] = self::query("SELECT * FROM `payments` WHERE `reservation_id` = :id ORDER BY `payment_date` ASC", ['id' => $id]);
        }
        return $row;
    }

    public function checkOverlap(int $roomId, string $arrival, string $departure, ?int $exceptId = null): ?array
    {
        // Intervalle semi-ouvert [arrival, departure[
        // Deux réservations se chevauchent si : arrival < r.departure_date AND r.arrival_date < departure
        $sql = "
            SELECT r.*, c.first_name, c.last_name, rm.number AS room_name
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            INNER JOIN `rooms` rm ON r.room_id = rm.id
            WHERE r.room_id = :room_id
              AND r.status IN ('CONFIRMEE', 'EN_COURS')
              AND :arrival < r.departure_date
              AND r.arrival_date < :departure
        ";
        $params = [
            'room_id' => $roomId,
            'arrival' => $arrival,
            'departure' => $departure
        ];

        if ($exceptId !== null) {
            $sql .= " AND r.id != :except_id";
            $params['except_id'] = $exceptId;
        }

        $sql .= " LIMIT 1";
        return self::queryOne($sql, $params);
    }
}
