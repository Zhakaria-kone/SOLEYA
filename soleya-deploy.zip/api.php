<?php
// api.php - REST API Dispatcher for RESIDENCE MANAGER

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';

// PSR-4 Autoloader pour App\ et Routes\
spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    } elseif (strpos($class, 'Routes\\') === 0) {
        $path = __DIR__ . '/routes/' . str_replace('\\', '/', substr($class, 7)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Helpers\Response;
use Routes\Router;

// Gestion globale des erreurs et exceptions
set_exception_handler(function (\Throwable $e) {
    Response::error($e->getMessage(), 500, [
        'file' => basename($e->getFile()),
        'line' => $e->getLine()
    ]);
});

$router = new Router();

// ===================== AUTH =====================
$router->post('/auth/login', [\App\Controllers\AuthController::class, 'login']);
$router->post('/auth/logout', [\App\Controllers\AuthController::class, 'logout']);
$router->get('/auth/me', [\App\Controllers\AuthController::class, 'me']);

// ===================== DASHBOARD =====================
$router->get('/dashboard', [\App\Controllers\DashboardController::class, 'index']);

// ===================== CHAMBRES =====================
$router->get('/rooms', [\App\Controllers\RoomController::class, 'index']);
$router->get('/rooms/{id}', [\App\Controllers\RoomController::class, 'show']);
$router->post('/rooms', [\App\Controllers\RoomController::class, 'store']);
$router->put('/rooms/{id}', [\App\Controllers\RoomController::class, 'update']);
$router->delete('/rooms/{id}', [\App\Controllers\RoomController::class, 'delete']);
$router->post('/rooms/{id}/clean', [\App\Controllers\RoomController::class, 'setClean']);
$router->post('/rooms/{id}/maintenance', [\App\Controllers\RoomController::class, 'setMaintenance']);

// ===================== RÉSERVATIONS =====================
$router->get('/reservations', [\App\Controllers\ReservationController::class, 'index']);
$router->get('/reservations/{id}', [\App\Controllers\ReservationController::class, 'show']);
$router->post('/reservations', [\App\Controllers\ReservationController::class, 'store']);
$router->post('/reservations/{id}/checkin', [\App\Controllers\ReservationController::class, 'checkin']);
$router->post('/reservations/{id}/checkout', [\App\Controllers\ReservationController::class, 'checkout']);
$router->post('/reservations/{id}/extend', [\App\Controllers\ReservationController::class, 'extend']);
$router->post('/reservations/{id}/cancel', [\App\Controllers\ReservationController::class, 'cancel']);

// ===================== CLIENTS =====================
$router->get('/clients', [\App\Controllers\ClientController::class, 'index']);
$router->get('/clients/{id}', [\App\Controllers\ClientController::class, 'show']);
$router->post('/clients', [\App\Controllers\ClientController::class, 'store']);
$router->put('/clients/{id}', [\App\Controllers\ClientController::class, 'update']);
$router->delete('/clients/{id}', [\App\Controllers\ClientController::class, 'delete']);
$router->get('/clients/{id}/statement', [\App\Controllers\ClientController::class, 'statement']);

// ===================== PAIEMENTS =====================
$router->get('/payments', [\App\Controllers\PaymentController::class, 'index']);
$router->post('/payments', [\App\Controllers\PaymentController::class, 'store']);
$router->get('/payments/{id}/receipt', [\App\Controllers\PaymentController::class, 'receipt']);

// ===================== DÉPENSES =====================
$router->get('/expenses', [\App\Controllers\ExpenseController::class, 'index']);
$router->post('/expenses', [\App\Controllers\ExpenseController::class, 'store']);
$router->post('/expenses/{id}/submit', [\App\Controllers\ExpenseController::class, 'submit']);
$router->post('/expenses/{id}/validate', [\App\Controllers\ExpenseController::class, 'validate']);
$router->post('/expenses/{id}/reject', [\App\Controllers\ExpenseController::class, 'reject']);
$router->post('/expenses/{id}/pay', [\App\Controllers\ExpenseController::class, 'pay']);

// ===================== FOURNISSEURS =====================
$router->get('/suppliers', [\App\Controllers\SupplierController::class, 'index']);
$router->post('/suppliers', [\App\Controllers\SupplierController::class, 'store']);
$router->put('/suppliers/{id}', [\App\Controllers\SupplierController::class, 'update']);
$router->delete('/suppliers/{id}', [\App\Controllers\SupplierController::class, 'delete']);

// ===================== ACHATS =====================
$router->get('/purchases', [\App\Controllers\PurchaseController::class, 'index']);
$router->post('/purchases', [\App\Controllers\PurchaseController::class, 'store']);
$router->post('/purchases/{id}/pay', [\App\Controllers\PurchaseController::class, 'paySupplier']);

// ===================== FACTURATION =====================
$router->get('/invoices', [\App\Controllers\InvoiceController::class, 'index']);
$router->get('/invoices/{id}', [\App\Controllers\InvoiceController::class, 'show']);
$router->post('/invoices', [\App\Controllers\InvoiceController::class, 'store']);
$router->post('/invoices/from-reservation', [\App\Controllers\InvoiceController::class, 'fromReservation']);
$router->post('/invoices/{id}/cancel', [\App\Controllers\InvoiceController::class, 'cancel']);

// ===================== RAPPORTS =====================
$router->get('/reports', [\App\Controllers\ReportController::class, 'index']);

// ===================== PARAMÈTRES =====================
$router->get('/settings', [\App\Controllers\SettingController::class, 'getSettings']);
$router->post('/settings/building', [\App\Controllers\SettingController::class, 'updateBuilding']);
$router->post('/settings/room-types', [\App\Controllers\SettingController::class, 'saveRoomType']);
$router->delete('/settings/room-types/{id}', [\App\Controllers\SettingController::class, 'deleteRoomType']);
$router->post('/settings/payment-methods', [\App\Controllers\SettingController::class, 'savePaymentMethod']);
$router->post('/settings/financial-accounts', [\App\Controllers\SettingController::class, 'saveFinancialAccount']);
$router->post('/settings/users', [\App\Controllers\SettingController::class, 'saveUser']);
$router->delete('/settings/users/{id}', [\App\Controllers\SettingController::class, 'deleteUser']);
$router->post('/settings/permissions', [\App\Controllers\SettingController::class, 'savePermissions']);
$router->get('/settings/audit-logs', [\App\Controllers\SettingController::class, 'getAuditLogs']);
$router->post('/settings/reset-demo-data', [\App\Controllers\SettingController::class, 'resetDemoData']);

$router->dispatch();
