<?php
// app/Controllers/SupplierController.php

namespace App\Controllers;

use App\Models\Supplier;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;

class SupplierController
{
    private Supplier $supplierModel;

    public function __construct()
    {
        $this->supplierModel = new Supplier();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $suppliers = $this->supplierModel->allWithBalances();
        Response::success($suppliers);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $name = trim($params['name'] ?? '');
        $nature = trim($params['nature'] ?? $params['category'] ?? 'Fournitures');
        $phone = trim($params['phone'] ?? '');
        $email = trim($params['email'] ?? '');
        $address = trim($params['address'] ?? '');

        if (empty($name)) {
            Response::error('Le nom du fournisseur est obligatoire.', 422);
        }

        $id = $this->supplierModel->create([
            'name' => $name,
            'nature' => $nature,
            'phone' => $phone,
            'email' => $email,
            'address' => $address
        ]);

        AuditLog::log("Création fournisseur", "Fournisseur {$name} enregistré", $user['name']);

        $supplier = $this->supplierModel->find($id);
        $supplier['purchases_count'] = 0;
        $supplier['total_purchased'] = 0;
        $supplier['total_paid'] = 0;
        $supplier['balance_due'] = 0;

        Response::success($supplier, 'Fournisseur créé avec succès.', 201);
    }

    public function update(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $id = (int)($routeParams['id'] ?? 0);
        $sup = $this->supplierModel->find($id);
        if (!$sup) Response::error('Fournisseur introuvable.', 404);

        $name = trim($params['name'] ?? $sup['name']);
        $nature = trim($params['nature'] ?? $params['category'] ?? $sup['nature'] ?? '');
        $phone = trim($params['phone'] ?? $sup['phone']);
        $email = trim($params['email'] ?? $sup['email']);
        $address = trim($params['address'] ?? $sup['address']);

        $this->supplierModel->update($id, [
            'name' => $name,
            'nature' => $nature,
            'phone' => $phone,
            'email' => $email,
            'address' => $address
        ]);

        AuditLog::log("Modification fournisseur", "Fournisseur {$name} mis à jour", $user['name']);

        Response::success($this->supplierModel->find($id), 'Fournisseur mis à jour.');
    }

    public function delete(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = (int)($routeParams['id'] ?? 0);
        $sup = $this->supplierModel->find($id);
        if (!$sup) Response::error('Fournisseur introuvable.', 404);

        $hasPurchases = Supplier::queryOne("SELECT id FROM `purchases` WHERE `supplier_id` = :id LIMIT 1", ['id' => $id]);
        if ($hasPurchases) {
            Response::error('Impossible de supprimer ce fournisseur car des achats y sont associés.', 422);
        }

        $this->supplierModel->delete($id);
        AuditLog::log("Suppression fournisseur", "Fournisseur {$sup['name']} supprimé", $user['name']);

        Response::success(null, 'Fournisseur supprimé.');
    }
}
