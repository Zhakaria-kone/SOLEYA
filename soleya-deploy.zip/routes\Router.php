<?php
// routes/Router.php

namespace Routes;

use App\Helpers\Response;

class Router
{
    private array $routes = [];

    public function add(string $method, string $path, $handler, array $middleware = []): void
    {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => '/' . trim($path, '/'),
            'handler' => $handler,
            'middleware' => $middleware
        ];
    }

    public function get(string $path, $handler, array $middleware = []): void
    {
        $this->add('GET', $path, $handler, $middleware);
    }

    public function post(string $path, $handler, array $middleware = []): void
    {
        $this->add('POST', $path, $handler, $middleware);
    }

    public function put(string $path, $handler, array $middleware = []): void
    {
        $this->add('PUT', $path, $handler, $middleware);
    }

    public function delete(string $path, $handler, array $middleware = []): void
    {
        $this->add('DELETE', $path, $handler, $middleware);
    }

    public function dispatch(): void
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if ($method === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
        }

        $uri = $this->resolvePath();

        // Extraire payload JSON ou POST
        $body = [];
        $raw = file_get_contents('php://input');
        if (!empty($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $body = $decoded;
            }
        }
        $params = array_merge($_GET, $_POST, $body);

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $route['path']);
            $pattern = "#^{$pattern}$#";

            if (preg_match($pattern, $uri, $matches)) {
                // Exécution des middlewares
                foreach ($route['middleware'] as $mw) {
                    if (is_callable($mw)) {
                        call_user_func($mw);
                    }
                }

                // Paramètres d'URL capturés
                $routeParams = [];
                foreach ($matches as $k => $v) {
                    if (!is_int($k)) {
                        $routeParams[$k] = $v;
                    }
                }

                $handler = $route['handler'];
                if (is_array($handler)) {
                    [$class, $action] = $handler;
                    $controller = new $class();
                    $controller->$action($routeParams, $params);
                } elseif (is_callable($handler)) {
                    call_user_func($handler, $routeParams, $params);
                }
                return;
            }
        }

        Response::error("Route introuvable : [{$method}] {$uri}", 404);
    }

    private function resolvePath(): string
    {
        if (!empty($_GET['route'])) {
            return '/' . trim($_GET['route'], '/');
        }

        if (!empty($_SERVER['PATH_INFO'])) {
            return '/' . trim($_SERVER['PATH_INFO'], '/');
        }

        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);

        // Détection du chemin relatif par rapport au script
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
        $baseDir = rtrim(dirname($script), '/');

        if ($baseDir !== '' && strpos($uri, $baseDir) === 0) {
            $uri = substr($uri, strlen($baseDir));
        }

        if (strpos($uri, '/api.php') === 0) {
            $uri = substr($uri, strlen('/api.php'));
        } elseif (strpos($uri, '/api') === 0) {
            $uri = substr($uri, strlen('/api'));
        }

        $uri = '/' . trim($uri, '/');
        return $uri;
    }
}
