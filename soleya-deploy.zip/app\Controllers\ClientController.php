<?php
// app/Controllers/ClientController.php

namespace App\Controllers;

use App\Models\Client;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;

class ClientController
{
    private Client $clientModel;

    public function __construct()
    {
        $this->clientModel = new Client();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('clients');

        $clients = $this->clientModel->allWithStats();
        Response::success($clients);
    }

    public function show(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('clients');

        $id = (int)($routeParams['id'] ?? 0);
        $client = $this->clientModel->findWithHistory($id);
        if (!$client) {
            Response::error('Client introuvable.', 404);
        }

        Response::success($client);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('clients');

        $firstName = trim($params['first_name'] ?? $params['first'] ?? '');
        $lastName = trim($params['last_name'] ?? $params['last'] ?? '');
        $phone = trim($params['phone'] ?? '');
        $email = trim($params['email'] ?? '');
        $nationality = trim($params['nationality'] ?? 'Ivoirienne');
        $idType = trim($params['id_type'] ?? $params['idType'] ?? 'CNI');
        $idNumber = trim($params['id_number'] ?? $params['id_card_number'] ?? $params['idNumber'] ?? '');
        $address = trim($params['address'] ?? '');
        $notes = trim($params['notes'] ?? '');

        if (empty($firstName) || empty($lastName) || empty($phone)) {
            Response::error('Le prénom, le nom et le téléphone sont obligatoires.', 422);
        }

        $duplicate = $this->clientModel->findDuplicatePhone($phone);
        if ($duplicate) {
            Response::error("Ce numéro de téléphone est déjà attribué à {$duplicate['first_name']} {$duplicate['last_name']}.", 422);
        }

        $id = $this->clientModel->create([
            'first_name' => $firstName,
            'last_name' => $lastName,
            'phone' => $phone,
            'email' => $email,
            'nationality' => $nationality,
            'id_type' => $idType ?: 'CNI',
            'id_number' => $idNumber,
            'address' => $address,
            'notes' => $notes,
            'created_at' => date('Y-m-d')
        ]);

        AuditLog::log("Création client", "Nouveau client #{$id} : {$firstName} {$lastName} ({$phone})", $user['name']);

        $created = $this->clientModel->findWithHistory($id);
        Response::success($created, 'Client enregistré avec succès.', 201);
    }

    public function update(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('clients');

        $id = (int)($routeParams['id'] ?? 0);
        $client = $this->clientModel->find($id);
        if (!$client) {
            Response::error('Client introuvable.', 404);
        }

        $firstName = trim($params['first_name'] ?? $params['first'] ?? $client['first_name']);
        $lastName = trim($params['last_name'] ?? $params['last'] ?? $client['last_name']);
        $phone = trim($params['phone'] ?? $client['phone']);
        $email = trim($params['email'] ?? $client['email']);
        $nationality = trim($params['nationality'] ?? $client['nationality']);
        $idType = trim($params['id_type'] ?? $params['idType'] ?? $client['id_type'] ?? 'CNI');
        $idNumber = trim($params['id_number'] ?? $params['id_card_number'] ?? $params['idNumber'] ?? $client['id_number'] ?? '');
        $address = trim($params['address'] ?? $client['address']);
        $notes = array_key_exists('notes', $params) ? trim((string)$params['notes']) : ($client['notes'] ?? '');

        if (!empty($phone) && $phone !== $client['phone']) {
            $duplicate = $this->clientModel->findDuplicatePhone($phone, $id);
            if ($duplicate) {
                Response::error("Ce numéro de téléphone est déjà attribué à {$duplicate['first_name']} {$duplicate['last_name']}.", 422);
            }
        }

        $this->clientModel->update($id, [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'phone' => $phone,
            'email' => $email,
            'nationality' => $nationality,
            'id_type' => $idType ?: 'CNI',
            'id_number' => $idNumber,
            'address' => $address,
            'notes' => $notes
        ]);

        AuditLog::log("Modification client", "Fiche client mise à jour : {$firstName} {$lastName}", $user['name']);

        $updated = $this->clientModel->findWithHistory($id);
        Response::success($updated, 'Client mis à jour.');
    }

    public function delete(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = (int)($routeParams['id'] ?? 0);
        $client = $this->clientModel->find($id);
        if (!$client) {
            Response::error('Client introuvable.', 404);
        }

        $hasReservations = Client::queryOne("SELECT id FROM `reservations` WHERE `client_id` = :id LIMIT 1", ['id' => $id]);
        if ($hasReservations) {
            Response::error('Impossible de supprimer ce client car des réservations y sont rattachées.', 422);
        }

        $this->clientModel->delete($id);
        AuditLog::log("Suppression client", "Client supprimé : {$client['first_name']} {$client['last_name']}", $user['name']);

        Response::success(null, 'Client supprimé.');
    }

    public function statement(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('clients');

        $id = (int)($routeParams['id'] ?? 0);
        $client = $this->clientModel->findWithHistory($id);
        if (!$client) {
            Response::error('Client introuvable.', 404);
        }

        Response::success($client);
    }
}
