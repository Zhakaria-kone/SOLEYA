/* RESIDENCE MANAGER - Composants UI */
const ACT = {};           // gestionnaires d'actions (data-act)
const CRUD = {};          // configurations de listes CRUD
let CHARTS = [];
let SESSION = (typeof window !== 'undefined' && window.SESSION) ? window.SESSION : null;

document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]');
  if (b && ACT[b.dataset.act]) {
    e.preventDefault();
    ACT[b.dataset.act](b.dataset.id, b);
  }
});

/* ---------- Toasts ---------- */
function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast align-items-center text-bg-${type} border-0 show`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(msg)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

/* ---------- Badges ---------- */
const ROOM_ST = {
  LIBRE: ['Libre', 'free'],
  RESERVEE: ['Réservée', 'reserved'],
  OCCUPEE: ['Occupée', 'occupied'],
  A_NETTOYER: ['À nettoyer', 'clean'],
  MAINTENANCE: ['Maintenance', 'maint']
};
const roomSt = v => ROOM_ST[v] || ROOM_ST.LIBRE;
const RES_ST = {
  EN_ATTENTE: ['En attente', 'warning'],
  CONFIRMEE: ['Confirmée', 'primary'],
  EN_COURS: ['En cours', 'success'],
  TERMINEE: ['Terminée', 'secondary'],
  ANNULEE: ['Annulée', 'danger'],
  NO_SHOW: ['No-show', 'dark']
};
const EXP_ST = {
  BROUILLON: ['Brouillon', 'secondary'],
  EN_ATTENTE_VALIDATION: ['En attente de validation', 'warning'],
  VALIDEE: ['Validée', 'primary'],
  REJETEE: ['Rejetée', 'danger'],
  PAYEE: ['Payée', 'success'],
  PARTIELLEMENT_PAYEE: ['Partiellement payée', 'info'],
  ANNULEE: ['Annulée', 'dark']
};

const badge = (map, v) => {
  const m = map[v] || [v, 'secondary'];
  return `<span class="badge text-bg-${m[1]}">${esc(m[0])}</span>`;
};

const roomBadge = v => {
  const m = roomSt(v);
  return `<span class="rbadge rb-${m[1]}">${m[0]}</span>`;
};

const avatar = name => {
  const parts = String(name || '').trim().split(' ').filter(Boolean);
  const i = (parts[0] ? parts[0][0] : '') + (parts[1] ? parts[1][0] : '');
  const h = [...String(name || '')].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return `<span class="avatar" style="background:hsl(${h} 55% 45%)">${esc(i.toUpperCase() || 'RM')}</span>`;
};

/* ---------- Modales ---------- */
function showModal(html, size = '') {
  $('#modal .modal-dialog').className = 'modal-dialog modal-dialog-centered modal-dialog-scrollable ' + size;
  $('#modalContent').innerHTML = html;
  bootstrap.Modal.getOrCreateInstance($('#modal')).show();
}
function hideModal() {
  bootstrap.Modal.getOrCreateInstance($('#modal')).hide();
}
function confirmBox(msg, ok, label = 'Confirmer', cls = 'btn-primary') {
  showModal(`<div class="modal-body p-4"><p class="mb-4 fs-6">${msg}</p><div class="text-end"><button class="btn btn-light me-2" data-bs-dismiss="modal">Annuler</button><button class="btn ${cls}" id="cfOk">${label}</button></div></div>`, 'modal-sm');
  $('#cfOk').onclick = () => { hideModal(); ok(); };
}

/* Modale de details de chambre avec occupant */
function showRoomDetails(roomId) {
  const r = DB.find('rooms', roomId);
  if (!r) return;
  const occ = getCurrentOccupant(r.id);
  const st = ROOM_ST[r.status] || [r.status, 'free'];
  const t = DB.find('roomTypes', r.typeId) || {};

  let occupantHtml = '';
  if (r.status === 'OCCUPEE' && occ && occ.client) {
    occupantHtml = `
      <div class="alert alert-success d-flex align-items-center gap-3 my-3">
        <div class="fs-2"><i class="bi bi-person-check-fill"></i></div>
        <div>
          <div class="fw-bold fs-6">Occupant actuel : ${esc(occ.client.first + ' ' + occ.client.last)}</div>
          <div class="small"><i class="bi bi-telephone-fill me-1"></i> ${esc(occ.client.phone)} ${occ.client.email ? ' • ' + esc(occ.client.email) : ''}</div>
          <div class="small text-muted"><i class="bi bi-calendar-range me-1"></i> ${esc(occ.period)} (${occ.reservation.nights} nuits)</div>
          <div class="mt-2">
            <span class="badge bg-primary">Séjour en cours</span>
            <span class="badge bg-light text-dark border">Reste à payer : ${fcfa(resBalance(occ.reservation))}</span>
          </div>
        </div>
      </div>
    `;
  } else if (r.status === 'RESERVEE' && occ && occ.client) {
    occupantHtml = `
      <div class="alert alert-info d-flex align-items-center gap-3 my-3">
        <div class="fs-2"><i class="bi bi-calendar-event"></i></div>
        <div>
          <div class="fw-bold fs-6">Prochaine réservation : ${esc(occ.client.first + ' ' + occ.client.last)}</div>
          <div class="small"><i class="bi bi-telephone-fill me-1"></i> ${esc(occ.client.phone)}</div>
          <div class="small text-muted">${esc(occ.period)}</div>
        </div>
      </div>
    `;
  } else if (r.status === 'OCCUPEE') {
    occupantHtml = `
      <div class="alert alert-warning my-3">
        <i class="bi bi-info-circle-fill me-2"></i> Chambre déclarée occupée sans fiche séjour directe.
      </div>
    `;
  } else {
    occupantHtml = `
      <div class="alert alert-light border d-flex align-items-center gap-2 my-3 text-muted">
        <i class="bi bi-check-circle text-success fs-5"></i> Aucun occupant actuellement. Chambre disponible à la réservation.
      </div>
    `;
  }

  const html = `
    <div class="modal-header">
      <h5 class="modal-title d-flex align-items-center gap-2">
        <i class="bi bi-door-open-fill text-primary"></i> ${esc(r.number)}
      </h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <div class="d-flex justify-content-between align-items-center">
        <span class="fs-6 text-muted">Catégorie : <b>${esc(t.name || 'Standard')}</b></span>
        ${roomBadge(r.status)}
      </div>

      ${occupantHtml}

      <div class="row g-2 mb-3">
        <div class="col-4">
          <div class="mini-card text-center py-2">
            <div class="small text-muted">Tarif jour</div>
            <b>${fcfa(r.daily)}</b>
          </div>
        </div>
        <div class="col-4">
          <div class="mini-card text-center py-2">
            <div class="small text-muted">Capacité</div>
            <b>${r.capacity} pers.</b>
          </div>
        </div>
        <div class="col-4">
          <div class="mini-card text-center py-2">
            <div class="small text-muted">Superficie</div>
            <b>${r.area || '—'} m²</b>
          </div>
        </div>
      </div>

      <div class="mb-2">
        <small class="text-muted fw-bold d-block">Équipements inclus :</small>
        <span class="small">${esc(r.equipment || 'Équipements standards')}</span>
      </div>
      <div>
        <small class="text-muted fw-bold d-block">Description :</small>
        <span class="small text-secondary">${esc(r.description || 'Aucune description spécifique.')}</span>
      </div>
    </div>
    <div class="modal-footer d-flex justify-content-between flex-wrap gap-2">
      <button type="button" class="btn btn-outline-danger" data-act="crud" data-key="rooms" data-op="del" data-id="${r.id}">
        <i class="bi bi-trash"></i> Supprimer la chambre
      </button>
      <div class="d-flex gap-2">
        ${r.status === 'A_NETTOYER' ? `<button class="btn btn-success" data-act="room.clean" data-id="${r.id}"><i class="bi bi-check2"></i> Valider ménage</button>` : ''}
        <button class="btn btn-primary" data-act="crud" data-key="rooms" data-op="edit" data-id="${r.id}">
          <i class="bi bi-pencil"></i> Modifier la chambre
        </button>
        <button class="btn btn-light" data-bs-dismiss="modal">Fermer</button>
      </div>
    </div>
  `;
  showModal(html, 'modal-md');
}
ACT['room.details'] = id => showRoomDetails(id);

/* ---------- Formulaires ---------- */
function linesRow(l = {}) {
  return `<div class="row g-1 mb-1 line"><div class="col-6"><input class="form-control form-control-sm" data-k="label" placeholder="Désignation" value="${esc(l.label || '')}" required></div><div class="col-2"><input type="number" class="form-control form-control-sm" data-k="qty" value="${l.qty ?? 1}" min="1"></div><div class="col-3"><input type="number" class="form-control form-control-sm" data-k="price" value="${l.price ?? 0}"></div><div class="col-1"><button type="button" class="btn btn-sm btn-outline-danger w-100" data-rm="1">×</button></div></div>`;
}

function fieldHtml(f, v) {
  const id = 'f_' + f.k, req = f.required ? 'required' : '';
  const opts = typeof f.options === 'function' ? f.options() : f.options;
  let inp;
  if (f.type === 'select') inp = `<select class="form-select" name="${f.k}" id="${id}" ${req}>${f.empty ? '<option value="">— Choisir —</option>' : ''}${opts.map(o => `<option value="${esc(o.v)}" ${String(o.v) === String(v ?? '') ? 'selected' : ''}>${esc(o.l)}</option>`).join('')}</select>`;
  else if (f.type === 'textarea') inp = `<textarea class="form-control" name="${f.k}" id="${id}" rows="2">${esc(v)}</textarea>`;
  else if (f.type === 'check') inp = `<div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="${f.k}" id="${id}" ${v ? 'checked' : ''}></div>`;
  else if (f.type === 'info') inp = `<div class="alert alert-light border mb-0 py-2" id="${id}"></div>`;
  else if (f.type === 'lines') inp = `<div class="lines" id="${id}">${(v && v.length ? v : [{}]).map(linesRow).join('')}</div><button type="button" class="btn btn-sm btn-outline-primary mt-1" data-addline="${id}"><i class="bi bi-plus"></i> Ajouter une ligne</button>`;
  else inp = `<input class="form-control" type="${f.type || 'text'}" name="${f.k}" id="${id}" value="${esc(v ?? '')}" ${req} ${f.min != null ? `min="${f.min}"` : ''} ${f.readonly ? 'readonly' : ''} ${f.type === 'number' ? 'step="1"' : ''}>`;
  return `<div class="col-md-${f.col || 6}"><label class="form-label small fw-semibold" for="${id}">${f.label}${f.required ? ' *' : ''}</label>${inp}</div>`;
}

function openForm({ title, fields, values = {}, onSubmit, onInput, submit = 'Enregistrer', size = 'modal-lg' }) {
  showModal(`<form id="mform" novalidate><div class="modal-header"><h5 class="modal-title">${title}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div id="mErr"></div><div class="row g-3">${fields.map(f => fieldHtml(f, values[f.k])).join('')}</div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary">${submit}</button></div></form>`, size);
  const form = $('#mform');
  const collect = () => {
    const d = {};
    fields.forEach(f => {
      if (f.type === 'info') return;
      if (f.type === 'lines') d[f.k] = $$('.line', form).map(r => ({ label: $('[data-k=label]', r).value.trim(), qty: Number($('[data-k=qty]', r).value) || 0, price: Number($('[data-k=price]', r).value) || 0 })).filter(l => l.label);
      else if (f.type === 'check') d[f.k] = form.elements[f.k].checked;
      else if (f.type === 'number') d[f.k] = Number(form.elements[f.k].value) || 0;
      else if (f.type === 'select' && f.numeric && form.elements[f.k].value !== '') d[f.k] = Number(form.elements[f.k].value);
      else d[f.k] = form.elements[f.k].value.trim();
    });
    return d;
  };
  form.addEventListener('click', e => {
    if (e.target.dataset.addline) { $('#' + e.target.dataset.addline).insertAdjacentHTML('beforeend', linesRow()); }
    const rm = e.target.closest('[data-rm]'); if (rm && $$('.line', form).length > 1) { rm.closest('.line').remove(); onInput && onInput(form, collect()); }
  });
  const upd = () => onInput && onInput(form, collect());
  form.addEventListener('input', upd);
  form.addEventListener('change', upd);
  upd();
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!form.checkValidity()) { form.classList.add('was-validated'); return; }
    const err = onSubmit(collect());
    if (err) { $('#mErr').innerHTML = `<div class="alert alert-danger">${err}</div>`; return; }
    hideModal();
  });
}

/* ---------- Listes CRUD generiques ---------- */
function crudBody(cfg) {
  const st = cfg.state;
  let rows = cfg.rows();
  if (cfg.filter) rows = rows.filter(cfg.filter);
  if (st.q) {
    const q = st.q.toLowerCase();
    rows = rows.filter(r => cfg.search(r).toLowerCase().includes(q));
  }
  const per = cfg.perPage || 10, pages = Math.max(1, Math.ceil(rows.length / per));
  st.page = Math.min(st.page, pages);
  const slice = rows.slice((st.page - 1) * per, st.page * per);
  const act = r => {
    let h = (cfg.actions ? cfg.actions(r) : '');
    if (cfg.edit !== false) h += `<button class="btn btn-sm btn-outline-secondary" title="Modifier" data-act="crud" data-key="${cfg.key}" data-op="edit" data-id="${r.id}"><i class="bi bi-pencil"></i></button> `;
    if (cfg.remove && (!cfg.canRemove || cfg.canRemove(r))) h += `<button class="btn btn-sm btn-outline-danger" title="Supprimer" data-act="crud" data-key="${cfg.key}" data-op="del" data-id="${r.id}"><i class="bi bi-trash"></i></button>`;
    return h;
  };
  let h = slice.map(r => `<tr>${cfg.cols.map(c => `<td class="${c.cls || ''}">${c.f(r)}</td>`).join('')}<td class="text-end text-nowrap">${act(r)}</td></tr>`).join('');
  if (!slice.length) h = `<tr><td colspan="${cfg.cols.length + 1}" class="text-center text-muted py-4">Aucun enregistrement</td></tr>`;
  h += `<tr class="pager-row"><td colspan="${cfg.cols.length + 1}"><div class="d-flex justify-content-between align-items-center"><small class="text-muted">${rows.length} élément(s)</small><div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" ${st.page <= 1 ? 'disabled' : ''} data-act="crud" data-key="${cfg.key}" data-op="prev"><i class="bi bi-chevron-left"></i></button><span class="btn btn-outline-secondary disabled">${st.page} / ${pages}</span><button class="btn btn-outline-secondary" ${st.page >= pages ? 'disabled' : ''} data-act="crud" data-key="${cfg.key}" data-op="next"><i class="bi bi-chevron-right"></i></button></div></div></td></tr>`;
  return h;
}

function crudHtml(cfg) {
  CRUD[cfg.key] = cfg;
  cfg.state = cfg.state || { q: '', page: 1 };
  return `
    <div class="card-box">
      <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
        <div class="d-flex gap-2 flex-wrap align-items-center">
          <div class="input-group search-box">
            <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
            <input class="form-control" placeholder="Rechercher…" data-crud-search="${cfg.key}" value="${esc(cfg.state.q)}">
          </div>
          ${cfg.toolbar ? cfg.toolbar() : ''}
        </div>
        ${cfg.add !== false ? `<button class="btn btn-primary" data-act="crud" data-key="${cfg.key}" data-op="add"><i class="bi bi-plus-lg"></i> ${cfg.addLabel || 'Ajouter'}</button>` : ''}
      </div>
      <div class="table-responsive">
        <table class="table table-modern align-middle">
          <thead>
            <tr>${cfg.cols.map(c => `<th>${c.l}</th>`).join('')}<th></th></tr>
          </thead>
          <tbody id="cb-${cfg.key}">${crudBody(cfg)}</tbody>
        </table>
      </div>
    </div>
  `;
}

const refreshCrud = key => { const c = CRUD[key]; const b = $('#cb-' + key); if (b) b.innerHTML = crudBody(c); };

document.addEventListener('input', e => {
  const k = e.target.dataset.crudSearch;
  if (k) {
    CRUD[k].state.q = e.target.value;
    CRUD[k].state.page = 1;
    refreshCrud(k);
  }
});

ACT.crud = (id, b) => {
  const cfg = CRUD[b.dataset.key], op = b.dataset.op;
  if (op === 'prev') { cfg.state.page--; return refreshCrud(cfg.key); }
  if (op === 'next') { cfg.state.page++; return refreshCrud(cfg.key); }
  if (op === 'del') {
    const isRoom = cfg.coll === 'rooms';
    const roomObj = isRoom ? DB.find('rooms', id) : null;
    const confirmPrompt = isRoom
      ? `Êtes-vous sûr de vouloir supprimer définitivement la chambre "${roomObj ? roomObj.number : id}" ?<br><small class="text-muted d-block mt-1">Cette action retirera la chambre du parc et diminuera le nombre total de chambres de l'établissement.</small>`
      : 'Supprimer cet élément ?';

    return confirmBox(confirmPrompt, async () => {
      try {
        if (typeof API !== 'undefined') {
          if (cfg.coll === 'rooms') await API.deleteRoom(id);
          else if (cfg.coll === 'clients') await API.deleteClient(id);
          else if (cfg.coll === 'suppliers') await API.deleteSupplier(id);
          else if (cfg.coll === 'roomTypes') await API.deleteRoomType(id);
          else if (cfg.coll === 'users') await API.deleteUser(id);
        }
        if (isRoom) {
          DB.s.reservations = DB.s.reservations.filter(r => r.roomId !== Number(id));
        }
        DB.del(cfg.coll, id);
        DB.log(`Suppression ${cfg.singular} #${id}`);
        toast(isRoom ? `Chambre "${roomObj ? roomObj.number : id}" supprimée avec succès` : 'Élément supprimé avec succès');
        renderPage();
      } catch (e) {
        console.warn('API del error:', e);
        toast(e.message || 'Impossible de supprimer cet élément.', 'danger');
      }
    }, isRoom ? 'Supprimer la chambre' : 'Supprimer', 'btn-danger');
  }

  const cur = op === 'edit' ? DB.find(cfg.coll, id) : null;
  openForm({
    title: (cur ? 'Modifier ' : 'Nouveau / nouvelle ') + cfg.singular,
    fields: cfg.fields,
    values: cur || (cfg.defaults ? cfg.defaults() : {}),
    onInput: cfg.onInput,
    onSubmit: async d => {
      const err = cfg.validate && cfg.validate(d, cur);
      if (err) return err;
      if (cfg.before) cfg.before(d, cur);

      try {
        if (typeof API !== 'undefined') {
          if (cur) {
            if (cfg.coll === 'rooms') await API.updateRoom(cur.id, { number: d.number, type_id: d.typeId, room_type_id: d.typeId, capacity: d.capacity, area: d.area, daily_rate: d.daily, weekly_rate: d.weekly, monthly_rate: d.monthly, status: d.status, equipment: d.equipment, description: d.description });
            else if (cfg.coll === 'clients') await API.updateClient(cur.id, { first_name: d.first, last_name: d.last, phone: d.phone, email: d.email, address: d.address, nationality: d.nationality, id_type: d.idType, id_number: d.idNumber, notes: d.notes });
            else if (cfg.coll === 'suppliers') await API.updateSupplier(cur.id, { name: d.name, phone: d.phone, email: d.email, address: d.address, nature: d.nature, category: d.nature });
            else if (cfg.coll === 'roomTypes') await API.saveRoomType({ id: cur.id, name: d.name, capacity: d.capacity, daily_rate: d.daily, weekly_rate: d.weekly, monthly_rate: d.monthly });
            else if (cfg.coll === 'methods') await API.savePaymentMethod({ id: cur.id, name: d.name, is_active: d.active });
            else if (cfg.coll === 'accounts') await API.saveFinancialAccount({ id: cur.id, name: d.name, opening_balance: d.opening, is_active: d.active });
            else if (cfg.coll === 'users') await API.saveUser({ id: cur.id, name: d.name, email: d.email, password: d.password, role: d.role, is_active: d.active });
          } else {
            let srvObj = null;
            if (cfg.coll === 'rooms') srvObj = await API.createRoom({ number: d.number, type_id: d.typeId, room_type_id: d.typeId, new_category_name: d.newCategoryName, capacity: d.capacity, area: d.area, daily_rate: d.daily, weekly_rate: d.weekly, monthly_rate: d.monthly, status: d.status || 'LIBRE', equipment: d.equipment, description: d.description });
            else if (cfg.coll === 'clients') srvObj = await API.createClient({ first_name: d.first, last_name: d.last, phone: d.phone, email: d.email, address: d.address, nationality: d.nationality, id_type: d.idType, id_number: d.idNumber, notes: d.notes });
            else if (cfg.coll === 'reservations') srvObj = await API.createReservation({ client_id: d.clientId, room_id: d.roomId, arrival_date: d.arrival, departure_date: d.departure, guests: d.guests, rate_applied: d.rate, discount_amount: d.discount, extra_amount: d.extra, deposit_amount: d.deposit, status: d.status, notes: d.notes });
            else if (cfg.coll === 'payments') srvObj = await API.createPayment({ reservation_id: d.resId, client_id: d.clientId, amount: d.amount, payment_method_id: d.methodId, financial_account_id: d.accountId, transaction_ref: d.txRef, payment_date: d.date, payment_time: d.time, type: d.type });
            else if (cfg.coll === 'expenses') srvObj = await API.createExpense({ label: d.label, description: d.label, amount: d.amount, category: d.category, expense_date: d.date, supplier_id: d.supplierId, room_id: d.roomId, status: d.status, payment_method_id: d.methodId, financial_account_id: d.accountId });
            else if (cfg.coll === 'suppliers') srvObj = await API.createSupplier({ name: d.name, phone: d.phone, email: d.email, address: d.address, nature: d.nature, category: d.nature });
            else if (cfg.coll === 'purchases') srvObj = await API.createPurchase({ supplier_id: d.supplierId, purchase_date: d.date, kind: d.kind, terms: d.terms, paid_amount: purCfg._pay || 0, items: d.items });
            else if (cfg.coll === 'invoices') srvObj = await API.createInvoice({ type: d.type, client_id: d.clientId, issue_date: d.date, tax_rate: d.taxRate, notes: d.terms, items: d.items });
            else if (cfg.coll === 'roomTypes') srvObj = await API.saveRoomType({ name: d.name, capacity: d.capacity, daily_rate: d.daily, weekly_rate: d.weekly, monthly_rate: d.monthly });
            else if (cfg.coll === 'methods') srvObj = await API.savePaymentMethod({ name: d.name, is_active: d.active });
            else if (cfg.coll === 'accounts') srvObj = await API.saveFinancialAccount({ name: d.name, opening_balance: d.opening, is_active: d.active });
            else if (cfg.coll === 'users') srvObj = await API.saveUser({ name: d.name, email: d.email, password: d.password, role: d.role, is_active: d.active });

            if (srvObj && srvObj.id) {
              d.id = Number(srvObj.id);
              if (cfg.coll === 'rooms') {
                d.typeId = Number(srvObj.type_id || d.typeId);
                d.daily = Number(srvObj.daily_rate ?? d.daily);
                d.weekly = Number(srvObj.weekly_rate ?? d.weekly);
                d.monthly = Number(srvObj.monthly_rate ?? d.monthly);
                d.status = srvObj.status || 'LIBRE';
              }
            }
          }
        }
      } catch (apiErr) {
        console.warn('API CRUD error:', apiErr);
        toast(apiErr.message || 'Erreur lors de l’enregistrement.', 'danger');
        return;
      }

      if (cur) {
        DB.upd(cfg.coll, cur.id, d);
        DB.log(`Modification ${cfg.singular} #${cur.id}`);
      } else {
        const o = DB.add(cfg.coll, d);
        DB.log(`Création ${cfg.singular} #${o.id}`);
        if (cfg.after) cfg.after(o);
      }
      if (cur && cfg.after) cfg.after(cur);
      toast('Enregistré avec succès');
      renderPage();
    }
  });
};

/* ---------- Graphiques ---------- */
function mkChart(el, conf) {
  if (typeof Chart === 'undefined') {
    if (el && el.parentElement) {
      el.parentElement.innerHTML = '<div class="text-muted text-center py-4 small"><i class="bi bi-graph-up me-1"></i>Graphique (chargement...)</div>';
    }
    return null;
  }
  try {
    const c = new Chart(el, conf);
    CHARTS.push(c);
    return c;
  } catch (e) {
    console.warn('Erreur initialisation graphique:', e);
    return null;
  }
}
function killCharts() {
  CHARTS.forEach(c => {
    try { if (c && typeof c.destroy === 'function') c.destroy(); } catch (e) {}
  });
  CHARTS = [];
}

/* ---------- Impression ---------- */
function printDoc(html) { $('#printZone').innerHTML = html; setTimeout(() => window.print(), 150); }

/* ---------- Export CSV ---------- */
function exportCsv(name, cols, rows) {
  const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = '\ufeff' + [cols, ...rows].map(r => r.map(q).join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = name + '.csv';
  a.click();
}
