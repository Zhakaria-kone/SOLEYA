<?php
// app/Controllers/RoomController.php

namespace App\Controllers;

use App\Models\Room;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class RoomController
{
    private Room $roomModel;

    public function __construct()
    {
        $this->roomModel = new Room();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $rooms = $this->roomModel->allWithDetails();
        Response::success($rooms);
    }

    public function show(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $id = (int)($routeParams['id'] ?? 0);
        $room = $this->roomModel->find($id);
        if (!$room) {
            Response::error('Chambre introuvable.', 404);
        }

        $room['current_occupant'] = $this->roomModel->getCurrentOccupant($id);
        $room['upcoming_reservation'] = $this->roomModel->getUpcomingReservation($id);

        Response::success($room);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $number = trim($params['number'] ?? '');
        $roomTypeId = (int)($params['type_id'] ?? $params['room_type_id'] ?? 0);
        $newTypeName = trim((string)($params['new_type_name'] ?? $params['new_category_name'] ?? ''));

        // Création à la volée d'une nouvelle catégorie si demandée
        if ($roomTypeId <= 0 && !empty($newTypeName)) {
            $existingType = Room::queryOne("SELECT id FROM `room_types` WHERE LOWER(`name`) = LOWER(:name) LIMIT 1", ['name' => $newTypeName]);
            if ($existingType) {
                $roomTypeId = (int)$existingType['id'];
            } else {
                $roomTypeId = (new \App\Models\RoomType())->create([
                    'name' => $newTypeName,
                    'daily_rate' => max(0, (int)($params['daily_rate'] ?? $params['daily'] ?? 25000)),
                    'weekly_rate' => max(0, (int)($params['weekly_rate'] ?? $params['weekly'] ?? 150000)),
                    'monthly_rate' => max(0, (int)($params['monthly_rate'] ?? $params['monthly'] ?? 500000)),
                    'capacity' => max(1, (int)($params['capacity'] ?? 2))
                ]);
            }
        }

        $dailyRate = max(0, (int)($params['daily_rate'] ?? $params['daily'] ?? 0));
        $weeklyRate = max(0, (int)($params['weekly_rate'] ?? $params['weekly'] ?? 0));
        $monthlyRate = max(0, (int)($params['monthly_rate'] ?? $params['monthly'] ?? 0));

        // Si aucun tarif personnalisé n'est saisi, récupérer les tarifs par défaut du type
        if ($dailyRate <= 0 && $roomTypeId > 0) {
            $rt = (new \App\Models\RoomType())->find($roomTypeId);
            if ($rt) {
                $dailyRate = (int)($rt['daily_rate'] ?? 25000);
                if ($weeklyRate <= 0) $weeklyRate = (int)($rt['weekly_rate'] ?? ($dailyRate * 6));
                if ($monthlyRate <= 0) $monthlyRate = (int)($rt['monthly_rate'] ?? ($dailyRate * 20));
            }
        }

        if ($weeklyRate <= 0) $weeklyRate = $dailyRate * 6;
        if ($monthlyRate <= 0) $monthlyRate = $dailyRate * 20;

        $capacity = max(1, (int)($params['capacity'] ?? 2));
        $area = isset($params['area']) && $params['area'] !== '' ? max(0, (int)$params['area']) : null;
        $rawStatus = $params['status'] ?? 'LIBRE';
        if ($rawStatus === 'DISPONIBLE' || empty($rawStatus)) {
            $rawStatus = 'LIBRE';
        }
        $status = in_array($rawStatus, ['LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE'], true)
            ? $rawStatus
            : 'LIBRE';
        $equipment = trim($params['equipment'] ?? '');
        $description = trim($params['description'] ?? '');

        if (empty($number) || $roomTypeId <= 0 || $dailyRate <= 0) {
            Response::error('Veuillez renseigner le nom/numéro, la catégorie et le tarif journalier de la chambre.', 422);
        }

        // Vérifier l'unicité du nom/numéro de chambre
        $existing = Room::queryOne("SELECT id FROM `rooms` WHERE `number` = :num LIMIT 1", ['num' => $number]);
        if ($existing) {
            Response::error("Une chambre portant le nom '{$number}' existe déjà.", 422);
        }

        $id = $this->roomModel->create([
            'number' => $number,
            'type_id' => $roomTypeId,
            'capacity' => $capacity,
            'area' => $area,
            'daily_rate' => $dailyRate,
            'weekly_rate' => $weeklyRate,
            'monthly_rate' => $monthlyRate,
            'status' => $status,
            'equipment' => $equipment,
            'description' => $description
        ]);

        AuditLog::log("Création chambre", "Ajout de la chambre {$number} ({$dailyRate} FCFA/nuit)", $user['name']);

        $created = $this->roomModel->findWithDetails($id);
        Response::success($created, 'Chambre créée avec succès.', 201);
    }

    public function update(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $id = (int)($routeParams['id'] ?? 0);
        $room = $this->roomModel->find($id);
        if (!$room) {
            Response::error('Chambre introuvable.', 404);
        }

        $number = trim($params['number'] ?? $room['number']);
        $roomTypeId = (int)($params['type_id'] ?? $params['room_type_id'] ?? $room['type_id']);
        $capacity = max(1, (int)($params['capacity'] ?? $room['capacity']));
        $area = array_key_exists('area', $params) ? ($params['area'] !== '' ? max(0, (int)$params['area']) : null) : $room['area'];
        $dailyRate = max(0, (int)($params['daily_rate'] ?? $params['daily'] ?? $room['daily_rate']));
        $weeklyRate = max(0, (int)($params['weekly_rate'] ?? $params['weekly'] ?? $room['weekly_rate']));
        $monthlyRate = max(0, (int)($params['monthly_rate'] ?? $params['monthly'] ?? $room['monthly_rate']));
        $rawStatus = $params['status'] ?? $room['status'];
        if ($rawStatus === 'DISPONIBLE' || empty($rawStatus)) {
            $rawStatus = 'LIBRE';
        }
        $status = in_array($rawStatus, ['LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE'], true)
            ? $rawStatus
            : 'LIBRE';
        $equipment = array_key_exists('equipment', $params) ? trim((string)$params['equipment']) : $room['equipment'];
        $description = array_key_exists('description', $params) ? trim((string)$params['description']) : $room['description'];

        $this->roomModel->update($id, [
            'number' => $number,
            'type_id' => $roomTypeId,
            'capacity' => $capacity,
            'area' => $area,
            'daily_rate' => $dailyRate,
            'weekly_rate' => $weeklyRate,
            'monthly_rate' => $monthlyRate,
            'status' => $status,
            'equipment' => $equipment,
            'description' => $description
        ]);

        AuditLog::log("Modification chambre", "Mise à jour de la chambre {$number}", $user['name']);

        $updated = $this->roomModel->findWithDetails($id);

        Response::success($updated, 'Chambre mise à jour.');
    }

    public function delete(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = (int)($routeParams['id'] ?? 0);
        $room = $this->roomModel->find($id);
        if (!$room) {
            Response::error('Chambre introuvable.', 404);
        }

        \App\Models\Model::beginTransaction();
        try {
            // Supprimer les paiements et factures liés aux réservations de cette chambre
            $resIds = \App\Models\Model::query("SELECT id FROM `reservations` WHERE `room_id` = :id", ['id' => $id]);
            foreach ($resIds as $row) {
                $rId = (int)$row['id'];
                \App\Models\Model::execute("DELETE FROM `payments` WHERE `reservation_id` = :rid", ['rid' => $rId]);
                \App\Models\Model::execute("DELETE FROM `invoice_items` WHERE `invoice_id` IN (SELECT id FROM `invoices` WHERE `reservation_id` = :rid)", ['rid' => $rId]);
                \App\Models\Model::execute("DELETE FROM `invoices` WHERE `reservation_id` = :rid", ['rid' => $rId]);
            }
            // Supprimer les réservations de cette chambre
            \App\Models\Model::execute("DELETE FROM `reservations` WHERE `room_id` = :id", ['id' => $id]);

            // Détacher les dépenses liées à cette chambre
            \App\Models\Model::execute("UPDATE `expenses` SET `room_id` = NULL WHERE `room_id` = :id", ['id' => $id]);

            // Supprimer définitivement la chambre
            $this->roomModel->delete($id);

            \App\Models\Model::commit();
            AuditLog::log("Suppression chambre", "Suppression définitive de la chambre {$room['number']} ({$room['status']})", $user['name']);

            Response::success(null, "Chambre '{$room['number']}' supprimée avec succès.");
        } catch (\Throwable $e) {
            \App\Models\Model::rollBack();
            Response::error('Erreur lors de la suppression de la chambre : ' . $e->getMessage(), 500);
        }
    }

    public function setClean(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $id = (int)($routeParams['id'] ?? 0);
        $room = $this->roomModel->find($id);
        if (!$room) {
            Response::error('Chambre introuvable.', 404);
        }

        $this->roomModel->update($id, ['status' => 'LIBRE']);
        $this->roomModel->syncStatus($id);
        $updated = $this->roomModel->find($id);
        AuditLog::log("Nettoyage validé", "La chambre {$room['number']} est désormais prête et disponible", $user['name']);

        Response::success(['id' => $id, 'status' => $updated['status'] ?: 'LIBRE'], 'Chambre validée propre et disponible.');
    }

    public function setMaintenance(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('rooms');

        $id = (int)($routeParams['id'] ?? 0);
        $room = $this->roomModel->find($id);
        if (!$room) {
            Response::error('Chambre introuvable.', 404);
        }

        $newStatus = ($room['status'] === 'MAINTENANCE') ? 'LIBRE' : 'MAINTENANCE';
        $this->roomModel->update($id, ['status' => $newStatus]);
        if ($newStatus === 'LIBRE') {
            $this->roomModel->syncStatus($id);
            $updated = $this->roomModel->find($id);
            $newStatus = $updated['status'] ?: 'LIBRE';
        }

        $action = ($newStatus === 'MAINTENANCE') ? 'mise en maintenance' : 'remise en service';
        AuditLog::log("Statut maintenance", "Chambre {$room['number']} : {$action}", $user['name']);

        Response::success(['id' => $id, 'status' => $newStatus], "Chambre {$action}.");
    }
}
