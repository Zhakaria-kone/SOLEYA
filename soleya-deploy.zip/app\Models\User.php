<?php
// app/Models/User.php

namespace App\Models;

class User extends Model
{
    protected string $table = 'users';

    public function findByEmail(string $email): ?array
    {
        return self::queryOne("SELECT * FROM `users` WHERE `email` = :email LIMIT 1", ['email' => $email]);
    }

    public function getPermissions(string $role): array
    {
        $rows = self::query("SELECT `module` FROM `role_permissions` WHERE `role` = :role", ['role' => $role]);
        return array_column($rows, 'module');
    }

    public function setPermissions(string $role, array $modules): void
    {
        self::execute("DELETE FROM `role_permissions` WHERE `role` = :role", ['role' => $role]);
        foreach ($modules as $mod) {
            self::execute("INSERT INTO `role_permissions` (`role`, `module`) VALUES (:role, :mod)", [
                'role' => $role,
                'mod' => $mod
            ]);
        }
    }
}
