<?php
// app/Models/Invoice.php

namespace App\Models;

class Invoice extends Model
{
    protected string $table = 'invoices';

    public function allWithDetails(?string $from = null, ?string $to = null): array
    {
        $where = "1=1";
        $params = [];

        if ($from && $to) {
            $where .= " AND i.issue_date BETWEEN :from AND :to";
            $params['from'] = $from;
            $params['to'] = $to;
        }

        $sql = "
            SELECT 
                i.*,
                c.first_name,
                c.last_name,
                c.phone AS client_phone,
                c.email AS client_email,
                c.address AS client_address,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.invoice_id = i.id), 0) AS paid_amount
            FROM `invoices` i
            INNER JOIN `clients` c ON i.client_id = c.id
            WHERE {$where}
            ORDER BY i.issue_date DESC, i.id DESC
        ";

        $rows = self::query($sql, $params);
        foreach ($rows as &$row) {
            $row['client_full_name'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['items'] = self::query("SELECT * FROM `invoice_items` WHERE `invoice_id` = :id", ['id' => $row['id']]);
            if ($row['status'] === 'ANNULEE' || $row['type'] === 'AVOIR') {
                $row['balance_due'] = 0;
            } else {
                $row['balance_due'] = max(0, (int)$row['total_ttc'] - (int)$row['paid_amount']);
            }
        }
        return $rows;
    }

    public function findWithItems(int $id): ?array
    {
        $sql = "
            SELECT 
                i.*,
                c.first_name,
                c.last_name,
                c.phone AS client_phone,
                c.email AS client_email,
                c.address AS client_address,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.invoice_id = i.id), 0) AS paid_amount
            FROM `invoices` i
            INNER JOIN `clients` c ON i.client_id = c.id
            WHERE i.id = :id
            LIMIT 1
        ";
        $invoice = self::queryOne($sql, ['id' => $id]);
        if ($invoice) {
            $invoice['client_full_name'] = $invoice['first_name'] . ' ' . $invoice['last_name'];
            $invoice['items'] = self::query("SELECT * FROM `invoice_items` WHERE `invoice_id` = :id", ['id' => $id]);
            if ($invoice['status'] === 'ANNULEE' || $invoice['type'] === 'AVOIR') {
                $invoice['balance_due'] = 0;
            } else {
                $invoice['balance_due'] = max(0, (int)$invoice['total_ttc'] - (int)$invoice['paid_amount']);
            }
        }
        return $invoice;
    }

    public function nextNumber(string $type = 'FACTURE'): string
    {
        $prefixes = [
            'FACTURE' => 'FAC',
            'ACOMPTE' => 'AC',
            'AVOIR' => 'AV'
        ];
        $prefix = ($prefixes[$type] ?? 'FAC') . '-' . date('Y') . '-';
        $row = self::queryOne("SELECT COUNT(*) AS total FROM `invoices` WHERE `number` LIKE :prefix", ['prefix' => "{$prefix}%"]);
        $next = ((int)$row['total']) + 1;
        return $prefix . str_pad((string)$next, 3, '0', STR_PAD_LEFT);
    }

    public function addItems(int $invoiceId, array $items): void
    {
        foreach ($items as $item) {
            $label = trim($item['label'] ?? '');
            $qty = (int)($item['qty'] ?? 1);
            $price = (int)($item['price'] ?? 0);
            if ($label !== '') {
                self::execute("INSERT INTO `invoice_items` (`invoice_id`, `label`, `quantity`, `unit_price`, `total_price`) VALUES (:iid, :lbl, :qty, :pr, :tot)", [
                    'iid' => $invoiceId,
                    'lbl' => $label,
                    'qty' => $qty,
                    'pr' => $price,
                    'tot' => $qty * $price
                ]);
            }
        }
    }
}
