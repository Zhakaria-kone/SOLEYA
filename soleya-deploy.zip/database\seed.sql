-- database/seed.sql
-- RESIDENCE MANAGER - Données initiales et de démonstration complètes

USE `residence_manager`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Résidence
INSERT INTO `building` (`id`, `name`, `address`, `city`, `phone`, `email`, `description`, `manager`, `billing`, `tax_rate`, `terms`)
VALUES (1, 'Résidence Prestige', 'Cocody, Riviera Palmeraie', 'Abidjan', '+225 07 00 00 00 00', 'contact@residence-prestige.ci', 'Résidence meublée haut de gamme offrant confort, discrétion et prestations de premier ordre.', 'Administrateur', 'RCCM CI-ABJ-2024-B-00000 — Compte contribuable 0000000A', 0, 'Paiement à réception de facture.');

-- 2. Utilisateurs
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `is_active`) VALUES
(1, 'Administrateur', 'admin@residence.ci', '$2y$10$vW3NqTElq8sZKQiPjxpKOOmgkJEpbQCHVKbhZfGIqScN5pYaznCtG', 'admin', 1),
(2, 'Awa Gestionnaire', 'gestion@residence.ci', '$2y$10$a5G42gOSKuFzd159diXfuejphKoWIlHIC.//t6DjIC7mqOAVQXmgK', 'manager', 1),
(3, 'Koffi Réception', 'reception@residence.ci', '$2y$10$VnvQzVrpSnhSV9IDAXLEJuxSesQjFZo8qMvD4T8XetJFVW67xIOF6', 'reception', 1),
(4, 'Mariam Comptable', 'compta@residence.ci', '$2y$10$mRq36NjxM12G7sFWHMfNcuiZKqVpvLsJZJBERRh.2bcwJ0iFy7Yha', 'accountant', 1);

-- Permissions par rôle
INSERT INTO `role_permissions` (`role`, `module`) VALUES
('admin', 'dashboard'), ('admin', 'rooms'), ('admin', 'reservations'), ('admin', 'clients'), ('admin', 'stays'), ('admin', 'payments'), ('admin', 'expenses'), ('admin', 'purchases'), ('admin', 'suppliers'), ('admin', 'invoices'), ('admin', 'reports'), ('admin', 'settings'),
('manager', 'dashboard'), ('manager', 'rooms'), ('manager', 'reservations'), ('manager', 'clients'), ('manager', 'stays'), ('manager', 'reports'),
('reception', 'dashboard'), ('reception', 'rooms'), ('reception', 'reservations'), ('reception', 'clients'), ('reception', 'stays'), ('reception', 'payments'), ('reception', 'invoices'),
('accountant', 'dashboard'), ('accountant', 'payments'), ('accountant', 'expenses'), ('accountant', 'purchases'), ('accountant', 'suppliers'), ('accountant', 'invoices'), ('accountant', 'reports');

-- 3. Types de chambres & Chambres autonomes
INSERT INTO `room_types` (`id`, `name`, `daily_rate`, `weekly_rate`, `monthly_rate`, `capacity`) VALUES
(1, 'Standard', 25000, 150000, 500000, 2),
(2, 'Confort', 35000, 210000, 700000, 3),
(3, 'Suite', 55000, 330000, 1100000, 4);

INSERT INTO `rooms` (`id`, `number`, `type_id`, `capacity`, `area`, `daily_rate`, `weekly_rate`, `monthly_rate`, `status`, `equipment`, `description`) VALUES
(1, 'Chambre 101', 1, 2, 22, 25000, 150000, 500000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard meublée et climatisée.'),
(2, 'Chambre 102', 1, 2, 22, 25000, 150000, 500000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard confortable.'),
(3, 'Chambre 103', 1, 2, 24, 25000, 150000, 500000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard meublée tout confort.'),
(4, 'Chambre 104', 1, 2, 24, 25000, 150000, 500000, 'RESERVEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard lumineuse.'),
(5, 'Chambre 201', 1, 2, 25, 25000, 150000, 500000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard spacieuse.'),
(6, 'Chambre 202', 1, 2, 25, 25000, 150000, 500000, 'RESERVEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard au calme.'),
(7, 'Chambre 203', 1, 2, 26, 25000, 150000, 500000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard design.'),
(8, 'Chambre 204', 1, 2, 26, 25000, 150000, 500000, 'A_NETTOYER', 'Climatisation, Wi-Fi, TV, Réfrigérateur', 'Chambre Standard en attente de passage ménage.'),
(9, 'Chambre 301', 2, 3, 30, 35000, 210000, 700000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Chambre Confort avec kitchenette équipée.'),
(10, 'Chambre 302', 2, 3, 30, 35000, 210000, 700000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Chambre Confort avec espace détente.'),
(11, 'Chambre 303', 2, 3, 32, 35000, 210000, 700000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Chambre Confort meublée avec soin.'),
(12, 'Chambre 304', 2, 3, 32, 35000, 210000, 700000, 'MAINTENANCE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Chambre Confort en maintenance climatiseur.'),
(13, 'Suite Orchidée', 2, 3, 35, 35000, 210000, 700000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Suite Confort thème floral.'),
(14, 'Suite Baobab', 2, 3, 35, 35000, 210000, 700000, 'RESERVEE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Suite Confort spacieuse.'),
(15, 'Suite Hibiscus', 2, 3, 36, 35000, 210000, 700000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Suite Confort avec salon privatif.'),
(16, 'Suite Ebène', 2, 3, 36, 35000, 210000, 700000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette', 'Suite Confort boiseries nobles.'),
(17, 'Chambre Corail', 3, 4, 45, 55000, 330000, 1100000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite avec balcon vue dégagée.'),
(18, 'Chambre Lagune', 3, 4, 45, 55000, 330000, 1100000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite moderne.'),
(19, 'Chambre Palme', 3, 4, 48, 55000, 330000, 1100000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite tout confort.'),
(20, 'Chambre Safari', 3, 4, 48, 55000, 330000, 1100000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite familiale.'),
(21, 'Chambre Ivoire', 3, 4, 50, 55000, 330000, 1100000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite prestige.'),
(22, 'Chambre Savane', 3, 4, 50, 55000, 330000, 1100000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Grande Suite executive.'),
(23, 'Suite Royale', 3, 4, 55, 55000, 330000, 1100000, 'OCCUPEE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Suite Royale très haut standing.'),
(24, 'Suite Prestige', 3, 4, 55, 55000, 330000, 1100000, 'LIBRE', 'Climatisation, Wi-Fi, TV, Kitchenette, Balcon', 'Suite signature de la résidence.');

-- 4. Clients
INSERT INTO `clients` (`id`, `first_name`, `last_name`, `phone`, `email`, `address`, `nationality`, `id_type`, `id_number`, `created_at`) VALUES
(1, 'Marie', 'Dupont', '+225 07 10 20 30 40', 'marie.dupont@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI100000', '2026-08-01'),
(2, 'Jean Baptiste', 'Koffi', '+225 07 17 23 35 42', 'jeanbaptiste.koffi@mail.com', 'Abidjan', 'Ivoirienne', 'Passeport', 'CI107311', '2026-08-04'),
(3, 'Aminata', 'Traoré', '+225 07 24 26 40 44', 'aminata.traore@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI114622', '2026-08-07'),
(4, 'Yao', 'Kouassi', '+225 07 31 29 45 46', 'yao.kouassi@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI121933', '2026-08-10'),
(5, 'Fatoumata', 'Diallo', '+225 07 38 32 50 48', 'fatoumata.diallo@mail.com', 'Abidjan', 'Malienne', 'Passeport', 'CI129244', '2026-08-13'),
(6, 'Eric', 'N’Guessan', '+225 07 45 35 55 50', 'eric.nguessan@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI136555', '2026-08-16'),
(7, 'Salimata', 'Bamba', '+225 07 52 38 60 52', 'salimata.bamba@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI143866', '2026-08-19'),
(8, 'Serge', 'Konan', '+225 07 59 41 65 54', 'serge.konan@mail.com', 'Abidjan', 'Ivoirienne', 'Passeport', 'CI151177', '2026-08-22'),
(9, 'Mariam', 'Touré', '+225 07 66 44 70 56', 'mariam.toure@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI158488', '2026-08-25'),
(10, 'Christelle', 'Yao', '+225 07 73 47 75 58', 'christelle.yao@mail.com', 'Abidjan', 'Malienne', 'CNI', 'CI165799', '2026-08-28'),
(11, 'Ibrahim', 'Coulibaly', '+225 07 80 50 80 60', 'ibrahim.coulibaly@mail.com', 'Abidjan', 'Ivoirienne', 'Passeport', 'CI173110', '2026-08-31'),
(12, 'Awa', 'Ouattara', '+225 07 87 53 85 62', 'awa.ouattara@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI180421', '2026-09-03'),
(13, 'Franck', 'Kouamé', '+225 07 94 56 90 64', 'franck.kouame@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI187732', '2026-09-06'),
(14, 'Nadège', 'Soro', '+225 07 10 59 95 66', 'nadege.soro@mail.com', 'Abidjan', 'Ivoirienne', 'CNI', 'CI195043', '2026-09-09');

-- 5. Moyens de paiement & Comptes financiers
INSERT INTO `payment_methods` (`id`, `name`, `is_active`) VALUES
(1, 'Espèces', 1), (2, 'Wave', 1), (3, 'Orange Money', 1), (4, 'MTN Mobile Money', 1),
(5, 'Moov Money', 1), (6, 'Virement bancaire', 1), (7, 'Carte bancaire', 1), (8, 'Chèque', 1);

INSERT INTO `financial_accounts` (`id`, `name`, `opening_balance`, `is_active`) VALUES
(1, 'Caisse physique', 600000, 1),
(2, 'Compte Wave', 250000, 1),
(3, 'Compte Orange Money', 150000, 1),
(4, 'Compte MTN Money', 50000, 1),
(5, 'Compte Moov Money', 0, 1),
(6, 'Compte bancaire', 1800000, 1);

-- 6. Fournisseurs
INSERT INTO `suppliers` (`id`, `name`, `phone`, `email`, `address`, `nature`) VALUES
(1, 'Fournisseur ABC', '+225 01 02 03 04 05', 'abc@fourn.ci', 'Yopougon', 'Produits d’entretien écologiques'),
(2, 'CIE', '+225 27 21 00 00 00', 'contact@cie.ci', 'Abidjan', 'Électricité'),
(3, 'SODECI', '+225 27 21 11 11 11', 'contact@sodeci.ci', 'Abidjan', 'Eau courante'),
(4, 'Électro Plus', '+225 05 05 05 05 05', 'contact@electroplus.ci', 'Marcory', 'Équipements et réparations froid'),
(5, 'Linge & Confort', '+225 07 08 09 10 11', 'linge@confort.ci', 'Treichville', 'Linge de maison et literie');

-- 7. Réservations en cours (Occupants des chambres)
INSERT INTO `reservations` (`id`, `client_id`, `room_id`, `arrival_date`, `departure_date`, `guests`, `rate_applied`, `nights`, `discount_amount`, `extra_amount`, `total_amount`, `deposit_amount`, `status`, `notes`, `created_at`) VALUES
(1, 1, 1, DATE_SUB(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 1, 25000, 6, 0, 0, 150000, 150000, 'EN_COURS', 'Séjour professionnel', DATE_SUB(CURDATE(), INTERVAL 6 DAY)),
(2, 2, 3, DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 2, 25000, 6, 0, 0, 150000, 90000, 'EN_COURS', 'Couple sans enfants', DATE_SUB(CURDATE(), INTERVAL 5 DAY)),
(3, 3, 5, DATE_SUB(CURDATE(), INTERVAL 4 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 1, 25000, 6, 0, 0, 150000, 90000, 'EN_COURS', '', DATE_SUB(CURDATE(), INTERVAL 7 DAY)),
(4, 4, 7, DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 2, 25000, 6, 0, 0, 150000, 150000, 'EN_COURS', 'Demande lit bébé', DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
(5, 5, 10, DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 2, 35000, 5, 0, 0, 175000, 105000, 'EN_COURS', '', DATE_SUB(CURDATE(), INTERVAL 5 DAY)),
(6, 6, 13, DATE_SUB(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 1, 35000, 5, 0, 0, 175000, 105000, 'EN_COURS', 'Arrivée tardive', DATE_SUB(CURDATE(), INTERVAL 6 DAY)),
(7, 7, 16, DATE_SUB(CURDATE(), INTERVAL 5 DAY), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 3, 35000, 8, 0, 0, 280000, 280000, 'EN_COURS', '', DATE_SUB(CURDATE(), INTERVAL 8 DAY)),
(8, 8, 17, DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 2, 55000, 6, 0, 0, 330000, 200000, 'EN_COURS', 'VIP séjour détente', DATE_SUB(CURDATE(), INTERVAL 5 DAY)),
(9, 9, 19, DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 6 DAY), 2, 55000, 7, 0, 0, 385000, 230000, 'EN_COURS', '', DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
(10, 10, 20, DATE_SUB(CURDATE(), INTERVAL 4 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 3, 55000, 6, 0, 0, 330000, 330000, 'EN_COURS', 'Famille avec enfant', DATE_SUB(CURDATE(), INTERVAL 7 DAY)),
(11, 11, 21, DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 1, 55000, 5, 0, 0, 275000, 165000, 'EN_COURS', 'Mission conseil', DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
(12, 12, 23, DATE_SUB(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 2, 55000, 8, 0, 0, 440000, 265000, 'EN_COURS', 'Séjour lune de miel', DATE_SUB(CURDATE(), INTERVAL 6 DAY)),

-- Réservations confirmées à venir
(13, 13, 4, DATE_ADD(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 1, 25000, 3, 0, 0, 75000, 25000, 'CONFIRMEE', 'Acompte versé par Wave', CURDATE()),
(14, 2, 6, DATE_ADD(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 6 DAY), 2, 25000, 5, 0, 0, 125000, 40000, 'CONFIRMEE', 'Confirmation par SMS', CURDATE()),
(15, 3, 9, DATE_ADD(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 1, 35000, 3, 0, 0, 105000, 0, 'EN_ATTENTE', 'Paiement à l’arrivée', CURDATE()),
(16, 4, 14, DATE_ADD(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 8 DAY), 2, 35000, 5, 0, 0, 175000, 70000, 'CONFIRMEE', 'Orange Money reçu', CURDATE()),
(17, 1, 18, DATE_ADD(CURDATE(), INTERVAL 4 DAY), DATE_ADD(CURDATE(), INTERVAL 9 DAY), 2, 55000, 5, 0, 0, 275000, 55000, 'CONFIRMEE', '', CURDATE()),

-- Séjours terminés récents
(18, 5, 2, DATE_SUB(CURDATE(), INTERVAL 12 DAY), DATE_SUB(CURDATE(), INTERVAL 8 DAY), 2, 25000, 4, 0, 0, 100000, 100000, 'TERMINEE', 'Séjour parfait', DATE_SUB(CURDATE(), INTERVAL 15 DAY)),
(19, 6, 8, DATE_SUB(CURDATE(), INTERVAL 15 DAY), DATE_SUB(CURDATE(), INTERVAL 11 DAY), 1, 25000, 4, 0, 0, 100000, 100000, 'TERMINEE', '', DATE_SUB(CURDATE(), INTERVAL 18 DAY)),
(20, 7, 11, DATE_SUB(CURDATE(), INTERVAL 20 DAY), DATE_SUB(CURDATE(), INTERVAL 16 DAY), 2, 35000, 4, 0, 0, 140000, 140000, 'TERMINEE', '', DATE_SUB(CURDATE(), INTERVAL 23 DAY)),
(21, 8, 15, DATE_SUB(CURDATE(), INTERVAL 25 DAY), DATE_SUB(CURDATE(), INTERVAL 22 DAY), 1, 35000, 3, 0, 0, 105000, 105000, 'TERMINEE', '', DATE_SUB(CURDATE(), INTERVAL 28 DAY));

-- 8. Factures
INSERT INTO `invoices` (`id`, `number`, `type`, `issue_date`, `client_id`, `reservation_id`, `tax_rate`, `total_ht`, `total_tva`, `total_ttc`, `status`, `terms`) VALUES
(1, 'FAC-2026-001', 'FACTURE', DATE_SUB(CURDATE(), INTERVAL 8 DAY), 5, 18, 0, 100000, 0, 100000, 'EMISE', 'Paiement à réception.'),
(2, 'FAC-2026-002', 'FACTURE', DATE_SUB(CURDATE(), INTERVAL 11 DAY), 6, 19, 0, 100000, 0, 100000, 'EMISE', 'Paiement à réception.'),
(3, 'FAC-2026-003', 'FACTURE', DATE_SUB(CURDATE(), INTERVAL 16 DAY), 7, 20, 0, 140000, 0, 140000, 'EMISE', 'Paiement à réception.'),
(4, 'FAC-2026-004', 'FACTURE', DATE_SUB(CURDATE(), INTERVAL 3 DAY), 1, 1, 0, 150000, 0, 150000, 'EMISE', 'Paiement à réception.'),
(5, 'FAC-2026-005', 'FACTURE', DATE_SUB(CURDATE(), INTERVAL 2 DAY), 2, 2, 0, 150000, 0, 150000, 'EMISE', 'Paiement à réception.');

INSERT INTO `invoice_items` (`id`, `invoice_id`, `label`, `quantity`, `unit_price`, `total_price`) VALUES
(1, 1, 'Séjour Chambre 102 (4 nuits)', 4, 25000, 100000),
(2, 2, 'Séjour Chambre 204 (4 nuits)', 4, 25000, 100000),
(3, 3, 'Séjour Chambre 303 (4 nuits)', 4, 35000, 140000),
(4, 4, 'Séjour Chambre 101 (6 nuits)', 6, 25000, 150000),
(5, 5, 'Séjour Chambre 103 (6 nuits)', 6, 25000, 150000);

-- 9. Encaissements enregistrés
INSERT INTO `payments` (`id`, `reference`, `type`, `payment_date`, `payment_time`, `reservation_id`, `client_id`, `invoice_id`, `amount`, `payment_method_id`, `financial_account_id`, `transaction_ref`, `author_name`) VALUES
(1, 'PAY-2026-0001', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 12 DAY), '14:30', 18, 5, 1, 100000, 1, 1, 'Reçu espèces', 'Administrateur'),
(2, 'PAY-2026-0002', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 15 DAY), '11:15', 19, 6, 2, 100000, 2, 2, 'WAVE-987421', 'Administrateur'),
(3, 'PAY-2026-0003', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 20 DAY), '16:00', 20, 7, 3, 140000, 3, 3, 'OM-451298', 'Administrateur'),
(4, 'PAY-2026-0004', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 3 DAY), '10:00', 1, 1, 4, 150000, 1, 1, 'Paiement intégral séjour', 'Administrateur'),
(5, 'PAY-2026-0005', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '15:20', 2, 2, 5, 90000, 2, 2, 'Acompte Wave', 'Administrateur'),
(6, 'PAY-2026-0006', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 4 DAY), '09:40', 3, 3, NULL, 90000, 1, 1, 'Acompte espèces', 'Administrateur'),
(7, 'PAY-2026-0007', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '17:10', 4, 4, NULL, 150000, 6, 6, 'Virement bancaire direct', 'Administrateur'),
(8, 'PAY-2026-0008', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '13:00', 5, 5, NULL, 105000, 3, 3, 'OM-778899', 'Administrateur'),
(9, 'PAY-2026-0009', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 3 DAY), '18:45', 6, 6, NULL, 105000, 2, 2, 'WAVE-112233', 'Administrateur'),
(10, 'PAY-2026-0010', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 5 DAY), '12:30', 7, 7, NULL, 280000, 6, 6, 'Virement séjour complet', 'Administrateur'),
(11, 'PAY-2026-0011', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '11:00', 8, 8, NULL, 200000, 7, 6, 'Carte bancaire', 'Administrateur'),
(12, 'PAY-2026-0012', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '14:15', 9, 9, NULL, 230000, 4, 4, 'MTN-554433', 'Administrateur'),
(13, 'PAY-2026-0013', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 4 DAY), '10:30', 10, 10, NULL, 330000, 1, 1, 'Règlement total espèces', 'Administrateur'),
(14, 'PAY-2026-0014', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '16:50', 11, 11, NULL, 165000, 2, 2, 'WAVE-445566', 'Administrateur'),
(15, 'PAY-2026-0015', 'PAIEMENT', DATE_SUB(CURDATE(), INTERVAL 3 DAY), '14:00', 12, 12, NULL, 265000, 3, 3, 'OM-990011', 'Administrateur'),
(16, 'PAY-2026-0016', 'PAIEMENT', CURDATE(), '10:15', 13, 13, NULL, 25000, 2, 2, 'Acompte résa WAVE', 'Administrateur'),
(17, 'PAY-2026-0017', 'PAIEMENT', CURDATE(), '11:45', 14, 2, NULL, 40000, 1, 1, 'Acompte résa espèces', 'Administrateur');

-- 10. Achats
INSERT INTO `purchases` (`id`, `reference`, `supplier_id`, `purchase_date`, `kind`, `terms`, `total_amount`, `author_name`) VALUES
(1, 'ACH-2026-0001', 1, DATE_SUB(CURDATE(), INTERVAL 4 DAY), 'EXPLOITATION', 'Comptant', 38500, 'Administrateur'),
(2, 'ACH-2026-0002', 5, DATE_SUB(CURDATE(), INTERVAL 12 DAY), 'EXPLOITATION', 'Partiel', 270000, 'Administrateur'),
(3, 'ACH-2026-0003', 4, DATE_SUB(CURDATE(), INTERVAL 20 DAY), 'IMMOBILISATION', 'À crédit', 285000, 'Administrateur'),
(4, 'ACH-2026-0004', 1, DATE_SUB(CURDATE(), INTERVAL 25 DAY), 'EXPLOITATION', 'Comptant', 36000, 'Administrateur');

INSERT INTO `purchase_items` (`id`, `purchase_id`, `label`, `quantity`, `unit_price`, `total_price`) VALUES
(1, 1, 'Produits d’entretien écologiques', 10, 3850, 38500),
(2, 2, 'Draps coton 2 places', 20, 8500, 170000),
(3, 2, 'Serviettes de bain', 40, 2500, 100000),
(4, 3, 'Climatiseur split inverter 1.5 CV', 1, 285000, 285000),
(5, 4, 'Désodorisants diffuseurs', 30, 1200, 36000);

INSERT INTO `supplier_payments` (`id`, `purchase_id`, `payment_date`, `amount`, `financial_account_id`, `payment_method_id`) VALUES
(1, 1, DATE_SUB(CURDATE(), INTERVAL 4 DAY), 38500, 1, 1),
(2, 2, DATE_SUB(CURDATE(), INTERVAL 12 DAY), 100000, 1, 1),
(3, 4, DATE_SUB(CURDATE(), INTERVAL 25 DAY), 36000, 1, 1);

-- 11. Dépenses d'exploitation
INSERT INTO `expenses` (`id`, `reference`, `expense_date`, `expense_time`, `category`, `label`, `amount`, `paid_amount`, `supplier_id`, `room_id`, `payment_method_id`, `financial_account_id`, `status`, `author_name`) VALUES
(1, 'DEP-2026-0001', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '10:30', 'Électricité', 'Facture électricité CIE résidence', 185000, 185000, 2, NULL, 2, 2, 'PAYEE', 'Administrateur'),
(2, 'DEP-2026-0002', DATE_SUB(CURDATE(), INTERVAL 6 DAY), '14:20', 'Eau', 'Facture SODECI consommation mensuelle', 62000, 62000, 3, NULL, 1, 1, 'PAYEE', 'Administrateur'),
(3, 'DEP-2026-0003', DATE_SUB(CURDATE(), INTERVAL 9 DAY), '09:15', 'Internet', 'Abonnement fibre optique haut débit', 45000, 45000, NULL, NULL, 1, 1, 'PAYEE', 'Administrateur'),
(4, 'DEP-2026-0004', DATE_SUB(CURDATE(), INTERVAL 4 DAY), '16:00', 'Nettoyage', 'Produits ménagers spécialisés', 38500, 38500, 1, NULL, 1, 1, 'PAYEE', 'Administrateur'),
(5, 'DEP-2026-0005', DATE_SUB(CURDATE(), INTERVAL 15 DAY), '18:00', 'Personnel', 'Gratifications et salaires d’appoint', 150000, 150000, NULL, NULL, 1, 1, 'PAYEE', 'Administrateur'),
(6, 'DEP-2026-0006', DATE_SUB(CURDATE(), INTERVAL 3 DAY), '11:45', 'Réparation', 'Réparation circuit froid Chambre 304', 95000, 0, 4, 12, 1, 1, 'VALIDEE', 'Administrateur'),
(7, 'DEP-2026-0007', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '15:10', 'Fournitures', 'Renouvellement linge de rechange', 120000, 0, 5, NULL, 1, 1, 'EN_ATTENTE_VALIDATION', 'Awa Gestionnaire'),
(8, 'DEP-2026-0008', DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:30', 'Transport', 'Course logistique fourniture accueil', 7500, 0, NULL, NULL, 1, 1, 'BROUILLON', 'Koffi Réception'),
(9, 'DEP-2026-0009', DATE_SUB(CURDATE(), INTERVAL 11 DAY), '14:00', 'Entretien', 'Élagage des arbres et jardinage', 25000, 0, NULL, NULL, 1, 1, 'REJETEE', 'Administrateur');

-- 12. Journal d'Audit
INSERT INTO `audit_logs` (`id`, `user_name`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 'Système', 'Initialisation de la base de données', 'Chargement initial du schéma et du seed', '127.0.0.1', NOW()),
(2, 'Administrateur', 'Connexion', 'Session administrateur démarrée', '127.0.0.1', NOW());

SET FOREIGN_KEY_CHECKS = 1;
