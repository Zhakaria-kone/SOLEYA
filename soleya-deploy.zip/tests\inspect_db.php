<?php
// tests/inspect_db.php
require_once __DIR__ . '/../app/Models/Model.php';

$pdo = \App\Models\Model::getPdo();
$tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

echo "Base de données : residence_manager (MariaDB / MySQL)\n";
echo "Nombre de tables : " . count($tables) . "\n\n";

foreach ($tables as $t) {
    $count = $pdo->query("SELECT COUNT(*) FROM `{$t}`")->fetchColumn();
    echo str_pad("  • {$t}", 30) . " : {$count} ligne(s)\n";
}

echo "\nServeur MySQL actif sur 127.0.0.1:3306 (user: root, sans mot de passe).\n";

$ch = curl_init('http://localhost:8080/phpmyadmin/index.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 2);
curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "Accès phpMyAdmin : " . ($code === 200 ? "Disponible sur http://localhost:8080/phpmyadmin/" : "Non configuré sur le port 8080 (HTTP {$code})") . "\n";
