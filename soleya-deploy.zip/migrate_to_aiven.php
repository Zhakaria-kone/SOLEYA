<?php
// migrate_to_aiven.php - Déploiement du schéma et des données vers Aiven MySQL

declare(strict_types=1);

$host = 'mysql-2ed2282d-soleya.l.aivencloud.com';
$port = 22626;
$db   = 'defaultdb';
$user = 'avnadmin';
$pass = 'AVNS_K3sGorWi4gSwuCsE8xF';

echo "=== MIGRATION VERS AIVEN MYSQL ===\n";

$dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_SSL_CA => true,
    PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "1. Connecté à Aiven MySQL avec succès.\n";

    // Lecture du schéma DDL
    $schemaSql = file_get_contents(__DIR__ . '/database/schema.sql');
    // Retirer 'CREATE DATABASE' et 'USE residence_manager' car sur Aiven la base est 'defaultdb'
    $schemaSql = preg_replace('/CREATE DATABASE[^;]+;/i', '', $schemaSql);
    $schemaSql = preg_replace('/USE `residence_manager`;/i', '', $schemaSql);

    $pdo->exec($schemaSql);
    echo "2. Schéma de tables créé sur Aiven.\n";

    // Insertion des données initiales / seed
    $seedSql = file_get_contents(__DIR__ . '/database/seed.sql');
    $seedSql = preg_replace('/USE `residence_manager`;/i', '', $seedSql);

    $pdo->exec($seedSql);
    echo "3. Données de référence et de démonstration insérées sur Aiven.\n";

    // Vérification des tables créées
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "4. Tables présentes sur Aiven (" . count($tables) . ") : " . implode(', ', $tables) . "\n";

    $roomCount = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    echo "5. Vérification : {$roomCount} chambres et {$userCount} utilisateurs trouvés.\n";

    echo "=== MIGRATION AIVEN TERMINÉE AVEC SUCCÈS ===\n";
} catch (Exception $e) {
    echo "ERREUR : " . $e->getMessage() . "\n";
    exit(1);
}
