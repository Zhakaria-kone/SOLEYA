<?php
// app/Models/Model.php

namespace App\Models;

use PDO;
use Exception;

abstract class Model
{
    protected static ?PDO $pdo = null;
    protected string $table = '';
    protected string $primaryKey = 'id';

    public static function getPdo(): PDO
    {
        if (self::$pdo === null) {
            $config = require __DIR__ . '/../../config/database.php';
            $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
            self::$pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);
        }
        return self::$pdo;
    }

    public function all(string $orderBy = 'id DESC'): array
    {
        $stmt = self::getPdo()->prepare("SELECT * FROM `{$this->table}` ORDER BY {$orderBy}");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function find($id): ?array
    {
        $stmt = self::getPdo()->prepare("SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public function create(array $data): int
    {
        $fields = array_keys($data);
        $columns = implode('`, `', $fields);
        $placeholders = ':' . implode(', :', $fields);

        $sql = "INSERT INTO `{$this->table}` (`{$columns}`) VALUES ({$placeholders})";
        $stmt = self::getPdo()->prepare($sql);
        $stmt->execute($data);

        return (int)self::getPdo()->lastInsertId();
    }

    public function update($id, array $data): bool
    {
        $fields = [];
        foreach (array_keys($data) as $field) {
            $fields[] = "`{$field}` = :{$field}";
        }
        $setString = implode(', ', $fields);
        $data['id'] = $id;

        $sql = "UPDATE `{$this->table}` SET {$setString} WHERE `{$this->primaryKey}` = :id";
        $stmt = self::getPdo()->prepare($sql);
        return $stmt->execute($data);
    }

    public function delete($id): bool
    {
        $stmt = self::getPdo()->prepare("DELETE FROM `{$this->table}` WHERE `{$this->primaryKey}` = :id");
        return $stmt->execute(['id' => $id]);
    }

    public static function query(string $sql, array $params = []): array
    {
        $stmt = self::getPdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function queryOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getPdo()->prepare($sql);
        $stmt->execute($params);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function execute(string $sql, array $params = []): bool
    {
        $stmt = self::getPdo()->prepare($sql);
        return $stmt->execute($params);
    }

    public static function beginTransaction(): void
    {
        self::getPdo()->beginTransaction();
    }

    public static function commit(): void
    {
        self::getPdo()->commit();
    }

    public static function rollBack(): void
    {
        self::getPdo()->rollBack();
    }
}
