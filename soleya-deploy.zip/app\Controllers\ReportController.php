<?php
// app/Controllers/ReportController.php

namespace App\Controllers;

use App\Services\FinanceService;
use App\Models\Room;
use App\Models\Reservation;
use App\Models\Payment;
use App\Models\Expense;
use App\Helpers\Response;
use App\Helpers\Format;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;

class ReportController
{
    private FinanceService $financeService;

    public function __construct()
    {
        $this->financeService = new FinanceService();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('reports');

        $from = $params['from'] ?? date('Y-m-01');
        $to = $params['to'] ?? Format::today();

        $finance = $this->financeService->getDashboard($from, $to);

        // Performances par chambre
        $roomPerformance = Room::query("
            SELECT 
                rm.id,
                rm.number,
                rt.name AS type_name,
                COUNT(r.id) AS reservations_count,
                COALESCE(SUM(r.nights), 0) AS total_nights,
                COALESCE(SUM(r.total_amount), 0) AS total_revenue
            FROM `rooms` rm
            LEFT JOIN `room_types` rt ON rm.type_id = rt.id
            LEFT JOIN `reservations` r ON rm.id = r.room_id 
                AND r.status NOT IN ('ANNULEE', 'NO_SHOW')
                AND r.arrival_date <= :to AND r.departure_date >= :from
            GROUP BY rm.id
            ORDER BY total_revenue DESC
        ", ['from' => $from, 'to' => $to]);

        // Détail des dépenses par catégorie
        $expensesByCategory = Expense::query("
            SELECT 
                category,
                COUNT(*) AS count,
                SUM(amount) AS total
            FROM `expenses`
            WHERE expense_date BETWEEN :from AND :to
              AND status IN ('VALIDEE', 'PAYEE')
            GROUP BY category
            ORDER BY total DESC
        ", ['from' => $from, 'to' => $to]);

        // Détail des encaissements par mode
        $paymentsByMethod = Payment::query("
            SELECT 
                m.name AS method_name,
                COUNT(p.id) AS count,
                SUM(p.amount) AS total
            FROM `payments` p
            LEFT JOIN `payment_methods` m ON p.payment_method_id = m.id
            WHERE p.payment_date BETWEEN :from AND :to
            GROUP BY m.id
            ORDER BY total DESC
        ", ['from' => $from, 'to' => $to]);

        Response::success([
            'period' => ['from' => $from, 'to' => $to],
            'kpis' => $finance['kpis'],
            'room_performance' => $roomPerformance,
            'expenses_by_category' => $expensesByCategory,
            'payments_by_method' => $paymentsByMethod,
            'cash_evolution' => $finance['charts']['evolution']
        ]);
    }
}
