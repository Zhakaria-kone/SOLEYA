// Service Worker - Soleya Residence Manager
const CACHE_NAME = 'soleya-cache-v1';
const ASSETS_TO_CACHE = [
  './',
  'index.php',
  'manifest.json',
  'assets/logo.jpg',
  'assets/css/style.css',
  'assets/icons/icon-192x192.png',
  'assets/icons/icon-512x512.png',
  'assets/icons/favicon-32x32.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {
        // Cache optionnel des ressources en cas de réseau partiel
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Ignorer les requêtes API dynamiques (api.php) pour toujours garder les données fraîches de MySQL
  if (event.request.url.includes('api.php') || event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request);
    })
  );
});
