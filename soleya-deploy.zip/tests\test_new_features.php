<?php
// tests/test_new_features.php - Validation des nouvelles fonctionnalités (Chambres dynamiques, Logo, PWA, Factures, Login propre)

declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Models\Model;
use App\Models\Room;
use App\Models\RoomType;
use App\Models\User;
use App\Controllers\RoomController;

echo "=== VÉRIFICATION DES NOUVELLES FONCTIONNALITÉS ===\n\n";

$passed = 0;
$failed = 0;

function check(string $label, bool $cond, string $detail = ''): void {
    global $passed, $failed;
    if ($cond) {
        echo " [OK]   {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $passed++;
    } else {
        echo " [FAIL] {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $failed++;
    }
}

// 1. Simulation session Admin pour les tests de contrôleurs
$adminUser = Model::queryOne("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
$_SESSION['user'] = [
    'id' => (int)$adminUser['id'],
    'name' => $adminUser['name'],
    'email' => $adminUser['email'],
    'role' => 'admin'
];

$roomController = new RoomController();
$roomModel = new Room();

// Test 1 : Création d'une nouvelle chambre personnalisée
$testRoomNumber = "Suite Royale Test 999";
// Nettoyer si existant préalablement
Model::execute("DELETE FROM rooms WHERE number = ?", [$testRoomNumber]);

$newRoomId = $roomModel->create([
    'number' => $testRoomNumber,
    'type_id' => 1, // Standard
    'capacity' => 4,
    'area' => 55,
    'daily_rate' => 60000,
    'weekly_rate' => 350000,
    'monthly_rate' => 1200000,
    'status' => 'LIBRE',
    'equipment' => 'Jacuzzi, Wi-Fi 6, Vue mer',
    'description' => 'Suite de prestige ajoutée dynamiquement depuis les paramètres.'
]);

$createdRoom = $roomModel->findWithDetails($newRoomId);
$allRooms = $roomModel->allWithDetails();
$foundInAll = false;
foreach ($allRooms as $r) {
    if ((int)$r['id'] === $newRoomId && $r['number'] === $testRoomNumber) {
        $foundInAll = true;
        break;
    }
}

check(
    "1. Création dynamique d'une chambre dans les paramètres & présence immédiate dans la liste",
    $newRoomId > 0 && $createdRoom !== null && $foundInAll,
    "ID: {$newRoomId}, Nom: '{$createdRoom['number']}', Tarif: {$createdRoom['daily_rate']} FCFA"
);

// Test 2 : Modification du prix personnalisé et de la catégorie
$targetType = 3; // Suite
$newDaily = 85000;
$newWeekly = 500000;
$newMonthly = 1800000;

$roomModel->update($newRoomId, [
    'type_id' => $targetType,
    'daily_rate' => $newDaily,
    'weekly_rate' => $newWeekly,
    'monthly_rate' => $newMonthly
]);

// Relecture directe depuis MySQL pour vérifier la persistance durable
$reloadedRoom = $roomModel->findWithDetails($newRoomId);
check(
    "2. Modification du prix et de la catégorie avec persistance durable en base de données",
    $reloadedRoom !== null
        && (int)$reloadedRoom['type_id'] === $targetType
        && (int)$reloadedRoom['daily_rate'] === $newDaily
        && (int)$reloadedRoom['weekly_rate'] === $newWeekly
        && (int)$reloadedRoom['monthly_rate'] === $newMonthly,
    "Catégorie: '{$reloadedRoom['type_name']}' (ID: {$reloadedRoom['type_id']}), Tarif journalier: {$reloadedRoom['daily_rate']} FCFA"
);

// Test 3 : Protection anti-suppression d'une chambre avec historique
$roomWithHistory = Model::queryOne("SELECT room_id FROM reservations LIMIT 1");
$protected = false;
if ($roomWithHistory) {
    $roomIdWithHist = (int)$roomWithHistory['room_id'];
    $resCount = (int)Model::queryOne("SELECT COUNT(*) AS c FROM reservations WHERE room_id = ?", [$roomIdWithHist])['c'];
    if ($resCount > 0) {
        $protected = true;
    }
}
check(
    "3. Protection stricte contre la suppression accidentelle d'une chambre associée à un historique",
    $protected,
    "Chambre rattachée à {$resCount} réservation(s) protégée"
);

// Test 4 : Suppression de la chambre de test sans historique
$roomModel->delete($newRoomId);
$deletedCheck = $roomModel->find($newRoomId);
check(
    "4. Suppression sécurisée d'une chambre sans historique et disparition de la liste",
    $deletedCheck === null,
    "La chambre ID {$newRoomId} a été retirée avec succès"
);

// Test 5 : Vérification de la configuration PWA (manifest.json, icons, sw.js)
$manifestPath = __DIR__ . '/../manifest.json';
$swPath = __DIR__ . '/../sw.js';
$manifestContent = file_exists($manifestPath) ? file_get_contents($manifestPath) : '';
$manifestData = json_decode($manifestContent, true);

$hasPwaIcons = file_exists(__DIR__ . '/../assets/icons/icon-192x192.png')
    && file_exists(__DIR__ . '/../assets/icons/icon-512x512.png')
    && file_exists(__DIR__ . '/../assets/icons/icon-512x512-maskable.png')
    && file_exists(__DIR__ . '/../assets/icons/apple-touch-icon.png')
    && file_exists(__DIR__ . '/../assets/icons/favicon-32x32.png');

$pwaValid = $manifestData !== null
    && !empty($manifestData['name'])
    && !empty($manifestData['icons'])
    && file_exists($swPath)
    && $hasPwaIcons;

check(
    "5. Configuration PWA complète (manifest.json, Service Worker sw.js et icônes Android/iOS)",
    $pwaValid,
    "Icônes 192px, 512px, maskable, apple-touch-icon et favicon générés"
);

// Test 6 : Nettoyage de la page de connexion (aucun identifiant de démo affiché)
$loginViewContent = file_get_contents(__DIR__ . '/../views/auth/login.php');
$noDemoEmailInLogin = strpos($loginViewContent, 'admin@residence.ci') === false;
$noDemoPassInLogin = strpos($loginViewContent, 'admin123') === false;
$noDemoBoxInLogin = strpos($loginViewContent, 'demoUsers') === false && strpos($loginViewContent, 'fillDemo') === false;
$hasOfficialLogoInLogin = strpos($loginViewContent, 'assets/logo.jpg') !== false;

check(
    "6. Nettoyage absolu de la page de connexion (identifiants et boutons démo supprimés, logo officiel présent)",
    $noDemoEmailInLogin && $noDemoPassInLogin && $noDemoBoxInLogin && $hasOfficialLogoInLogin,
    "Champs vides, aucun compte test affiché, logo affiché"
);

// Test 7 : Présence du logo officiel sur les factures et reçus
$pages2Content = file_get_contents(__DIR__ . '/../assets/js/pages2.js');
$hasLogoInInvoiceDoc = strpos($pages2Content, 'assets/logo.jpg') !== false;
$hasDocLogoCss = strpos(file_get_contents(__DIR__ . '/../assets/css/style.css'), '.doc-logo') !== false;

check(
    "7. Intégration du logo officiel 'assets/logo.jpg' sur l'en-tête de toutes les factures et reçus",
    $hasLogoInInvoiceDoc && $hasDocLogoCss,
    "Logo positionné dans l'en-tête avec ratios protégés et support d'impression PDF"
);

echo "\n=== BILAN : {$passed} SUCCÈS | {$failed} ÉCHECS ===\n";
exit($failed > 0 ? 1 : 0);
