<?php
// tests/test_aiven_conn.php

$host = 'mysql-2ed2282d-soleya.l.aivencloud.com';
$port = 22626;
$db   = 'defaultdb';
$user = 'avnadmin';
$pass = 'AVNS_K3sGorWi4gSwuCsE8xF';

$dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_SSL_CA => true,
    PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "SUCCESS: Connexion réussie à Aiven MySQL!\n";
    $stmt = $pdo->query("SELECT VERSION() as v");
    $row = $stmt->fetch();
    echo "Version MySQL Aiven : " . $row['v'] . "\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
