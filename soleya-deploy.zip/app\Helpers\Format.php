<?php
// app/Helpers/Format.php

namespace App\Helpers;

use DateTime;
use DateTimeZone;

class Format
{
    public static function fcfa(int|float $amount): string
    {
        return number_format($amount, 0, ',', ' ') . ' FCFA';
    }

    public static function date(?string $date): string
    {
        if (!$date) return '—';
        $d = DateTime::createFromFormat('Y-m-d', substr($date, 0, 10));
        return $d ? $d->format('d/m/Y') : $date;
    }

    public static function now(): string
    {
        $d = new DateTime('now', new DateTimeZone('Africa/Abidjan'));
        return $d->format('Y-m-d H:i:s');
    }

    public static function today(): string
    {
        $d = new DateTime('now', new DateTimeZone('Africa/Abidjan'));
        return $d->format('Y-m-d');
    }

    public static function diffDays(string $from, string $to): int
    {
        $d1 = new DateTime($from);
        $d2 = new DateTime($to);
        $diff = $d1->diff($d2);
        return (int)$diff->format('%r%a');
    }
}
