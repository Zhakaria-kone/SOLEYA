<?php
// app/Services/FinanceService.php

namespace App\Services;

use App\Models\Model;
use App\Models\Room;
use App\Models\FinancialAccount;
use App\Helpers\Format;
use DateTime;
use DateInterval;

class FinanceService
{
    private Room $roomModel;
    private FinancialAccount $accountModel;

    public function __construct()
    {
        $this->roomModel = new Room();
        $this->accountModel = new FinancialAccount();
    }

    public function getDashboard(?string $from = null, ?string $to = null, string $periodKey = 'last30'): array
    {
        $today = Format::today();
        if (empty($from)) {
            $from = date('Y-m-d', strtotime('-30 days'));
        }
        if (empty($to)) {
            $to = $today;
        }

        // 1. Indicateurs opérationnels
        $rooms = $this->roomModel->all();
        $totalRooms = count($rooms);
        $counts = ['LIBRE' => 0, 'RESERVEE' => 0, 'OCCUPEE' => 0, 'A_NETTOYER' => 0, 'MAINTENANCE' => 0];
        foreach ($rooms as $r) {
            if (isset($counts[$r['status']])) {
                $counts[$r['status']]++;
            }
        }
        $occupancyRate = $totalRooms > 0 ? round(($counts['OCCUPEE'] / $totalRooms) * 100) : 0;

        $arrivalsToday = (int)Model::queryOne("SELECT COUNT(*) AS total FROM `reservations` WHERE `arrival_date` = :today AND `status` IN ('CONFIRMEE', 'EN_ATTENTE')", ['today' => $today])['total'];
        $departuresToday = (int)Model::queryOne("SELECT COUNT(*) AS total FROM `reservations` WHERE `departure_date` = :today AND `status` = 'EN_COURS'", ['today' => $today])['total'];
        $upcomingCount = (int)Model::queryOne("SELECT COUNT(*) AS total FROM `reservations` WHERE `departure_date` > :today AND `status` IN ('CONFIRMEE', 'EN_ATTENTE')", ['today' => $today])['total'];

        // 2. Indicateurs financiers sur la période [from, to]
        // Chiffre d'affaires : prestations réalisées dont la date d'arrivée est dans la période (PRD 387)
        $ca = (int)Model::queryOne("
            SELECT COALESCE(SUM(total_amount), 0) AS total 
            FROM `reservations` 
            WHERE `status` NOT IN ('ANNULEE', 'NO_SHOW') 
              AND `arrival_date` BETWEEN :from AND :to
        ", ['from' => $from, 'to' => $to])['total'];

        // Période précédente pour calculer l'évolution (+ / - %)
        $len = Format::diffDays($from, $to) + 1;
        $dFrom = new DateTime($from);
        $dPrevTo = clone $dFrom;
        $dPrevTo->sub(new DateInterval('P1D'));
        $dPrevFrom = clone $dPrevTo;
        $dPrevFrom->sub(new DateInterval("P{$len}D"));
        $prevCa = (int)Model::queryOne("
            SELECT COALESCE(SUM(total_amount), 0) AS total 
            FROM `reservations` 
            WHERE `status` NOT IN ('ANNULEE', 'NO_SHOW') 
              AND `arrival_date` BETWEEN :from AND :to
        ", ['from' => $dPrevFrom->format('Y-m-d'), 'to' => $dPrevTo->format('Y-m-d')])['total'];

        $caDeltaPercent = $prevCa > 0 ? round((($ca - $prevCa) / $prevCa) * 100) : 0;

        // Total des encaissements sur la période
        $income = (int)Model::queryOne("
            SELECT COALESCE(SUM(amount), 0) AS total 
            FROM `payments` 
            WHERE `payment_date` BETWEEN :from AND :to
        ", ['from' => $from, 'to' => $to])['total'];

        // Dépenses payées sur la période
        $expensesPaid = (int)Model::queryOne("
            SELECT COALESCE(SUM(paid_amount), 0) AS total 
            FROM `expenses` 
            WHERE `expense_date` BETWEEN :from AND :to
        ", ['from' => $from, 'to' => $to])['total'];

        // Achats fournisseurs payés sur la période
        $supplierPaymentsPaid = (int)Model::queryOne("
            SELECT COALESCE(SUM(amount), 0) AS total 
            FROM `supplier_payments` 
            WHERE `payment_date` BETWEEN :from AND :to
        ", ['from' => $from, 'to' => $to])['total'];

        $totalSpent = $expensesPaid + $supplierPaymentsPaid;

        // Trésorerie disponible actuelle (somme de tous les comptes)
        $treasury = $this->accountModel->getTotalTreasury();

        // Créances clients (factures non soldées)
        $receivables = (int)Model::queryOne("
            SELECT COALESCE(SUM(i.total_ttc - COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.invoice_id = i.id), 0)), 0) AS total
            FROM `invoices` i
            WHERE i.status = 'EMISE' AND i.type != 'AVOIR'
        ")['total'];
        $receivables = max(0, $receivables);

        // Dettes fournisseurs (achats non soldés)
        $debts = (int)Model::queryOne("
            SELECT COALESCE(SUM(pu.total_amount - COALESCE((SELECT SUM(sp.amount) FROM `supplier_payments` sp WHERE sp.purchase_id = pu.id), 0)), 0) AS total
            FROM `purchases` pu
        ")['total'];
        $debts = max(0, $debts);

        // Résultat estimé sur la période
        $estimatedResult = $ca - $totalSpent;

        // Séjours récents pour le widget "Calendrier des séjours"
        $stays = Model::query("
            SELECT 
                r.id, r.arrival_date, r.departure_date, r.status,
                c.first_name, c.last_name,
                rm.number AS room_name
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            INNER JOIN `rooms` rm ON r.room_id = rm.id
            WHERE r.status IN ('EN_COURS', 'CONFIRMEE', 'EN_ATTENTE')
            ORDER BY (CASE WHEN r.status = 'EN_COURS' THEN 0 ELSE 1 END), r.arrival_date ASC
            LIMIT 4
        ");
        foreach ($stays as &$s) {
            $s['client_full_name'] = $s['first_name'] . ' ' . $s['last_name'];
        }

        // Dernières opérations
        $recentOps = $this->getRecentOperations();

        // Découpage en intervalles pour le graphique
        $evolution = $this->getEvolutionData($from, $to, $periodKey);

        return [
            'period' => ['from' => $from, 'to' => $to, 'key' => $periodKey],
            'kpis' => [
                'total_rooms' => $totalRooms,
                'occupied_rooms' => $counts['OCCUPEE'],
                'free_rooms' => $counts['LIBRE'],
                'reserved_rooms' => $counts['RESERVEE'],
                'cleaning_rooms' => $counts['A_NETTOYER'],
                'maintenance_rooms' => $counts['MAINTENANCE'],
                'occupancy_rate' => $occupancyRate,
                'arrivals_today' => $arrivalsToday,
                'departures_today' => $departuresToday,
                'upcoming_reservations' => $upcomingCount,
                'revenue' => $ca,
                'total_revenue' => $ca,
                'revenue_delta_percent' => $caDeltaPercent,
                'income' => $income,
                'spent' => $totalSpent,
                'treasury' => $treasury,
                'net_cash' => $treasury,
                'receivables' => $receivables,
                'debts' => $debts,
                'estimated_result' => $estimatedResult
            ],
            'stays' => $stays,
            'recent_operations' => $recentOps,
            'evolution' => $evolution,
            'accounts' => $this->accountModel->allWithBalances()
        ];
    }

    private function getRecentOperations(): array
    {
        $ops = [];

        // 1. Derniers paiements
        $payments = Model::query("
            SELECT p.reference, p.payment_date, p.payment_time, p.amount, p.type,
                   c.first_name, c.last_name, rm.number AS room_name
            FROM `payments` p
            INNER JOIN `clients` c ON p.client_id = c.id
            LEFT JOIN `reservations` r ON p.reservation_id = r.id
            LEFT JOIN `rooms` rm ON r.room_id = rm.id
            ORDER BY p.payment_date DESC, p.id DESC
            LIMIT 4
        ");
        foreach ($payments as $p) {
            $ops[] = [
                'timestamp' => $p['payment_date'] . ' ' . ($p['payment_time'] ?: '12:00'),
                'icon' => 'bi-currency-dollar',
                'color' => 'green',
                'title' => ($p['amount'] < 0 ? 'Remboursement' : 'Encaissement') . ' – ' . Format::fcfa(abs((int)$p['amount'])),
                'subtitle' => ($p['room_name'] ?: ($p['first_name'] . ' ' . $p['last_name'])) . ' • ' . Format::date($p['payment_date']) . ' ' . ($p['payment_time'] ?: ''),
                'success' => true
            ];
        }

        // 2. Derniers achats
        $purchases = Model::query("
            SELECT pu.reference, pu.purchase_date, pu.total_amount, s.name AS supplier_name,
                   (SELECT pi.label FROM `purchase_items` pi WHERE pi.purchase_id = pu.id LIMIT 1) AS first_item
            FROM `purchases` pu
            INNER JOIN `suppliers` s ON pu.supplier_id = s.id
            ORDER BY pu.purchase_date DESC, pu.id DESC
            LIMIT 2
        ");
        foreach ($purchases as $pu) {
            $ops[] = [
                'timestamp' => $pu['purchase_date'] . ' 13:20',
                'icon' => 'bi-cart-fill',
                'color' => 'red',
                'title' => 'Achat – ' . ($pu['first_item'] ?: 'Articles'),
                'subtitle' => $pu['supplier_name'] . ' • ' . Format::date($pu['purchase_date']),
                'success' => false
            ];
        }

        // 3. Dernières dépenses payées
        $expenses = Model::query("
            SELECT reference, expense_date, expense_time, category, label, paid_amount
            FROM `expenses`
            WHERE `paid_amount` > 0
            ORDER BY expense_date DESC, id DESC
            LIMIT 2
        ");
        foreach ($expenses as $e) {
            $ops[] = [
                'timestamp' => $e['expense_date'] . ' ' . ($e['expense_time'] ?: '12:45'),
                'icon' => 'bi-file-earmark-text-fill',
                'color' => 'orange',
                'title' => 'Dépense – ' . $e['category'],
                'subtitle' => Format::date($e['expense_date']) . ' ' . ($e['expense_time'] ?: ''),
                'success' => false
            ];
        }

        usort($ops, fn($a, $b) => strcmp($b['timestamp'], $a['timestamp']));
        return array_slice($ops, 0, 4);
    }

    private function getEvolutionData(string $from, string $to, string $periodKey): array
    {
        $days = Format::diffDays($from, $to) + 1;
        $buckets = [];

        if ($periodKey === 'today' || $days <= 1) {
            $buckets[] = ['label' => 'Aujourd’hui', 'from' => $from, 'to' => $to];
        } elseif ($periodKey === 'week' || $days <= 7) {
            $d = new DateTime($from);
            $dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
            for ($i = 0; $i < $days; $i++) {
                $cur = $d->format('Y-m-d');
                $buckets[] = ['label' => $dayNames[(int)$d->format('w')], 'from' => $cur, 'to' => $cur];
                $d->modify('+1 day');
            }
        } else {
            $step = (int)ceil($days / 4);
            $d = new DateTime($from);
            for ($i = 0; $i < 4; $i++) {
                $bFrom = $d->format('Y-m-d');
                $dEnd = clone $d;
                $dEnd->modify('+' . ($step - 1) . ' days');
                if ($dEnd->format('Y-m-d') > $to) {
                    $bTo = $to;
                } else {
                    $bTo = $dEnd->format('Y-m-d');
                }
                $buckets[] = ['label' => 'Sem. ' . ($i + 1), 'from' => $bFrom, 'to' => $bTo];
                $d->modify("+{$step} days");
                if ($d->format('Y-m-d') > $to) break;
            }
        }

        $labels = [];
        $recettes = [];
        $depenses = [];
        $resultats = [];

        foreach ($buckets as $b) {
            $labels[] = $b['label'];
            $rec = (int)Model::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `payments` WHERE `payment_date` BETWEEN :from AND :to", ['from' => $b['from'], 'to' => $b['to']])['total'];
            $dep = (int)Model::queryOne("SELECT COALESCE(SUM(paid_amount), 0) AS total FROM `expenses` WHERE `expense_date` BETWEEN :from AND :to", ['from' => $b['from'], 'to' => $b['to']])['total']
                 + (int)Model::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `supplier_payments` WHERE `payment_date` BETWEEN :from AND :to", ['from' => $b['from'], 'to' => $b['to']])['total'];
            
            $recettes[] = $rec;
            $depenses[] = $dep;
            $resultats[] = $rec - $dep;
        }

        return [
            'labels' => $labels,
            'recettes' => $recettes,
            'depenses' => $depenses,
            'resultats' => $resultats
        ];
    }
}
