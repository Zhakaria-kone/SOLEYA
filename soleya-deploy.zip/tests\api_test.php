<?php
// tests/api_test.php - Automated Verification of RESIDENCE MANAGER Backend

declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    } elseif (strpos($class, 'Routes\\') === 0) {
        $path = __DIR__ . '/../routes/' . str_replace('\\', '/', substr($class, 7)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Models\User;
use App\Models\Room;
use App\Models\Client;
use App\Models\Reservation;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Expense;
use App\Services\ReservationService;
use App\Services\InvoiceService;
use App\Services\FinanceService;

echo "=== DÉBUT DES TESTS DU BACKEND ===\n\n";

$passed = 0;
$failed = 0;

function assertTest(string $desc, bool $condition) {
    global $passed, $failed;
    if ($condition) {
        echo " [OK] " . $desc . "\n";
        $passed++;
    } else {
        echo " [FAIL] " . $desc . "\n";
        $failed++;
    }
}

// 1. Authentification
$userModel = new User();
$admin = $userModel->findByEmail('admin@residence.ci');
assertTest("Utilisateur admin trouvé", $admin !== null && $admin['role'] === 'admin');
assertTest("Vérification mot de passe bcrypt admin", password_verify('admin123', $admin['password_hash']));

// 2. Chambres sans hiérarchie d'étages et occupant direct
$roomModel = new Room();
$rooms = $roomModel->allWithDetails();
assertTest("Liste des chambres récupérée (24 chambres)", count($rooms) === 24);

$occupiedRoom = null;
foreach ($rooms as $r) {
    if ($r['status'] === 'OCCUPEE' && !empty($r['current_occupant'])) {
        $occupiedRoom = $r;
        break;
    }
}
assertTest("Chambre occupée contient le nom complet de l'occupant", $occupiedRoom !== null && !empty($occupiedRoom['current_occupant']['client_name']));
echo "   -> Exemple: {$occupiedRoom['number']} occupée par {$occupiedRoom['current_occupant']['client_name']} ({$occupiedRoom['current_occupant']['client_phone']})\n";

// 3. Service Réservation & Règle Anti-Chevauchement
$resService = new ReservationService();
$clientModel = new Client();
$client = $clientModel->find(1);

$userSession = ['id' => $admin['id'], 'name' => $admin['name'], 'role' => 'admin'];

// Création d'une réservation de test sur une chambre libre
$targetRoom = null;
foreach ($rooms as $r) {
    if ($r['status'] === 'LIBRE' || $r['status'] === 'DISPONIBLE') {
        $targetRoom = $r;
        break;
    }
}

$testArrival = '2026-11-10';
$testDeparture = '2026-11-15';
$newRes = null;
try {
    $newRes = $resService->create([
        'client_id' => $client['id'],
        'room_id' => $targetRoom['id'],
        'arrival_date' => $testArrival,
        'departure_date' => $testDeparture,
        'guests' => 1,
        'rate_applied' => $targetRoom['daily_rate'],
        'deposit_amount' => 0,
        'notes' => 'Test unitaire automatique'
    ], $userSession);
    assertTest("Création réservation réussie (#{$newRes['id']})", $newRes !== null && $newRes['id'] > 0);
} catch (Exception $e) {
    assertTest("Création réservation réussie : " . $e->getMessage(), false);
}

// Tentative de double réservation sur les mêmes dates (doit échouer)
$overlapBlocked = false;
try {
    $resService->create([
        'client_id' => 2,
        'room_id' => $targetRoom['id'],
        'arrival_date' => '2026-11-12',
        'departure_date' => '2026-11-18',
        'guests' => 1,
        'rate_applied' => $targetRoom['daily_rate']
    ], $userSession);
} catch (Exception $e) {
    $overlapBlocked = true;
    echo "   -> Message anti-chevauchement capturé : {$e->getMessage()}\n";
}
assertTest("Anti-chevauchement : double réservation strictement bloquée", $overlapBlocked);

// 4. Cycle de vie : Check-in -> Check-out -> Statut À NETTOYER
if ($newRes) {
    try {
        $resService->checkin($newRes['id'], $userSession);
        $roomAfterCheckin = $roomModel->find($targetRoom['id']);
        assertTest("Check-in : statut chambre devient OCCUPEE", $roomAfterCheckin['status'] === 'OCCUPEE');

        $resService->checkout($newRes['id'], $userSession);
        $roomAfterCheckout = $roomModel->find($targetRoom['id']);
        assertTest("Check-out : statut chambre devient obligatoirement A_NETTOYER", $roomAfterCheckout['status'] === 'A_NETTOYER');

        // Housekeeping valide le nettoyage
        $roomModel->update($targetRoom['id'], ['status' => 'LIBRE']);
        $roomAfterClean = $roomModel->find($targetRoom['id']);
        assertTest("Validation gouvernance : statut chambre redevient LIBRE / DISPONIBLE", in_array($roomAfterClean['status'], ['LIBRE', 'DISPONIBLE']));
    } catch (Exception $e) {
        assertTest("Cycle check-in/check-out : " . $e->getMessage(), false);
    }
}

// 5. Facturation automatique
$invService = new InvoiceService();
if ($newRes) {
    try {
        $inv = $invService->generateFromReservation($newRes['id'], $userSession);
        assertTest("Génération automatique de facture (#{$inv['number']})", $inv !== null && !empty($inv['items']));
        echo "   -> Facture: {$inv['number']} - Total TTC: {$inv['total_ttc']} FCFA, Lignes: " . count($inv['items']) . "\n";
    } catch (Exception $e) {
        assertTest("Génération facture : " . $e->getMessage(), false);
    }
}

// 6. Tableau de bord & KPIs financiers
$financeService = new FinanceService();
$dashboard = $financeService->getDashboard();
assertTest("Tableau de bord financier calculé", !empty($dashboard['kpis']));
assertTest("Chiffre d'affaires total calculé", $dashboard['kpis']['total_revenue'] > 0);
assertTest("Solde de trésorerie disponible calculé", $dashboard['kpis']['net_cash'] > 0);
echo "   -> CA Encaissé : {$dashboard['kpis']['total_revenue']} FCFA\n";
echo "   -> Taux d'occupation : {$dashboard['kpis']['occupancy_rate']}%\n";
echo "   -> Trésorerie disponible : {$dashboard['kpis']['net_cash']} FCFA\n";

echo "\n=== RÉSULTATS DES TESTS ===\n";
echo "SUCCÈS: {$passed} | ÉCHECS: {$failed}\n";
