/* RESIDENCE MANAGER - Client API REST (assets/js/api.js) */

const API = {
  baseUrl: 'api.php',

  async request(endpoint, method = 'GET', data = null) {
    const options = {
      method: method,
      headers: {
        'Accept': 'application/json'
      },
      credentials: 'same-origin'
    };

    if (data && ['POST', 'PUT', 'DELETE'].includes(method)) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(data);
    }

    try {
      const url = `${this.baseUrl}/${endpoint.replace(/^\//, '')}`;
      const res = await fetch(url, options);
      const json = await res.json();

      if (!res.ok || json.status === 'error') {
        throw new Error(json.message || 'Une erreur est survenue lors de la communication avec le serveur.');
      }

      return json.data;
    } catch (err) {
      console.warn(`[API] Erreur sur ${method} ${endpoint}:`, err.message);
      throw err;
    }
  },

  /* Authentification */
  login(email, password) {
    return this.request('auth/login', 'POST', { email, password });
  },
  logout() {
    return this.request('auth/logout', 'POST');
  },
  me() {
    return this.request('auth/me');
  },

  /* Tableau de bord */
  getDashboard(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`dashboard${qs}`);
  },

  /* Chambres */
  getRooms() {
    return this.request('rooms');
  },
  getRoom(id) {
    return this.request(`rooms/${id}`);
  },
  createRoom(data) {
    return this.request('rooms', 'POST', data);
  },
  updateRoom(id, data) {
    return this.request(`rooms/${id}`, 'PUT', data);
  },
  deleteRoom(id) {
    return this.request(`rooms/${id}`, 'DELETE');
  },
  cleanRoom(id) {
    return this.request(`rooms/${id}/clean`, 'POST');
  },
  maintenanceRoom(id) {
    return this.request(`rooms/${id}/maintenance`, 'POST');
  },

  /* Réservations */
  getReservations(from = null, to = null, status = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    if (status) q.append('status', status);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`reservations${qs}`);
  },
  createReservation(data) {
    return this.request('reservations', 'POST', data);
  },
  checkin(id) {
    return this.request(`reservations/${id}/checkin`, 'POST');
  },
  checkout(id) {
    return this.request(`reservations/${id}/checkout`, 'POST');
  },
  extendReservation(id, newDeparture) {
    return this.request(`reservations/${id}/extend`, 'POST', { departure_date: newDeparture });
  },
  cancelReservation(id) {
    return this.request(`reservations/${id}/cancel`, 'POST');
  },

  /* Clients */
  getClients() {
    return this.request('clients');
  },
  createClient(data) {
    return this.request('clients', 'POST', data);
  },
  updateClient(id, data) {
    return this.request(`clients/${id}`, 'PUT', data);
  },
  deleteClient(id) {
    return this.request(`clients/${id}`, 'DELETE');
  },

  /* Encaissements */
  getPayments(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`payments${qs}`);
  },
  createPayment(data) {
    return this.request('payments', 'POST', data);
  },
  getReceipt(id) {
    return this.request(`payments/${id}/receipt`);
  },

  /* Dépenses */
  getExpenses(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`expenses${qs}`);
  },
  createExpense(data) {
    return this.request('expenses', 'POST', data);
  },
  submitExpense(id) {
    return this.request(`expenses/${id}/submit`, 'POST');
  },
  validateExpense(id) {
    return this.request(`expenses/${id}/validate`, 'POST');
  },
  rejectExpense(id) {
    return this.request(`expenses/${id}/reject`, 'POST');
  },
  payExpense(id, methodId, accountId) {
    return this.request(`expenses/${id}/pay`, 'POST', {
      payment_method_id: methodId,
      financial_account_id: accountId
    });
  },

  /* Achats & Fournisseurs */
  getPurchases(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`purchases${qs}`);
  },
  createPurchase(data) {
    return this.request('purchases', 'POST', data);
  },
  paySupplier(purchaseId, data) {
    return this.request(`purchases/${purchaseId}/pay`, 'POST', data);
  },
  getSuppliers() {
    return this.request('suppliers');
  },
  createSupplier(data) {
    return this.request('suppliers', 'POST', data);
  },
  updateSupplier(id, data) {
    return this.request(`suppliers/${id}`, 'PUT', data);
  },
  deleteSupplier(id) {
    return this.request(`suppliers/${id}`, 'DELETE');
  },

  /* Factures */
  getInvoices(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`invoices${qs}`);
  },
  createInvoice(data) {
    return this.request('invoices', 'POST', data);
  },
  invoiceFromReservation(reservationId) {
    return this.request('invoices/from-reservation', 'POST', { reservation_id: reservationId });
  },
  cancelInvoice(id) {
    return this.request(`invoices/${id}/cancel`, 'POST');
  },

  /* Rapports */
  getReports(from = null, to = null) {
    const q = new URLSearchParams();
    if (from) q.append('from', from);
    if (to) q.append('to', to);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return this.request(`reports${qs}`);
  },

  /* Paramètres */
  getSettings() {
    return this.request('settings');
  },
  updateBuilding(data) {
    return this.request('settings/building', 'POST', data);
  },
  saveRoomType(data) {
    return this.request('settings/room-types', 'POST', data);
  },
  deleteRoomType(id) {
    return this.request(`settings/room-types/${id}`, 'DELETE');
  },
  savePaymentMethod(data) {
    return this.request('settings/payment-methods', 'POST', data);
  },
  saveFinancialAccount(data) {
    return this.request('settings/financial-accounts', 'POST', data);
  },
  saveUser(data) {
    return this.request('settings/users', 'POST', data);
  },
  deleteUser(id) {
    return this.request(`settings/users/${id}`, 'DELETE');
  },
  savePermissions(role, modules) {
    return this.request('settings/permissions', 'POST', { role, modules });
  },
  getAuditLogs(limit = 100) {
    return this.request(`settings/audit-logs?limit=${limit}`);
  },
  resetDemoData(data) {
    return this.request('settings/reset-demo-data', 'POST', data);
  }
};
