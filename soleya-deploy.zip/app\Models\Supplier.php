<?php
// app/Models/Supplier.php

namespace App\Models;

class Supplier extends Model
{
    protected string $table = 'suppliers';

    public function allWithBalances(): array
    {
        $sql = "
            SELECT 
                s.*,
                COUNT(p.id) AS purchases_count,
                COALESCE(SUM(p.total_amount), 0) AS total_purchased,
                COALESCE((
                    SELECT SUM(sp.amount) 
                    FROM `supplier_payments` sp 
                    INNER JOIN `purchases` pu ON sp.purchase_id = pu.id 
                    WHERE pu.supplier_id = s.id
                ), 0) AS total_paid
            FROM `suppliers` s
            LEFT JOIN `purchases` p ON s.id = p.supplier_id
            GROUP BY s.id
            ORDER BY s.id DESC
        ";
        $suppliers = self::query($sql);
        foreach ($suppliers as &$sup) {
            $sup['balance_due'] = max(0, (int)$sup['total_purchased'] - (int)$sup['total_paid']);
        }
        return $suppliers;
    }
}
