<?php
// app/Models/Room.php

namespace App\Models;

class Room extends Model
{
    protected string $table = 'rooms';

    public function allWithDetails(): array
    {
        $sql = "
            SELECT r.*, t.name AS type_name
            FROM `rooms` r
            LEFT JOIN `room_types` t ON r.type_id = t.id
            ORDER BY r.id ASC
        ";
        $rooms = self::query($sql);

        foreach ($rooms as &$room) {
            if (empty($room['status']) || $room['status'] === 'DISPONIBLE') {
                $room['status'] = 'LIBRE';
            }
            $room['room_type_id'] = (int)$room['type_id'];
            $room['current_occupant'] = $this->getCurrentOccupant((int)$room['id']);
            $room['upcoming_reservation'] = $this->getUpcomingReservation((int)$room['id']);
        }

        return $rooms;
    }

    public function findWithDetails(int $id): ?array
    {
        $sql = "
            SELECT r.*, t.name AS type_name
            FROM `rooms` r
            LEFT JOIN `room_types` t ON r.type_id = t.id
            WHERE r.id = :id
            LIMIT 1
        ";
        $room = self::queryOne($sql, ['id' => $id]);
        if ($room) {
            if (empty($room['status']) || $room['status'] === 'DISPONIBLE') {
                $room['status'] = 'LIBRE';
            }
            $room['room_type_id'] = (int)$room['type_id'];
            $room['current_occupant'] = $this->getCurrentOccupant((int)$room['id']);
            $room['upcoming_reservation'] = $this->getUpcomingReservation((int)$room['id']);
        }
        return $room;
    }

    public function getCurrentOccupant(int $roomId): ?array
    {
        $sql = "
            SELECT 
                r.id AS reservation_id,
                r.arrival_date,
                r.departure_date,
                r.nights,
                r.total_amount,
                r.status AS reservation_status,
                c.id AS client_id,
                c.first_name,
                c.last_name,
                c.phone,
                c.email,
                c.nationality,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.reservation_id = r.id), 0) AS paid_amount
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            WHERE r.room_id = :room_id
              AND r.status = 'EN_COURS'
            LIMIT 1
        ";
        $res = self::queryOne($sql, ['room_id' => $roomId]);
        if ($res) {
            $res['balance_due'] = max(0, (int)$res['total_amount'] - (int)$res['paid_amount']);
            $res['client_full_name'] = $res['first_name'] . ' ' . $res['last_name'];
            $res['client_name'] = $res['client_full_name'];
            $res['client_phone'] = $res['phone'];
        }
        return $res;
    }

    public function getUpcomingReservation(int $roomId): ?array
    {
        $sql = "
            SELECT 
                r.id AS reservation_id,
                r.arrival_date,
                r.departure_date,
                r.nights,
                r.total_amount,
                r.status AS reservation_status,
                c.id AS client_id,
                c.first_name,
                c.last_name,
                c.phone,
                c.email
            FROM `reservations` r
            INNER JOIN `clients` c ON r.client_id = c.id
            WHERE r.room_id = :room_id
              AND r.status IN ('CONFIRMEE', 'EN_ATTENTE')
              AND r.departure_date >= CURDATE()
            ORDER BY r.arrival_date ASC
            LIMIT 1
        ";
        $res = self::queryOne($sql, ['room_id' => $roomId]);
        if ($res) {
            $res['client_full_name'] = $res['first_name'] . ' ' . $res['last_name'];
        }
        return $res;
    }

    public function syncStatus(int $roomId): void
    {
        $room = $this->find($roomId);
        if (!$room || in_array($room['status'], ['MAINTENANCE', 'A_NETTOYER'])) {
            return;
        }

        $active = self::queryOne("SELECT id FROM `reservations` WHERE `room_id` = :room_id AND `status` = 'EN_COURS' LIMIT 1", ['room_id' => $roomId]);
        if ($active) {
            $this->update($roomId, ['status' => 'OCCUPEE']);
            return;
        }

        $reserved = self::queryOne("
            SELECT id FROM `reservations` 
            WHERE `room_id` = :room_id 
              AND `status` IN ('CONFIRMEE', 'EN_ATTENTE') 
              AND `departure_date` > CURDATE()
              AND `arrival_date` <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
            LIMIT 1
        ", ['room_id' => $roomId]);

        if ($reserved) {
            $this->update($roomId, ['status' => 'RESERVEE']);
            return;
        }

        $this->update($roomId, ['status' => 'LIBRE']);
    }
}
