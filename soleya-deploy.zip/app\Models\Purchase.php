<?php
// app/Models/Purchase.php

namespace App\Models;

class Purchase extends Model
{
    protected string $table = 'purchases';

    public function allWithDetails(?string $from = null, ?string $to = null): array
    {
        $where = "1=1";
        $params = [];

        if ($from && $to) {
            $where .= " AND p.purchase_date BETWEEN :from AND :to";
            $params['from'] = $from;
            $params['to'] = $to;
        }

        $sql = "
            SELECT 
                p.*,
                s.name AS supplier_name,
                COALESCE((SELECT SUM(sp.amount) FROM `supplier_payments` sp WHERE sp.purchase_id = p.id), 0) AS paid_amount
            FROM `purchases` p
            INNER JOIN `suppliers` s ON p.supplier_id = s.id
            WHERE {$where}
            ORDER BY p.purchase_date DESC, p.id DESC
        ";

        $purchases = self::query($sql, $params);
        foreach ($purchases as &$p) {
            $p['balance_due'] = max(0, (int)$p['total_amount'] - (int)$p['paid_amount']);
            $p['items'] = self::query("SELECT * FROM `purchase_items` WHERE `purchase_id` = :pid", ['pid' => $p['id']]);
        }
        return $purchases;
    }

    public function nextReference(): string
    {
        $year = date('Y');
        $prefix = "ACH-{$year}-";
        $row = self::queryOne("SELECT COUNT(*) AS total FROM `purchases` WHERE `reference` LIKE :prefix", ['prefix' => "{$prefix}%"]);
        $next = ((int)$row['total']) + 1;
        return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
    }

    public function addItems(int $purchaseId, array $items): void
    {
        foreach ($items as $item) {
            $label = trim($item['label'] ?? '');
            $qty = (int)($item['qty'] ?? 1);
            $price = (int)($item['price'] ?? 0);
            if ($label !== '') {
                self::execute("INSERT INTO `purchase_items` (`purchase_id`, `label`, `quantity`, `unit_price`, `total_price`) VALUES (:pid, :lbl, :qty, :pr, :tot)", [
                    'pid' => $purchaseId,
                    'lbl' => $label,
                    'qty' => $qty,
                    'pr' => $price,
                    'tot' => $qty * $price
                ]);
            }
        }
    }

    public function addPayment(int $purchaseId, int $amount, int $accountId, int $methodId, ?string $date = null): void
    {
        self::execute("INSERT INTO `supplier_payments` (`purchase_id`, `payment_date`, `amount`, `financial_account_id`, `payment_method_id`) VALUES (:pid, :dt, :amt, :acc, :mth)", [
            'pid' => $purchaseId,
            'dt' => $date ?: date('Y-m-d'),
            'amt' => $amount,
            'acc' => $accountId,
            'mth' => $methodId
        ]);
    }
}
