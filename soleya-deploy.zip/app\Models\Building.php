<?php
// app/Models/Building.php

namespace App\Models;

class Building extends Model
{
    protected string $table = 'building';

    public function get(): array
    {
        $res = self::queryOne("SELECT * FROM `building` ORDER BY `id` ASC LIMIT 1");
        return $res ?: [
            'id' => 1,
            'name' => 'Résidence Prestige',
            'address' => 'Cocody, Riviera Palmeraie',
            'city' => 'Abidjan',
            'phone' => '+225 07 00 00 00 00',
            'email' => 'contact@residence-prestige.ci',
            'description' => 'Résidence meublée haut de gamme.',
            'manager' => 'Administrateur',
            'billing' => 'RCCM CI-ABJ-2024-B-00000',
            'tax_rate' => 0,
            'terms' => 'Paiement à réception de facture.'
        ];
    }

    public function saveBuilding(array $data): array
    {
        $allowed = ['name', 'address', 'city', 'phone', 'email', 'description', 'manager', 'billing', 'tax_rate', 'terms'];
        $filtered = [];
        foreach ($allowed as $col) {
            if (array_key_exists($col, $data)) {
                $filtered[$col] = $data[$col];
            }
        }
        $existing = self::queryOne("SELECT `id` FROM `building` ORDER BY `id` ASC LIMIT 1");
        if ($existing && !empty($existing['id'])) {
            $this->update((int)$existing['id'], $filtered);
        } else {
            $this->create($filtered);
        }
        return $this->get();
    }
}
