<?php
// views/layouts/main.php
/**
 * Layout principal PHP - RESIDENCE MANAGER
 * @var array $building
 * @var array $currentUser
 * @var array $permissions
 * @var array $rooms
 * @var array $clients
 * @var array $reservations
 * @var array $payments
 * @var array $expenses
 * @var array $purchases
 * @var array $suppliers
 * @var array $invoices
 * @var array $accounts
 * @var array $methods
 * @var array $dashboardData
 */

$rolesMap = [
    'admin' => 'Propriétaire / Admin',
    'manager' => 'Gestionnaire',
    'gestionnaire' => 'Gestionnaire',
    'reception' => 'Réceptionniste',
    'receptionniste' => 'Réceptionniste',
    'accountant' => 'Comptable',
    'comptable' => 'Comptable'
];

$modulesList = [
    ['id' => 'dashboard', 'label' => 'Tableau de bord', 'icon' => 'bi-house-door-fill'],
    ['id' => 'rooms', 'label' => 'Chambres', 'icon' => 'bi-door-closed-fill'],
    ['id' => 'reservations', 'label' => 'Réservations', 'icon' => 'bi-calendar-check-fill'],
    ['id' => 'clients', 'label' => 'Clients', 'icon' => 'bi-person-fill'],
    ['id' => 'stays', 'label' => 'Séjours', 'icon' => 'bi-key-fill'],
    ['id' => 'payments', 'label' => 'Encaissements', 'icon' => 'bi-wallet2'],
    ['id' => 'expenses', 'label' => 'Dépenses', 'icon' => 'bi-receipt'],
    ['id' => 'purchases', 'label' => 'Achats', 'icon' => 'bi-cart-fill'],
    ['id' => 'suppliers', 'label' => 'Fournisseurs', 'icon' => 'bi-truck'],
    ['id' => 'invoices', 'label' => 'Facturation', 'icon' => 'bi-file-earmark-text-fill'],
    ['id' => 'reports', 'label' => 'Rapports', 'icon' => 'bi-bar-chart-fill'],
    ['id' => 'settings', 'label' => 'Paramètres', 'icon' => 'bi-gear-fill']
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($building['name'] ?? 'Residence Manager') ?></title>
  <link rel="manifest" href="manifest.json">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/icons/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/icons/apple-touch-icon.png">
  <meta name="theme-color" content="#0f172a">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <!-- Application Principale PHP -->
  <div id="app">
    <aside id="sidebar">
      <div class="brand">
        <img src="assets/logo.jpg" alt="Logo" class="app-logo shadow-sm" style="width: 36px; height: 36px; object-fit: cover; border-radius: 8px; flex-shrink: 0;">
        <div id="brandName" class="text-truncate"><?= htmlspecialchars($building['name'] ?? 'Residence Manager') ?></div>
      </div>

      <nav id="nav">
        <?php foreach ($modulesList as $mod): ?>
          <?php if (in_array($mod['id'], $permissions, true)): ?>
            <a href="#/<?= $mod['id'] ?>" data-page="<?= $mod['id'] ?>">
              <i class="bi <?= $mod['icon'] ?>"></i>
              <span><?= htmlspecialchars($mod['label']) ?></span>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </nav>

      <div class="side-bottom">
        <div id="sideUser" class="side-user">
          <div class="avatar"><?= strtoupper(substr($currentUser['name'] ?? 'U', 0, 2)) ?></div>
          <div>
            <b><?= htmlspecialchars($currentUser['name'] ?? 'Utilisateur') ?></b>
            <small><?= $rolesMap[$currentUser['role']] ?? htmlspecialchars($currentUser['role']) ?></small>
          </div>
        </div>
        <a href="index.php?action=logout" class="btn-logout text-decoration-none d-block text-center mt-2">
          <i class="bi bi-box-arrow-left"></i> Déconnexion
        </a>
      </div>
    </aside>

    <div id="side-backdrop" data-act="sidetoggle"></div>

    <div id="main">
      <header id="topbar">
        <button class="burger" data-act="sidetoggle" aria-label="Menu"><i class="bi bi-list"></i></button>
        <div class="flex-grow-1">
          <h1 id="pageTitle">Tableau de bord</h1>
          <div id="pageSub">Vue d’ensemble de votre résidence</div>
        </div>

        <div id="periodBox" class="d-flex gap-2 align-items-center">
          <span id="customDates" class="d-none d-flex gap-1">
            <input type="date" id="pFrom" class="form-control form-control-sm" data-chg="pfrom">
            <input type="date" id="pTo" class="form-control form-control-sm" data-chg="pto">
          </span>
          <select id="periodSel" class="form-select period-sel" data-chg="period"></select>
        </div>

        <div class="dropdown">
          <button class="bell" data-bs-toggle="dropdown" aria-label="Notifications">
            <i class="bi bi-bell"></i>
            <span id="notifCount" class="badge-n">0</span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow" id="notifList"></ul>
        </div>

        <div id="topUser" class="top-user">
          <div class="avatar"><?= strtoupper(substr($currentUser['name'] ?? 'U', 0, 2)) ?></div>
          <span class="d-none d-md-inline"><?= htmlspecialchars($building['name'] ?? 'Residence') ?></span>
        </div>
      </header>

      <main id="view"></main>
    </div>
  </div>

  <div id="toasts"></div>
  <div class="modal fade" id="modal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" id="modalContent"></div>
    </div>
  </div>
  <div id="printZone"></div>

  <!-- Hydratation initiale des données serveur PHP MySQL -->
  <script>
    window.SESSION = <?= json_encode($currentUser, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_PERMISSIONS = <?= json_encode($permissions, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_ROLE_PERMISSIONS = <?= json_encode($rolePermissions ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_ROOMS = <?= json_encode($rooms, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_ROOM_TYPES = <?= json_encode($roomTypes ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_CLIENTS = <?= json_encode($clients, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_RESERVATIONS = <?= json_encode($reservations, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_PAYMENTS = <?= json_encode($payments, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_EXPENSES = <?= json_encode($expenses, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_PURCHASES = <?= json_encode($purchases, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_SUPPLIER_PAYMENTS = <?= json_encode($supplierPayments ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_SUPPLIERS = <?= json_encode($suppliers, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_INVOICES = <?= json_encode($invoices, JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_ACCOUNTS = <?= json_encode($accounts ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_METHODS = <?= json_encode($methods ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_USERS = <?= json_encode($usersList ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_AUDIT = <?= json_encode($auditLogs ?? [], JSON_UNESCAPED_UNICODE) ?>;
    window.SERVER_BUILDING = <?= json_encode($building, JSON_UNESCAPED_UNICODE) ?>;
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
  <script src="assets/js/data.js"></script>
  <script src="assets/js/api.js"></script>
  <script src="assets/js/ui.js"></script>
  <script src="assets/js/pages.js"></script>
  <script src="assets/js/pages2.js"></script>
  <script src="assets/js/app.js"></script>
  <script>
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').catch(() => {});
      });
    }
  </script>
</body>
</html>
