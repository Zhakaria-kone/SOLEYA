const fs = require('fs');
const vm = require('vm');

const domElements = {};
function makeEl(id) {
  return {
    id,
    innerHTML: '',
    textContent: '',
    value: '',
    dataset: {},
    classList: {
      add: () => {},
      remove: () => {},
      toggle: () => {},
      contains: () => false
    },
    appendChild: () => {},
    querySelectorAll: () => [],
    getContext: () => ({
      fillRect: () => {},
      clearRect: () => {},
      getImageData: () => {},
      putImageData: () => {},
      createImageData: () => {},
      setTransform: () => {},
      drawImage: () => {},
      save: () => {},
      fillText: () => {},
      restore: () => {},
      beginPath: () => {},
      moveTo: () => {},
      lineTo: () => {},
      closePath: () => {},
      stroke: () => {},
      fill: () => {}
    })
  };
}
const ids = ['login', 'app', 'nav', 'sideUser', 'topUser', 'periodSel', 'customDates', 'pFrom', 'pTo', 'pageTitle', 'pageSub', 'view', 'periodBox', 'notifCount', 'notifList', 'toasts', 'modal', 'modalContent', 'printZone'];
ids.forEach(id => { domElements['#' + id] = makeEl(id); });

const context = {
  window: { addEventListener: () => {} },
  document: {
    addEventListener: () => {},
    querySelector: sel => domElements[sel] || makeEl(sel),
    querySelectorAll: sel => [],
    createElement: tag => makeEl(tag),
    body: { classList: { add: () => {}, remove: () => {}, toggle: () => {} } }
  },
  sessionStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
  localStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
  location: { hash: '' },
  navigator: {},
  console: console
};
context.addEventListener = () => {};
context.window = context;
context.window.SESSION = { id: 1, name: 'Admin', role: 'admin' };
context.window.SERVER_PERMISSIONS = ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings'];
context.window.SERVER_ROOMS = [
  { id: 1, number: 'Chambre 101', type_id: 1, capacity: 2, daily_rate: 25000, status: 'OCCUPEE', current_occupant: { first_name: 'Marie', last_name: 'Dupont', phone: '+225 07 10 20 30 40', arrival_date: '2026-10-29', departure_date: '2026-11-04', nights: 6, total_amount: 150000 } },
  { id: 2, number: 'Chambre 102', type_id: 1, capacity: 2, daily_rate: 25000, status: '' },
  { id: 3, number: 'Chambre 103', type_id: 1, capacity: 2, daily_rate: 25000, status: 'DISPONIBLE' },
  { id: 4, number: 'Chambre 104', type_id: 1, capacity: 2, daily_rate: 25000, status: 'LIBRE' },
  { id: 5, number: 'Chambre 204', type_id: 1, capacity: 2, daily_rate: 25000, status: 'A_NETTOYER' },
  { id: 6, number: 'Chambre 304', type_id: 2, capacity: 3, daily_rate: 35000, status: 'MAINTENANCE' }
];
context.window.SERVER_CLIENTS = [];
context.window.SERVER_RESERVATIONS = [];
context.window.SERVER_PAYMENTS = [];
context.window.SERVER_EXPENSES = [];
context.window.SERVER_PURCHASES = [];
context.window.SERVER_SUPPLIERS = [];
context.window.SERVER_INVOICES = [];
context.window.SERVER_BUILDING = { name: 'Soleya' };

vm.createContext(context);

const files = [
  'assets/js/data.js',
  'assets/js/api.js',
  'assets/js/ui.js',
  'assets/js/pages.js',
  'assets/js/pages2.js',
  'assets/js/app.js'
];

let allOk = true;
for (const f of files) {
  try {
    const code = fs.readFileSync(f, 'utf8');
    vm.runInContext(code, context);
    console.log('SUCCESS:', f);
  } catch (err) {
    console.error('FAILED in', f, ':\n', err);
    allOk = false;
    break;
  }
}
if (allOk) {
  console.log('ALL JS FILES LOADED WITHOUT SYNTAX OR EVALUATION ERRORS!');
  
  // Test DB.init() and rendering every page
  
  try {
    vm.runInContext('DB.init();', context);
    console.log('SUCCESS: DB.init() executed.');
    
    vm.runInContext('renderLayout();', context);
    console.log('SUCCESS: renderLayout() executed.');
    
    const pages = ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings'];
    for (const p of pages) {
      context.location.hash = '#/' + p;
      vm.runInContext(`{
        location.hash = '#/${p}';
        const pageObj = PAGES['${p}'];
        if (pageObj && pageObj.f) {
          const v = $('#view');
          pageObj.f(v);
        }
      }`, context);
      console.log('SUCCESS: Rendered page ->', p);
    }
    console.log('ALL PAGES RENDERED SUCCESSFULLY!');
  } catch (err) {
    console.error('ERROR during page execution:', err);
  }
}
