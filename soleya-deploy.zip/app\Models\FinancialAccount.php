<?php
// app/Models/FinancialAccount.php

namespace App\Models;

class FinancialAccount extends Model
{
    protected string $table = 'financial_accounts';

    public function allWithBalances(): array
    {
        $accounts = $this->all('id ASC');
        foreach ($accounts as &$account) {
            $account['current_balance'] = $this->calculateBalance((int)$account['id'], (int)$account['opening_balance']);
        }
        return $accounts;
    }

    public function calculateBalance(int $accountId, int $openingBalance): int
    {
        $payments = (int)self::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `payments` WHERE `financial_account_id` = :id", ['id' => $accountId])['total'];
        $expenses = (int)self::queryOne("SELECT COALESCE(SUM(paid_amount), 0) AS total FROM `expenses` WHERE `financial_account_id` = :id", ['id' => $accountId])['total'];
        $suppPay = (int)self::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `supplier_payments` WHERE `financial_account_id` = :id", ['id' => $accountId])['total'];

        return $openingBalance + $payments - $expenses - $suppPay;
    }

    public function getTotalTreasury(): int
    {
        $accounts = $this->allWithBalances();
        $total = 0;
        foreach ($accounts as $a) {
            $total += (int)$a['current_balance'];
        }
        return $total;
    }
}
