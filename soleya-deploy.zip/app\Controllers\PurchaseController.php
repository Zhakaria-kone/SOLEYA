<?php
// app/Controllers/PurchaseController.php

namespace App\Controllers;

use App\Models\Purchase;
use App\Models\Supplier;
use App\Models\FinancialAccount;
use App\Models\PaymentMethod;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Helpers\Format;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class PurchaseController
{
    private Purchase $purchaseModel;
    private Supplier $supplierModel;
    private FinancialAccount $accountModel;
    private PaymentMethod $methodModel;

    public function __construct()
    {
        $this->purchaseModel = new Purchase();
        $this->supplierModel = new Supplier();
        $this->accountModel = new FinancialAccount();
        $this->methodModel = new PaymentMethod();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;

        $purchases = $this->purchaseModel->allWithDetails($from, $to);
        $supplierPayments = Purchase::query("SELECT * FROM `supplier_payments` ORDER BY `payment_date` DESC, `id` DESC");
        $suppliers = $this->supplierModel->all();
        $accounts = $this->accountModel->all();
        $methods = $this->methodModel->all();

        Response::success([
            'purchases' => $purchases,
            'supplier_payments' => $supplierPayments,
            'suppliers' => $suppliers,
            'accounts' => $accounts,
            'methods' => $methods
        ]);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $supplierId = (int)($params['supplier_id'] ?? 0);
        $date = !empty($params['purchase_date']) ? $params['purchase_date'] : Format::today();
        $notes = trim($params['notes'] ?? '');
        $items = $params['items'] ?? [];

        $supplier = $this->supplierModel->find($supplierId);
        if (!$supplier) {
            Response::error('Fournisseur invalide.', 422);
        }

        if (empty($items) || !is_array($items)) {
            Response::error('L’achat doit comporter au moins un article.', 422);
        }

        $total = 0;
        $validItems = [];
        foreach ($items as $it) {
            $lbl = trim($it['label'] ?? '');
            $qty = max(1, (int)($it['qty'] ?? 1));
            $price = (int)($it['price'] ?? 0);
            if ($lbl !== '' && $price > 0) {
                $total += ($qty * $price);
                $validItems[] = [
                    'label' => $lbl,
                    'qty' => $qty,
                    'price' => $price
                ];
            }
        }

        if (empty($validItems)) {
            Response::error('Veuillez renseigner des articles valides avec un prix supérieur à 0.', 422);
        }

        $ref = $this->purchaseModel->nextReference();
        $kind = in_array($params['kind'] ?? $params['notes'] ?? '', ['EXPLOITATION', 'IMMOBILISATION'], true)
            ? ($params['kind'] ?? $params['notes'])
            : 'EXPLOITATION';
        $terms = trim($params['terms'] ?? 'Comptant');

        $id = $this->purchaseModel->create([
            'reference' => $ref,
            'supplier_id' => $supplierId,
            'purchase_date' => $date,
            'kind' => $kind,
            'terms' => $terms,
            'total_amount' => $total,
            'author_name' => $user['name']
        ]);

        $this->purchaseModel->addItems($id, $validItems);

        $initialPaid = isset($params['paid_amount']) ? max(0, (int)$params['paid_amount']) : ($terms === 'Comptant' ? $total : 0);
        if ($initialPaid > 0) {
            $this->purchaseModel->addPayment($id, min($initialPaid, $total), 1, 1, $date);
        }

        AuditLog::log("Bon d’achat #{$ref}", "Achat chez {$supplier['name']} pour " . Format::money($total), $user['name']);

        Response::success($this->purchaseModel->find($id), 'Bon d’achat enregistré.', 201);
    }

    public function paySupplier(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('purchases');

        $id = (int)($routeParams['id'] ?? 0);
        $purchase = $this->purchaseModel->find($id);
        if (!$purchase) {
            Response::error('Achat introuvable.', 404);
        }

        $amount = (int)($params['amount'] ?? 0);
        $accountId = (int)($params['financial_account_id'] ?? 1);
        $methodId = (int)($params['payment_method_id'] ?? 1);
        $date = !empty($params['payment_date']) ? $params['payment_date'] : Format::today();

        if ($amount <= 0) {
            Response::error('Le montant doit être supérieur à 0.', 422);
        }

        $this->purchaseModel->addPayment($id, $amount, $accountId, $methodId, $date);

        // Recalculer le statut
        $paidRow = Purchase::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `supplier_payments` WHERE `purchase_id` = :id", ['id' => $id]);
        $totalPaid = (int)$paidRow['total'];
        $newStatus = ($totalPaid >= (int)$purchase['total_amount']) ? 'PAYEE' : 'PARTIELLE';

        AuditLog::log("Règlement fournisseur #{$purchase['reference']}", "Paiement de " . Format::money($amount) . " par {$user['name']}", $user['name']);

        Response::success([
            'purchase_id' => $id,
            'status' => $newStatus,
            'total_paid' => $totalPaid
        ], 'Règlement enregistré avec succès.');
    }
}
