-- database/schema.sql
-- RESIDENCE MANAGER - Schéma de base de données MySQL / MariaDB

CREATE DATABASE IF NOT EXISTS `residence_manager` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `residence_manager`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Configuration Résidence
DROP TABLE IF EXISTS `building`;
CREATE TABLE `building` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL DEFAULT 'Résidence Prestige',
    `address` VARCHAR(255) NOT NULL DEFAULT 'Cocody, Riviera Palmeraie',
    `city` VARCHAR(100) NOT NULL DEFAULT 'Abidjan',
    `phone` VARCHAR(50) NOT NULL DEFAULT '+225 07 00 00 00 00',
    `email` VARCHAR(150) NOT NULL DEFAULT 'contact@residence-prestige.ci',
    `description` TEXT NULL,
    `manager` VARCHAR(100) NOT NULL DEFAULT 'Administrateur',
    `billing` VARCHAR(255) NOT NULL DEFAULT 'RCCM CI-ABJ-2024-B-00000 — Compte contribuable 0000000A',
    `tax_rate` INT NOT NULL DEFAULT 0,
    `terms` VARCHAR(255) NOT NULL DEFAULT 'Paiement à réception de facture.',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Utilisateurs et permissions
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('admin', 'manager', 'reception', 'accountant') NOT NULL DEFAULT 'reception',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role` VARCHAR(50) NOT NULL,
    `module` VARCHAR(50) NOT NULL,
    UNIQUE KEY `uk_role_mod` (`role`, `module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Structure des chambres (autonome sans étage)
DROP TABLE IF EXISTS `room_types`;
CREATE TABLE `room_types` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `daily_rate` INT NOT NULL DEFAULT 0,
    `weekly_rate` INT NOT NULL DEFAULT 0,
    `monthly_rate` INT NOT NULL DEFAULT 0,
    `capacity` INT NOT NULL DEFAULT 2,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `number` VARCHAR(100) NOT NULL UNIQUE, -- Nom direct de la chambre
    `type_id` INT NOT NULL,
    `capacity` INT NOT NULL DEFAULT 2,
    `area` INT NULL,
    `daily_rate` INT NOT NULL DEFAULT 0,
    `weekly_rate` INT NOT NULL DEFAULT 0,
    `monthly_rate` INT NOT NULL DEFAULT 0,
    `status` ENUM('LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE') NOT NULL DEFAULT 'LIBRE',
    `equipment` TEXT NULL,
    `description` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`type_id`) REFERENCES `room_types`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Clients
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(100) NOT NULL,
    `last_name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `email` VARCHAR(150) NULL,
    `address` VARCHAR(255) NULL,
    `nationality` VARCHAR(100) DEFAULT 'Ivoirienne',
    `id_type` VARCHAR(50) DEFAULT 'CNI',
    `id_number` VARCHAR(100) NULL,
    `notes` TEXT NULL,
    `created_at` DATE NOT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_client_phone` (`phone`),
    INDEX `idx_client_name` (`last_name`, `first_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Réservations et Séjours
DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `client_id` INT NOT NULL,
    `room_id` INT NOT NULL,
    `arrival_date` DATE NOT NULL,
    `departure_date` DATE NOT NULL,
    `guests` INT NOT NULL DEFAULT 1,
    `rate_applied` INT NOT NULL DEFAULT 0, -- Tarif contractuel figé à la réservation
    `nights` INT NOT NULL DEFAULT 1,
    `discount_amount` INT NOT NULL DEFAULT 0,
    `extra_amount` INT NOT NULL DEFAULT 0,
    `total_amount` INT NOT NULL DEFAULT 0,
    `deposit_amount` INT NOT NULL DEFAULT 0,
    `status` ENUM('EN_ATTENTE', 'CONFIRMEE', 'EN_COURS', 'TERMINEE', 'ANNULEE', 'NO_SHOW') NOT NULL DEFAULT 'CONFIRMEE',
    `notes` TEXT NULL,
    `created_at` DATE NOT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE RESTRICT,
    INDEX `idx_res_dates` (`room_id`, `arrival_date`, `departure_date`),
    INDEX `idx_res_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Moyens de paiement & Comptes financiers
DROP TABLE IF EXISTS `payment_methods`;
CREATE TABLE `payment_methods` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `financial_accounts`;
CREATE TABLE `financial_accounts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `opening_balance` BIGINT NOT NULL DEFAULT 0,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Facturation
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `number` VARCHAR(50) NOT NULL UNIQUE,
    `type` ENUM('FACTURE', 'ACOMPTE', 'AVOIR') NOT NULL DEFAULT 'FACTURE',
    `issue_date` DATE NOT NULL,
    `client_id` INT NOT NULL,
    `reservation_id` INT NULL,
    `tax_rate` INT NOT NULL DEFAULT 0,
    `total_ht` BIGINT NOT NULL DEFAULT 0,
    `total_tva` BIGINT NOT NULL DEFAULT 0,
    `total_ttc` BIGINT NOT NULL DEFAULT 0,
    `status` ENUM('EMISE', 'ANNULEE') NOT NULL DEFAULT 'EMISE',
    `terms` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`reservation_id`) REFERENCES `reservations`(`id`) ON DELETE SET NULL,
    INDEX `idx_inv_date` (`issue_date`),
    INDEX `idx_inv_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `invoice_id` INT NOT NULL,
    `label` VARCHAR(255) NOT NULL,
    `quantity` INT NOT NULL DEFAULT 1,
    `unit_price` INT NOT NULL DEFAULT 0,
    `total_price` BIGINT NOT NULL DEFAULT 0,
    FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Encaissements & Règlements
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `reference` VARCHAR(50) NOT NULL UNIQUE,
    `type` ENUM('PAIEMENT', 'REMBOURSEMENT') NOT NULL DEFAULT 'PAIEMENT',
    `payment_date` DATE NOT NULL,
    `payment_time` VARCHAR(10) NULL,
    `reservation_id` INT NULL,
    `client_id` INT NOT NULL,
    `invoice_id` INT NULL,
    `amount` BIGINT NOT NULL, -- Positif pour encaissement, négatif pour remboursement
    `payment_method_id` INT NOT NULL,
    `financial_account_id` INT NOT NULL,
    `transaction_ref` VARCHAR(100) NULL,
    `author_name` VARCHAR(100) NOT NULL DEFAULT 'Administrateur',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`reservation_id`) REFERENCES `reservations`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`financial_account_id`) REFERENCES `financial_accounts`(`id`) ON DELETE RESTRICT,
    INDEX `idx_pay_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Fournisseurs & Achats
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NULL,
    `email` VARCHAR(150) NULL,
    `address` VARCHAR(255) NULL,
    `nature` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `reference` VARCHAR(50) NOT NULL UNIQUE,
    `supplier_id` INT NOT NULL,
    `purchase_date` DATE NOT NULL,
    `kind` ENUM('EXPLOITATION', 'IMMOBILISATION') NOT NULL DEFAULT 'EXPLOITATION',
    `terms` VARCHAR(50) NOT NULL DEFAULT 'Comptant',
    `total_amount` BIGINT NOT NULL DEFAULT 0,
    `author_name` VARCHAR(100) NOT NULL DEFAULT 'Administrateur',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON DELETE RESTRICT,
    INDEX `idx_purch_date` (`purchase_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `purchase_items`;
CREATE TABLE `purchase_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `purchase_id` INT NOT NULL,
    `label` VARCHAR(255) NOT NULL,
    `quantity` INT NOT NULL DEFAULT 1,
    `unit_price` INT NOT NULL DEFAULT 0,
    `total_price` BIGINT NOT NULL DEFAULT 0,
    FOREIGN KEY (`purchase_id`) REFERENCES `purchases`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `supplier_payments`;
CREATE TABLE `supplier_payments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `purchase_id` INT NOT NULL,
    `payment_date` DATE NOT NULL,
    `amount` BIGINT NOT NULL,
    `financial_account_id` INT NOT NULL,
    `payment_method_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`purchase_id`) REFERENCES `purchases`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`financial_account_id`) REFERENCES `financial_accounts`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Dépenses d'exploitation
DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `reference` VARCHAR(50) NOT NULL UNIQUE,
    `expense_date` DATE NOT NULL,
    `expense_time` VARCHAR(10) NULL,
    `category` VARCHAR(100) NOT NULL,
    `label` VARCHAR(255) NOT NULL,
    `amount` BIGINT NOT NULL,
    `paid_amount` BIGINT NOT NULL DEFAULT 0,
    `supplier_id` INT NULL,
    `room_id` INT NULL,
    `payment_method_id` INT NOT NULL,
    `financial_account_id` INT NOT NULL,
    `status` ENUM('BROUILLON', 'EN_ATTENTE_VALIDATION', 'VALIDEE', 'REJETEE', 'PAYEE', 'PARTIELLEMENT_PAYEE', 'ANNULEE') NOT NULL DEFAULT 'BROUILLON',
    `author_name` VARCHAR(100) NOT NULL DEFAULT 'Administrateur',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`financial_account_id`) REFERENCES `financial_accounts`(`id`) ON DELETE RESTRICT,
    INDEX `idx_exp_date` (`expense_date`),
    INDEX `idx_exp_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Journal d'Audit & Traçabilité
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_name` VARCHAR(100) NOT NULL,
    `action` VARCHAR(255) NOT NULL,
    `details` TEXT NULL,
    `ip_address` VARCHAR(50) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_ts` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
