<?php
// app/Controllers/DashboardController.php

namespace App\Controllers;

use App\Services\FinanceService;
use App\Models\Room;
use App\Models\Reservation;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;

class DashboardController
{
    private FinanceService $financeService;
    private Room $roomModel;
    private Reservation $reservationModel;

    public function __construct()
    {
        $this->financeService = new FinanceService();
        $this->roomModel = new Room();
        $this->reservationModel = new Reservation();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('dashboard');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;

        $finance = $this->financeService->getDashboard($from, $to);
        $rooms = $this->roomModel->allWithDetails();
        $recentReservations = $this->reservationModel->allWithDetails();
        // Limiter à 5 réservations récentes
        $recentReservations = array_slice($recentReservations, 0, 5);

        Response::success([
            'finance' => $finance,
            'rooms' => $rooms,
            'recent_reservations' => $recentReservations
        ]);
    }
}
