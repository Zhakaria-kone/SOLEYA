<?php
// app/Models/Payment.php

namespace App\Models;

class Payment extends Model
{
    protected string $table = 'payments';

    public function allWithDetails(?string $from = null, ?string $to = null): array
    {
        $where = "1=1";
        $params = [];

        if ($from && $to) {
            $where .= " AND p.payment_date BETWEEN :from AND :to";
            $params['from'] = $from;
            $params['to'] = $to;
        }

        $sql = "
            SELECT 
                p.*,
                c.first_name,
                c.last_name,
                rm.number AS room_name,
                m.name AS method_name,
                a.name AS account_name
            FROM `payments` p
            INNER JOIN `clients` c ON p.client_id = c.id
            LEFT JOIN `reservations` r ON p.reservation_id = r.id
            LEFT JOIN `rooms` rm ON r.room_id = rm.id
            LEFT JOIN `payment_methods` m ON p.payment_method_id = m.id
            LEFT JOIN `financial_accounts` a ON p.financial_account_id = a.id
            WHERE {$where}
            ORDER BY p.payment_date DESC, p.id DESC
        ";

        $rows = self::query($sql, $params);
        foreach ($rows as &$row) {
            $row['client_full_name'] = $row['first_name'] . ' ' . $row['last_name'];
        }
        return $rows;
    }

    public function nextReference(): string
    {
        $year = date('Y');
        $prefix = "PAY-{$year}-";
        $row = self::queryOne("SELECT COUNT(*) AS total FROM `payments` WHERE `reference` LIKE :prefix", ['prefix' => "{$prefix}%"]);
        $next = ((int)$row['total']) + 1;
        return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
    }

    public function findReceiptData(int $id): ?array
    {
        $sql = "
            SELECT 
                p.*,
                c.first_name,
                c.last_name,
                c.phone AS client_phone,
                c.email AS client_email,
                c.address AS client_address,
                rm.number AS room_name,
                r.arrival_date,
                r.departure_date,
                r.total_amount AS reservation_total,
                m.name AS method_name,
                a.name AS account_name
            FROM `payments` p
            INNER JOIN `clients` c ON p.client_id = c.id
            LEFT JOIN `reservations` r ON p.reservation_id = r.id
            LEFT JOIN `rooms` rm ON r.room_id = rm.id
            LEFT JOIN `payment_methods` m ON p.payment_method_id = m.id
            LEFT JOIN `financial_accounts` a ON p.financial_account_id = a.id
            WHERE p.id = :id
            LIMIT 1
        ";
        $row = self::queryOne($sql, ['id' => $id]);
        if ($row) {
            $row['client_full_name'] = $row['first_name'] . ' ' . $row['last_name'];
            if ($row['reservation_id']) {
                $paid = (int)self::queryOne("SELECT COALESCE(SUM(amount), 0) AS total FROM `payments` WHERE `reservation_id` = :rid", ['rid' => $row['reservation_id']])['total'];
                $row['reservation_paid'] = $paid;
                $row['reservation_balance'] = max(0, (int)$row['reservation_total'] - $paid);
            }
        }
        return $row;
    }
}
