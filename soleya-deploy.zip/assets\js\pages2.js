/* RESIDENCE MANAGER - Pages : encaissements, dépenses, achats, fournisseurs, facturation, rapports, paramètres */
const INV_TYPES = {
  FACTURE: ['Facture', 'FAC'],
  ACOMPTE: ['Facture d’acompte', 'AC'],
  AVOIR: ['Avoir', 'AV']
};
const nextInvNumber = type => {
  const p = INV_TYPES[type][1] + '-' + TODAY.slice(0, 4);
  return p + '-' + String(DB.s.invoices.filter(i => i.number.startsWith(p)).length + 1).padStart(3, '0');
};
const defaultAccount = mid => (mid >= 1 && mid <= 5 ? mid : 6);
const nowTime = () => new Date().toTimeString().slice(0, 5);
const mOpts = () => DB.s.methods.filter(m => m.active).map(m => ({ v: m.id, l: m.name }));
const aOpts = () => DB.s.accounts.filter(a => a.active).map(a => ({ v: a.id, l: a.name }));
// isAdmin est déjà défini globalement dans data.js

/* ===================== ENCAISSEMENTS ===================== */
function openPaymentForm(resId) {
  const list = DB.s.reservations.filter(r => !['ANNULEE', 'NO_SHOW'].includes(r.status) && (resBalance(r) > 0 || r.id === resId));
  openForm({
    title: 'Enregistrer un paiement',
    size: 'modal-lg',
    fields: [
      { k: 'resId', label: 'Réservation / séjour', type: 'select', numeric: true, required: true, empty: true, col: 12, options: () => list.map(r => ({ v: r.id, l: `${clientName(r.clientId)} — ${roomNum(r.roomId)} — solde ${fcfa(resBalance(r))}` })) },
      { k: 'date', label: 'Date', type: 'date', required: true, col: 4 },
      { k: 'amount', label: 'Montant (FCFA)', type: 'number', min: 1, required: true, col: 4 },
      { k: 'info', label: 'Solde restant', type: 'info', col: 4 },
      { k: 'methodId', label: 'Moyen de paiement', type: 'select', numeric: true, options: mOpts },
      { k: 'accountId', label: 'Compte destinataire', type: 'select', numeric: true, options: aOpts },
      { k: 'txRef', label: 'Référence transaction / reçu papier', col: 12 }
    ],
    values: { resId: resId || '', date: TODAY, methodId: 1, accountId: 1, amount: resId ? Math.max(0, resBalance(DB.find('reservations', resId))) : 0 },
    onInput: (f, d) => {
      if (f.dataset.r !== String(d.resId)) {
        if (f.dataset.r !== undefined || resId) {
          const r = DB.find('reservations', d.resId);
          if (r && f.dataset.r !== undefined) f.elements.amount.value = Math.max(0, resBalance(r));
        }
        f.dataset.r = String(d.resId);
      }
      if (f.dataset.m !== String(d.methodId)) {
        if (f.dataset.m !== undefined) f.elements.accountId.value = defaultAccount(d.methodId);
        f.dataset.m = String(d.methodId);
      }
      const r = DB.find('reservations', d.resId);
      $('#f_info', f).innerHTML = r ? `Reste à payer : <b>${fcfa(resBalance(r) - Number(f.elements.amount.value || 0))}</b>` : '—';
    },
    onSubmit: async d => {
      const r = DB.find('reservations', d.resId);
      if (!r) return 'Réservation introuvable.';
      if (d.amount > resBalance(r)) return `Le montant dépasse le solde restant (${fcfa(resBalance(r))}).`;
      const inv = DB.s.invoices.filter(i => i.resId === r.id && i.status !== 'ANNULEE').pop();
      let srvPay = null;
      try {
        if (typeof API !== 'undefined') {
          srvPay = await API.createPayment({
            reservation_id: r.id,
            client_id: r.clientId,
            invoice_id: inv ? inv.id : null,
            amount: d.amount,
            payment_method_id: d.methodId,
            financial_account_id: d.accountId,
            transaction_ref: d.txRef,
            payment_date: d.date,
            payment_time: nowTime(),
            type: 'PAIEMENT'
          });
        }
      } catch (e) {
        console.warn('API payment error:', e);
      }
      const p = DB.add('payments', {
        id: srvPay && srvPay.id ? Number(srvPay.id) : undefined,
        ref: (srvPay && srvPay.reference) ? srvPay.reference : DB.ref('PAY', 'payments'),
        type: 'PAIEMENT',
        date: d.date,
        time: nowTime(),
        resId: r.id,
        clientId: r.clientId,
        invoiceId: inv ? inv.id : null,
        amount: d.amount,
        methodId: d.methodId,
        accountId: d.accountId,
        txRef: d.txRef,
        author: SESSION.name
      });
      DB.log(`Paiement ${p.ref} de ${fcfa(p.amount)}`);
      toast(`Paiement enregistré — solde restant ${fcfa(resBalance(r))}`);
      renderPage();
      setTimeout(() => showReceipt(p.id), 450);
    }
  });
}

function showReceipt(id) {
  const p = DB.find('payments', id), b = DB.s.building, r = DB.find('reservations', p.resId);
  const html = `
    <div class="doc">
      <div class="d-flex justify-content-between align-items-start gap-3">
        <div class="d-flex align-items-start gap-3">
          <img src="assets/logo.jpg" alt="Logo" class="doc-logo" style="width:64px;height:64px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0;flex-shrink:0;">
          <div>
            <h4 class="mb-0 fw-bold">${esc(b.name)}</h4>
            <div class="small text-muted mt-1">${esc(b.address)}, ${esc(b.city)}<br>${esc(b.phone)} — ${esc(b.email)}</div>
          </div>
        </div>
        <div class="text-end">
          <h4 class="mb-0 text-primary">${p.amount < 0 ? 'REÇU DE REMBOURSEMENT' : 'REÇU DE PAIEMENT'}</h4>
          <b>${p.ref}</b><br><small class="text-muted">${fdate(p.date)} ${p.time || ''}</small>
        </div>
      </div>
      <hr class="my-3">
      <p>
        <b>Client :</b> ${esc(clientName(p.clientId))}<br>
        ${r ? `<b>Séjour :</b> ${roomNum(r.roomId)} du ${fdate(r.arrival)} au ${fdate(r.departure)}<br>` : ''}
        <b>Moyen de paiement :</b> ${esc(methodName(p.methodId))} — ${esc(accountName(p.accountId))}
        ${p.txRef ? '<br><b>Réf. transaction :</b> ' + esc(p.txRef) : ''}
      </p>
      <h3 class="text-center my-4">${fcfa(Math.abs(p.amount))}</h3>
      ${r ? `<p class="text-end">Total séjour : ${fcfa(resTotal(r))} — Total payé : ${fcfa(resPaid(r))} — <b>Solde : ${fcfa(resBalance(r))}</b></p>` : ''}
      <p class="small text-muted">Reçu délivré par ${esc(p.author)}.</p>
    </div>
  `;
  showModal(`
    <div class="modal-header"><h5 class="modal-title">Reçu ${p.ref}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">${html}</div>
    <div class="modal-footer"><button class="btn btn-primary" id="prt"><i class="bi bi-printer"></i> Imprimer / Télécharger PDF</button></div>
  `, 'modal-lg');
  $('#prt').onclick = () => printDoc(html);
}

ACT['receipt'] = id => showReceipt(id);
ACT['pay.new'] = () => openPaymentForm();
ACT['pay.refund'] = id => {
  const p = DB.find('payments', id);
  openForm({
    title: 'Remboursement — ' + p.ref,
    size: 'modal-sm',
    fields: [
      { k: 'amount', label: `Montant à rembourser (max ${fcfa(p.amount)})`, type: 'number', min: 1, required: true, col: 12 },
      { k: 'motif', label: 'Motif du remboursement', col: 12 }
    ],
    values: { amount: p.amount },
    onSubmit: d => {
      if (d.amount > p.amount) return 'Montant supérieur au paiement initial.';
      const n = DB.add('payments', {
        ref: DB.ref('REM', 'payments'),
        type: 'REMBOURSEMENT',
        date: TODAY,
        time: nowTime(),
        resId: p.resId,
        clientId: p.clientId,
        invoiceId: p.invoiceId,
        amount: -d.amount,
        methodId: p.methodId,
        accountId: p.accountId,
        txRef: d.motif,
        author: SESSION.name
      });
      DB.log(`Remboursement ${n.ref}`);
      toast('Remboursement enregistré (mouvement comptable distinct)');
      renderPage();
    }
  });
};

const paymentsCfg = {
  key: 'payments',
  coll: 'payments',
  singular: 'paiement',
  add: false,
  edit: false,
  rows: () => [...DB.s.payments].sort((a, b) => (b.date + (b.time || '')).localeCompare(a.date + (a.time || ''))),
  search: p => `${p.ref} ${clientName(p.clientId)} ${methodName(p.methodId)} ${p.txRef}`,
  toolbar: () => `<button class="btn btn-primary" data-act="pay.new"><i class="bi bi-plus-lg"></i> Nouvel encaissement</button>`,
  cols: [
    { l: 'Référence', f: p => `<b>${p.ref}</b>` },
    { l: 'Date', f: p => fdate(p.date) + ' <small class="text-muted">' + (p.time || '') + '</small>' },
    { l: 'Client', f: p => esc(clientName(p.clientId)) },
    { l: 'Chambre', f: p => { const r = DB.find('reservations', p.resId); return r ? `<b>${roomNum(r.roomId)}</b>` : '—'; } },
    { l: 'Moyen', f: p => esc(methodName(p.methodId)) },
    { l: 'Compte', f: p => esc(accountName(p.accountId)) },
    { l: 'Montant', f: p => `<b class="${p.amount < 0 ? 'text-danger' : 'text-success'}">${fcfa(p.amount)}</b>` }
  ],
  actions: p => `<button class="btn btn-sm btn-outline-primary" title="Reçu" data-act="receipt" data-id="${p.id}"><i class="bi bi-printer"></i></button> `
    + (p.amount > 0 ? `<button class="btn btn-sm btn-outline-danger" title="Rembourser" data-act="pay.refund" data-id="${p.id}"><i class="bi bi-arrow-return-left"></i></button>` : '')
};

CRUD.payments = paymentsCfg;
paymentsCfg.state = { q: '', page: 1 };

function pagePayments(el) {
  const R = periodRange(), inc = sumPay(R);
  const cards = `
    <div class="row g-3 mb-3">
      <div class="col-md-4"><div class="mini-card">Encaissements (${PERIODS[PERIOD.key]})<b class="text-success">${fcfa(inc)}</b></div></div>
      <div class="col-md-4"><div class="mini-card">Créances clients restantes<b class="text-danger">${fcfa(DB.s.reservations.filter(r => !['ANNULEE', 'NO_SHOW'].includes(r.status)).reduce((a, r) => a + Math.max(0, resBalance(r)), 0))}</b></div></div>
      <div class="col-md-4"><div class="mini-card">Trésorerie disponible<b>${fcfa(treasury())}</b></div></div>
    </div>
  `;
  el.innerHTML = cards + crudHtml(paymentsCfg);
}

/* ===================== DÉPENSES ===================== */
const expCfg = {
  key: 'expenses',
  coll: 'expenses',
  singular: 'dépense',
  addLabel: 'Nouvelle dépense',
  remove: true,
  canRemove: e => e.status === 'BROUILLON',
  rows: () => [...DB.s.expenses].sort((a, b) => b.date.localeCompare(a.date)),
  search: e => `${e.ref} ${e.category} ${e.label} ${supplierName(e.supplierId)}`,
  cols: [
    { l: 'Référence', f: e => `<b>${e.ref}</b>` },
    { l: 'Date', f: e => fdate(e.date) },
    { l: 'Catégorie', f: e => esc(e.category) },
    { l: 'Désignation', f: e => esc(e.label) },
    { l: 'Fournisseur', f: e => e.supplierId ? esc(supplierName(e.supplierId)) : '—' },
    { l: 'Montant', f: e => fcfa(e.amount) },
    { l: 'Réglé', f: e => fcfa(e.paidAmount) },
    { l: 'Statut', f: e => badge(EXP_ST, e.status) }
  ],
  actions: e => {
    const b = (a, i, t, c) => `<button class="btn btn-sm btn-${c}" title="${t}" data-act="${a}" data-id="${e.id}"><i class="bi ${i}"></i></button> `;
    let h = '';
    if (e.status === 'BROUILLON') h += b('exp.submit', 'bi-send', 'Soumettre à validation', 'outline-primary');
    if (e.status === 'EN_ATTENTE_VALIDATION' && isAdmin()) h += b('exp.ok', 'bi-check-lg', 'Valider dépense', 'success') + b('exp.no', 'bi-x-lg', 'Rejeter', 'danger');
    if (['VALIDEE', 'PARTIELLEMENT_PAYEE'].includes(e.status)) h += b('exp.pay', 'bi-cash', 'Enregistrer le règlement', 'outline-success');
    return h;
  },
  fields: [
    { k: 'date', label: 'Date', type: 'date', required: true, col: 4 },
    { k: 'category', label: 'Catégorie', type: 'select', options: EXPENSE_CATS.map(c => ({ v: c, l: c })), col: 4 },
    { k: 'amount', label: 'Montant (FCFA)', type: 'number', min: 1, required: true, col: 4 },
    { k: 'label', label: 'Désignation', required: true, col: 12 },
    { k: 'supplierId', label: 'Fournisseur', type: 'select', numeric: true, empty: true, options: () => DB.s.suppliers.map(s => ({ v: s.id, l: s.name })) },
    { k: 'roomId', label: 'Chambre concernée (facultatif)', type: 'select', numeric: true, empty: true, options: () => DB.s.rooms.map(r => ({ v: r.id, l: r.number })) },
    { k: 'methodId', label: 'Moyen de paiement', type: 'select', numeric: true, options: mOpts },
    { k: 'accountId', label: 'Compte financier', type: 'select', numeric: true, options: aOpts }
  ],
  defaults: () => ({ date: TODAY, category: 'Autres', methodId: 1, accountId: 1 }),
  validate: (d, cur) => cur && !['BROUILLON', 'REJETEE'].includes(cur.status) ? 'Une dépense déjà validée ne peut plus être modifiée.' : null,
  before: (d, cur) => {
    if (!cur) {
      d.ref = DB.ref('DEP', 'expenses');
      d.status = 'BROUILLON';
      d.paidAmount = 0;
      d.author = SESSION.name;
      d.time = nowTime();
    }
  }
};

CRUD.expenses = expCfg;
expCfg.state = { q: '', page: 1 };

const setExp = async (id, st, msg) => {
  try {
    if (typeof API !== 'undefined') {
      if (st === 'EN_ATTENTE_VALIDATION') await API.submitExpense(id);
      else if (st === 'VALIDEE') await API.validateExpense(id);
      else if (st === 'REJETEE') await API.rejectExpense(id);
    }
  } catch (e) {
    console.warn('API expense error:', e);
  }
  DB.upd('expenses', id, { status: st });
  DB.log(`${msg} (dépense #${id})`);
  toast(msg);
  renderPage();
};

ACT['exp.submit'] = id => setExp(id, 'EN_ATTENTE_VALIDATION', 'Dépense soumise pour validation');
ACT['exp.ok'] = id => setExp(id, 'VALIDEE', 'Dépense validée (aucun impact trésorerie avant règlement)');
ACT['exp.no'] = id => setExp(id, 'REJETEE', 'Dépense rejetée');
ACT['exp.pay'] = id => {
  const e = DB.find('expenses', id), rest = e.amount - e.paidAmount;
  openForm({
    title: 'Règlement — ' + e.ref,
    size: 'modal-sm',
    fields: [
      { k: 'amount', label: `Montant payé (reste ${fcfa(rest)})`, type: 'number', min: 1, required: true, col: 12 },
      { k: 'methodId', label: 'Moyen de paiement', type: 'select', numeric: true, options: mOpts, col: 12 },
      { k: 'accountId', label: 'Compte débité', type: 'select', numeric: true, options: aOpts, col: 12 }
    ],
    values: { amount: rest, methodId: e.methodId, accountId: e.accountId },
    onSubmit: async d => {
      if (d.amount > rest) return 'Montant supérieur au reste à payer.';
      const paid = e.paidAmount + d.amount;
      try {
        if (typeof API !== 'undefined') await API.payExpense(id, d.methodId, d.accountId);
      } catch (err) {
        console.warn('API pay expense error:', err);
      }
      DB.upd('expenses', id, {
        paidAmount: paid,
        status: paid >= e.amount ? 'PAYEE' : 'PARTIELLEMENT_PAYEE',
        methodId: d.methodId,
        accountId: d.accountId
      });
      DB.log(`Règlement ${e.ref} ${fcfa(d.amount)}`);
      toast('Règlement enregistré — trésorerie actualisée');
      renderPage();
    }
  });
};

function pageExpenses(el) {
  el.innerHTML = `
    <div class="row g-3 mb-3">
      <div class="col-md-4"><div class="mini-card">Dépenses payées (${PERIODS[PERIOD.key]})<b>${fcfa(sumExp(periodRange()))}</b></div></div>
      <div class="col-md-4"><div class="mini-card">En attente de validation<b class="text-warning">${DB.s.expenses.filter(e => e.status === 'EN_ATTENTE_VALIDATION').length}</b></div></div>
      <div class="col-md-4"><div class="mini-card">Validées non encore réglées<b class="text-danger">${fcfa(DB.s.expenses.filter(e => ['VALIDEE', 'PARTIELLEMENT_PAYEE'].includes(e.status)).reduce((a, e) => a + e.amount - e.paidAmount, 0))}</b></div></div>
    </div>
  ` + crudHtml(expCfg);
}

/* ===================== ACHATS ===================== */
const purCfg = {
  key: 'purchases',
  coll: 'purchases',
  singular: 'achat',
  addLabel: 'Nouvel achat',
  rows: () => [...DB.s.purchases].sort((a, b) => b.date.localeCompare(a.date)),
  search: p => `${p.ref} ${supplierName(p.supplierId)} ${p.items.map(i => i.label).join(' ')}`,
  cols: [
    { l: 'Référence', f: p => `<b>${p.ref}</b>` },
    { l: 'Date', f: p => fdate(p.date) },
    { l: 'Fournisseur', f: p => esc(supplierName(p.supplierId)) },
    { l: 'Articles', f: p => esc(p.items.map(i => i.label).join(', ')) },
    { l: 'Nature', f: p => p.kind === 'IMMOBILISATION' ? '<span class="badge text-bg-info">Immobilisation</span>' : '<span class="badge text-bg-light border">Exploitation</span>' },
    { l: 'Total', f: p => fcfa(purchTotal(p)) },
    { l: 'Payé', f: p => fcfa(purchPaid(p)) },
    { l: 'Reste dû', f: p => { const b = purchTotal(p) - purchPaid(p); return `<span class="${b > 0 ? 'text-danger fw-semibold' : 'text-success'}">${fcfa(b)}</span>`; } }
  ],
  actions: p => purchTotal(p) - purchPaid(p) > 0 ? `<button class="btn btn-sm btn-outline-success" title="Règlement dette fournisseur" data-act="pur.pay" data-id="${p.id}"><i class="bi bi-cash"></i></button> ` : '',
  fields: [
    { k: 'supplierId', label: 'Fournisseur', type: 'select', numeric: true, required: true, empty: true, options: () => DB.s.suppliers.map(s => ({ v: s.id, l: s.name })), col: 4 },
    { k: 'date', label: 'Date', type: 'date', required: true, col: 4 },
    { k: 'kind', label: 'Nature de la charge', type: 'select', options: [{ v: 'EXPLOITATION', l: 'Charge d’exploitation' }, { v: 'IMMOBILISATION', l: 'Immobilisation' }], col: 4 },
    { k: 'items', label: 'Articles (désignation / quantité / prix unitaire)', type: 'lines', col: 12 },
    { k: 'terms', label: 'Conditions de règlement', type: 'select', options: [{ v: 'Comptant', l: 'Payé immédiatement' }, { v: 'Partiel', l: 'Paiement partiel' }, { v: 'À crédit', l: 'À crédit (dette)' }], col: 4 },
    { k: 'paid', label: 'Montant réglé immédiatement', type: 'number', min: 0, col: 4 },
    { k: 'tot', label: 'Total calculé', type: 'info', col: 4 }
  ],
  defaults: () => ({ date: TODAY, kind: 'EXPLOITATION', terms: 'Comptant', paid: 0, items: [{ label: '', qty: 1, price: 0 }] }),
  onInput: (f, d) => { $('#f_tot', f).innerHTML = '<b>' + fcfa(d.items.reduce((a, i) => a + i.qty * i.price, 0)) + '</b>'; },
  validate: d => d.items.length ? null : 'Ajoutez au moins un article.',
  before: (d, cur) => {
    const tot = d.items.reduce((a, i) => a + i.qty * i.price, 0);
    purCfg._pay = cur ? 0 : (d.terms === 'Comptant' ? tot : d.terms === 'À crédit' ? 0 : Math.min(d.paid, tot));
    delete d.paid;
    if (!cur) {
      d.ref = DB.ref('ACH', 'purchases');
      d.author = SESSION.name;
    }
  },
  after: o => {
    if (purCfg._pay > 0) {
      DB.add('supplierPayments', {
        purchaseId: o.id,
        date: o.date,
        amount: purCfg._pay,
        accountId: 1,
        methodId: 1
      });
      purCfg._pay = 0;
    }
  }
};

CRUD.purchases = purCfg;
purCfg.state = { q: '', page: 1 };

ACT['pur.pay'] = id => {
  const p = DB.find('purchases', id), rest = purchTotal(p) - purchPaid(p);
  openForm({
    title: 'Règlement dette fournisseur — ' + p.ref,
    size: 'modal-sm',
    fields: [
      { k: 'amount', label: `Montant (reste dû ${fcfa(rest)})`, type: 'number', min: 1, required: true, col: 12 },
      { k: 'methodId', label: 'Moyen de paiement', type: 'select', numeric: true, options: mOpts, col: 12 },
      { k: 'accountId', label: 'Compte prélevé', type: 'select', numeric: true, options: aOpts, col: 12 }
    ],
    values: { amount: rest, methodId: 1, accountId: 1 },
    onSubmit: async d => {
      if (d.amount > rest) return 'Montant supérieur au reste dû.';
      try {
        if (typeof API !== 'undefined') {
          await API.paySupplier(p.id, {
            amount: d.amount,
            financial_account_id: d.accountId,
            payment_method_id: d.methodId,
            payment_date: TODAY
          });
        }
      } catch (e) {
        console.warn('API paySupplier error:', e);
      }
      DB.add('supplierPayments', { purchaseId: p.id, date: TODAY, amount: d.amount, accountId: d.accountId, methodId: d.methodId });
      DB.log(`Règlement fournisseur ${p.ref} ${fcfa(d.amount)}`);
      toast('Règlement fournisseur enregistré');
      renderPage();
    }
  });
};

function pagePurchases(el) {
  el.innerHTML = `
    <div class="row g-3 mb-3">
      <div class="col-md-6"><div class="mini-card">Dettes fournisseurs en cours<b class="text-danger">${fcfa(DB.s.purchases.reduce((a, p) => a + purchTotal(p) - purchPaid(p), 0))}</b></div></div>
      <div class="col-md-6"><div class="mini-card">Total des achats enregistrés<b>${fcfa(DB.s.purchases.reduce((a, p) => a + purchTotal(p), 0))}</b></div></div>
    </div>
  ` + crudHtml(purCfg);
}

/* ===================== FOURNISSEURS ===================== */
const supCfg = {
  key: 'suppliers',
  coll: 'suppliers',
  singular: 'fournisseur',
  addLabel: 'Nouveau fournisseur',
  remove: true,
  canRemove: s => !DB.s.purchases.some(p => p.supplierId === s.id),
  rows: () => DB.s.suppliers,
  search: s => `${s.name} ${s.phone} ${s.nature}`,
  cols: [
    { l: 'Nom', f: s => `<b>${esc(s.name)}</b>` },
    { l: 'Téléphone', f: s => esc(s.phone) },
    { l: 'E-mail', f: s => esc(s.email) },
    { l: 'Nature des prestations', f: s => esc(s.nature) },
    { l: 'Achats', f: s => DB.s.purchases.filter(p => p.supplierId === s.id).length },
    { l: 'Solde fournisseur', f: s => { const b = DB.s.purchases.filter(p => p.supplierId === s.id).reduce((a, p) => a + purchTotal(p) - purchPaid(p), 0); return `<span class="${b > 0 ? 'text-danger fw-semibold' : 'text-muted'}">${fcfa(b)}</span>`; } }
  ],
  fields: [
    { k: 'name', label: 'Nom du fournisseur', required: true },
    { k: 'phone', label: 'Téléphone', type: 'tel' },
    { k: 'email', label: 'E-mail', type: 'email' },
    { k: 'address', label: 'Adresse' },
    { k: 'nature', label: 'Nature des produits ou services', col: 12 }
  ]
};

CRUD.suppliers = supCfg;
supCfg.state = { q: '', page: 1 };
function pageSuppliers(el) { el.innerHTML = crudHtml(supCfg); }

/* ===================== FACTURATION ===================== */
function invoiceDoc(i) {
  const b = DB.s.building, c = DB.find('clients', i.clientId), t = invTotals(i), paid = invPaid(i), tp = INV_TYPES[i.type][0];
  return `
    <div class="doc">
      <div class="d-flex justify-content-between align-items-start gap-3">
        <div class="d-flex align-items-start gap-3">
          <img src="assets/logo.jpg" alt="Logo" class="doc-logo" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0;flex-shrink:0;">
          <div>
            <div class="brand-doc">${esc(b.name)}</div>
            <div class="small text-muted mt-1">${esc(b.address)}, ${esc(b.city)}<br>${esc(b.phone)} — ${esc(b.email)}<br>${esc(b.billing)}</div>
          </div>
        </div>
        <div class="text-end">
          <h3 class="mb-0 text-primary">${tp.toUpperCase()}</h3>
          <b>N° ${i.number}</b><br>
          <span class="small text-muted">Émise le ${fdate(i.date)}</span>
          ${i.status === 'ANNULEE' ? '<br><span class="badge bg-danger-subtle text-danger fw-bold mt-1">DOCUMENT ANNULÉ</span>' : ''}
        </div>
      </div>
      <hr class="my-3">
      <p>
        <b>Destinataire :</b> ${esc(c ? c.first + ' ' + c.last : '—')}<br>
        ${c ? esc(c.phone) + ' — ' + esc(c.address || '') : ''}
      </p>
      <table class="table table-sm">
        <thead><tr><th>Désignation</th><th class="text-end">Qté</th><th class="text-end">Prix unitaire</th><th class="text-end">Total</th></tr></thead>
        <tbody>${i.items.map(x => `<tr><td>${esc(x.label)}</td><td class="text-end">${x.qty}</td><td class="text-end">${fcfa(x.price)}</td><td class="text-end">${fcfa(x.qty * x.price)}</td></tr>`).join('')}</tbody>
      </table>
      <div class="ms-auto" style="max-width:320px">
        <div class="d-flex justify-content-between"><span>Total HT</span><b>${fcfa(t.ht)}</b></div>
        ${i.taxRate ? `<div class="d-flex justify-content-between"><span>TVA (${i.taxRate}%)</span><b>${fcfa(t.tva)}</b></div>` : ''}
        <div class="d-flex justify-content-between fs-5 border-top pt-1 mt-1"><span>Total TTC</span><b>${fcfa(t.ttc)}</b></div>
        ${i.type !== 'AVOIR' ? `<div class="d-flex justify-content-between"><span>Montant déjà réglé</span><b>${fcfa(paid)}</b></div><div class="d-flex justify-content-between text-danger fw-bold"><span>Reste à payer</span><b>${fcfa(invBalance(i))}</b></div>` : ''}
      </div>
      <p class="small text-muted mt-4">${esc(i.terms || '')}</p>
    </div>
  `;
}

function showInvoice(id) {
  const i = DB.find('invoices', id), html = invoiceDoc(i), c = DB.find('clients', i.clientId);
  showModal(`
    <div class="modal-header"><h5 class="modal-title">${INV_TYPES[i.type][0]} ${i.number}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">${html}</div>
    <div class="modal-footer">
      <a class="btn btn-success" target="_blank" href="https://wa.me/${esc((c ? c.phone : '').replace(/\D/g, ''))}?text=${encodeURIComponent(`Bonjour, voici votre ${INV_TYPES[i.type][0].toLowerCase()} ${i.number} de ${fcfa(invTotals(i).ttc)} — ${DB.s.building.name}.`)}"><i class="bi bi-whatsapp"></i> Partager sur WhatsApp</a>
      <button class="btn btn-primary" id="prt"><i class="bi bi-printer"></i> Imprimer / PDF</button>
    </div>
  `, 'modal-lg');
  $('#prt').onclick = () => printDoc(html);
}

ACT['inv.view'] = id => showInvoice(id);
ACT['inv.cancel'] = id => confirmBox('Annuler cette facture ? Elle restera archivée et traçable dans l’historique conformément aux normes comptables.', async () => {
  try {
    if (typeof API !== 'undefined') await API.cancelInvoice(id);
  } catch (e) {
    console.warn('API cancel invoice error:', e);
  }
  DB.upd('invoices', id, { status: 'ANNULEE' });
  DB.log('Annulation facture #' + id);
  toast('Facture annulée');
  renderPage();
}, 'Annuler la facture', 'btn-danger');

ACT['inv.pay'] = id => {
  const i = DB.find('invoices', id);
  if (i.resId) return openPaymentForm(i.resId);
  toast('Facture manuelle : enregistrez le paiement via le module Encaissements.', 'warning');
};

const invCfg = {
  key: 'invoices',
  coll: 'invoices',
  singular: 'facture',
  add: true,
  addLabel: 'Facture manuelle / avoir',
  edit: false,
  rows: () => [...DB.s.invoices].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id),
  search: i => `${i.number} ${clientName(i.clientId)}`,
  cols: [
    { l: 'Numéro', f: i => `<b>${i.number}</b>` },
    { l: 'Type', f: i => INV_TYPES[i.type][0] },
    { l: 'Date', f: i => fdate(i.date) },
    { l: 'Client', f: i => esc(clientName(i.clientId)) },
    { l: 'Total TTC', f: i => fcfa(invTotals(i).ttc) },
    { l: 'Payé', f: i => i.type === 'AVOIR' ? '—' : fcfa(invPaid(i)) },
    { l: 'Solde', f: i => { const b = invBalance(i); return `<span class="${b > 0 ? 'text-danger fw-semibold' : 'text-success'}">${fcfa(b)}</span>`; } },
    { l: 'Statut', f: i => i.status === 'ANNULEE' ? '<span class="badge text-bg-danger">Annulée</span>' : (invBalance(i) <= 0 && i.type !== 'AVOIR' ? '<span class="badge text-bg-success">Soldée</span>' : i.type === 'AVOIR' ? '<span class="badge text-bg-info">Avoir</span>' : '<span class="badge text-bg-warning">En attente</span>') }
  ],
  actions: i => `
    <button class="btn btn-sm btn-outline-primary" title="Voir / imprimer" data-act="inv.view" data-id="${i.id}"><i class="bi bi-eye"></i></button>
    ${i.status !== 'ANNULEE' && invBalance(i) > 0 ? `<button class="btn btn-sm btn-outline-success" title="Encaisser" data-act="inv.pay" data-id="${i.id}"><i class="bi bi-cash"></i></button> ` : ''}
    ${i.status !== 'ANNULEE' ? `<button class="btn btn-sm btn-outline-danger" title="Annuler" data-act="inv.cancel" data-id="${i.id}"><i class="bi bi-x-circle"></i></button>` : ''}
  `,
  fields: [
    { k: 'type', label: 'Type de document', type: 'select', options: Object.keys(INV_TYPES).map(k => ({ v: k, l: INV_TYPES[k][0] })), col: 4 },
    { k: 'clientId', label: 'Client', type: 'select', numeric: true, required: true, empty: true, options: () => DB.s.clients.map(c => ({ v: c.id, l: c.first + ' ' + c.last })), col: 4 },
    { k: 'date', label: 'Date d’émission', type: 'date', required: true, col: 4 },
    { k: 'items', label: 'Prestations (désignation / quantité / prix unitaire)', type: 'lines', col: 12 },
    { k: 'taxRate', label: 'Taux TVA / Taxe (%)', type: 'number', min: 0, col: 3 },
    { k: 'terms', label: 'Conditions de règlement', col: 6 },
    { k: 'tot', label: 'Total TTC calculé', type: 'info', col: 3 }
  ],
  defaults: () => ({ type: 'FACTURE', date: TODAY, taxRate: DB.s.building.taxRate, terms: DB.s.building.terms, items: [{ label: '', qty: 1, price: 0 }] }),
  onInput: (f, d) => {
    const ht = d.items.reduce((a, i) => a + i.qty * i.price, 0);
    $('#f_tot', f).innerHTML = '<b>' + fcfa(ht + Math.round(ht * d.taxRate / 100)) + '</b>';
  },
  validate: d => d.items.length ? null : 'Ajoutez au moins une ligne de prestation.',
  before: d => {
    d.number = nextInvNumber(d.type);
    d.resId = null;
    d.status = 'EMISE';
  }
};

CRUD.invoices = invCfg;
invCfg.state = { q: '', page: 1 };

function pageInvoices(el) {
  const open = DB.s.invoices.reduce((a, i) => a + invBalance(i), 0);
  el.innerHTML = `
    <div class="row g-3 mb-3">
      <div class="col-md-4"><div class="mini-card">Factures émises non annulées<b>${DB.s.invoices.filter(i => i.status !== 'ANNULEE').length}</b></div></div>
      <div class="col-md-4"><div class="mini-card">Créances restant à encaisser<b class="text-danger">${fcfa(open)}</b></div></div>
      <div class="col-md-4"><div class="mini-card">Facturation automatique<small class="d-block text-muted">Disponible depuis chaque fiche de Réservation via <i class="bi bi-file-earmark-text"></i></small></div></div>
    </div>
  ` + crudHtml(invCfg);
}

/* ===================== RAPPORTS ===================== */
let REPORT_ID = 'occupation';
const REPORTS = {
  occupation: {
    g: 'Opérationnels',
    l: 'Occupation des chambres',
    build: R => {
      const days = Math.max(1, diffDays(R[0], R[1]) + 1);
      return {
        cols: ['Chambre', 'Statut actuel', 'Nuits occupées sur la période', 'Taux d’occupation'],
        rows: DB.s.rooms.map(r => {
          const n = DB.s.reservations.filter(x => x.roomId === r.id && ['EN_COURS', 'TERMINEE'].includes(x.status)).reduce((a, x) => a + Math.max(0, diffDays(x.arrival > R[0] ? x.arrival : R[0], x.departure < addDays(R[1], 1) ? x.departure : addDays(R[1], 1))), 0);
          return [r.number, roomSt(r.status)[0], n, Math.round(n / days * 100) + ' %'];
        })
      };
    }
  },
  arrdep: {
    g: 'Opérationnels',
    l: 'Arrivées et départs',
    build: R => ({
      cols: ['Date', 'Mouvement', 'Client', 'Chambre'],
      rows: DB.s.reservations.flatMap(r => [
        inR(r.arrival, R) && r.status !== 'ANNULEE' ? [r.arrival, 'Arrivée (Check-in)', clientName(r.clientId), roomNum(r.roomId)] : null,
        inR(r.departure, R) && r.status !== 'ANNULEE' ? [r.departure, 'Départ (Check-out)', clientName(r.clientId), roomNum(r.roomId)] : null
      ]).filter(Boolean).sort((a, b) => a[0].localeCompare(b[0])).map(x => [fdate(x[0]), ...x.slice(1)])
    })
  },
  reservations: {
    g: 'Opérationnels',
    l: 'Réservations de la période',
    build: R => ({
      cols: ['Arrivée', 'Départ', 'Client', 'Chambre', 'Total', 'Statut'],
      rows: DB.s.reservations.filter(r => inR(r.arrival, R)).sort((a, b) => a.arrival.localeCompare(b.arrival)).map(r => [fdate(r.arrival), fdate(r.departure), clientName(r.clientId), roomNum(r.roomId), fmt(resTotal(r)), RES_ST[r.status][0]])
    })
  },
  history: {
    g: 'Opérationnels',
    l: 'Historique des séjours passés',
    build: R => ({
      cols: ['Client', 'Chambre', 'Du', 'Au', 'Nuits', 'Montant'],
      rows: DB.s.reservations.filter(r => r.status === 'TERMINEE' && inR(r.departure, R)).map(r => [clientName(r.clientId), roomNum(r.roomId), fdate(r.arrival), fdate(r.departure), r.nights, fmt(resTotal(r))])
    })
  },
  housekeeping: {
    g: 'Opérationnels',
    l: 'Nettoyage et maintenance',
    build: () => ({
      cols: ['Chambre', 'Statut actuel'],
      rows: DB.s.rooms.filter(r => ['A_NETTOYER', 'MAINTENANCE'].includes(r.status)).map(r => [r.number, roomSt(r.status)[0]])
    })
  },
  ca: {
    g: 'Financiers',
    l: 'Chiffre d’affaires',
    build: R => ({
      cols: ['Date d’arrivée', 'Client', 'Chambre', 'Montant'],
      rows: DB.s.reservations.filter(r => !['ANNULEE', 'NO_SHOW'].includes(r.status) && inR(r.arrival, R)).map(r => [fdate(r.arrival), clientName(r.clientId), roomNum(r.roomId), fmt(resTotal(r))]),
      total: ['Total', '', '', fmt(caOf(R))]
    })
  },
  enc: {
    g: 'Financiers',
    l: 'Encaissements réalisés',
    build: R => ({
      cols: ['Date', 'Référence', 'Client', 'Moyen', 'Compte', 'Montant'],
      rows: DB.s.payments.filter(p => inR(p.date, R)).sort((a, b) => a.date.localeCompare(b.date)).map(p => [fdate(p.date), p.ref, clientName(p.clientId), methodName(p.methodId), accountName(p.accountId), fmt(p.amount)]),
      total: ['Total', '', '', '', '', fmt(sumPay(R))]
    })
  },
  dep: {
    g: 'Financiers',
    l: 'Dépenses payées',
    build: R => ({
      cols: ['Date', 'Référence', 'Catégorie', 'Désignation', 'Statut', 'Montant payé'],
      rows: DB.s.expenses.filter(e => inR(e.date, R)).map(e => [fdate(e.date), e.ref, e.category, e.label, EXP_ST[e.status][0], fmt(e.paidAmount)])
    })
  },
  ach: {
    g: 'Financiers',
    l: 'Achats et approvisionnements',
    build: R => ({
      cols: ['Date', 'Référence', 'Fournisseur', 'Total', 'Payé', 'Reste à payer'],
      rows: DB.s.purchases.filter(p => inR(p.date, R)).map(p => [fdate(p.date), p.ref, supplierName(p.supplierId), fmt(purchTotal(p)), fmt(purchPaid(p)), fmt(purchTotal(p) - purchPaid(p))])
    })
  },
  dettes: {
    g: 'Financiers',
    l: 'Dettes fournisseurs',
    build: () => ({
      cols: ['Fournisseur', 'Montant dû'],
      rows: DB.s.suppliers.map(s => [s.name, DB.s.purchases.filter(p => p.supplierId === s.id).reduce((a, p) => a + purchTotal(p) - purchPaid(p), 0)]).filter(x => x[1] > 0).map(x => [x[0], fmt(x[1])])
    })
  },
  creances: {
    g: 'Financiers',
    l: 'Créances clients',
    build: () => ({
      cols: ['Facture', 'Client', 'Date', 'Total', 'Reste à percevoir'],
      rows: DB.s.invoices.filter(i => invBalance(i) > 0).map(i => [i.number, clientName(i.clientId), fdate(i.date), fmt(invTotals(i).ttc), fmt(invBalance(i))])
    })
  },
  treso: {
    g: 'Financiers',
    l: 'Situation de trésorerie',
    build: () => ({
      cols: ['Compte financier', 'Solde initial', 'Solde disponible'],
      rows: DB.s.accounts.map(a => [a.name, fmt(a.opening), fmt(accountBalance(a))]),
      total: ['Total trésorerie', '', fmt(treasury())]
    })
  },
  resultat: {
    g: 'Financiers',
    l: 'Résultat d’exploitation estimé',
    build: R => {
      const ca = caOf(R),
        d = DB.s.expenses.filter(e => ['VALIDEE', 'PAYEE', 'PARTIELLEMENT_PAYEE'].includes(e.status) && inR(e.date, R)).reduce((a, e) => a + e.amount, 0),
        a = DB.s.purchases.filter(p => p.kind === 'EXPLOITATION' && inR(p.date, R)).reduce((s, p) => s + purchTotal(p), 0);
      return {
        cols: ['Poste', 'Montant'],
        rows: [['Chiffre d’affaires', fmt(ca)], ['Dépenses d’exploitation', '- ' + fmt(d)], ['Achats consommés', '- ' + fmt(a)]],
        total: ['Résultat estimé', fmt(ca - d - a)]
      };
    }
  },
  perf: {
    g: 'Financiers',
    l: 'Performance par chambre',
    build: R => ({
      cols: ['Chambre', 'Nombre de séjours', 'Revenus générés'],
      rows: DB.s.rooms.map(r => {
        const rs = DB.s.reservations.filter(x => x.roomId === r.id && !['ANNULEE', 'NO_SHOW'].includes(x.status) && inR(x.arrival, R));
        return [r.number, rs.length, rs.reduce((a, x) => a + resTotal(x), 0)];
      }).sort((a, b) => b[2] - a[2]).map(x => [x[0], x[1], fmt(x[2])])
    })
  }
};

ACT.report = id => { REPORT_ID = id; renderPage(); };
ACT['report.csv'] = () => {
  const d = REPORTS[REPORT_ID].build(periodRange());
  exportCsv('rapport-' + REPORT_ID, d.cols, d.total ? [...d.rows, d.total] : d.rows);
};
ACT['report.pdf'] = () => printDoc($('#reportDoc').outerHTML);

function pageReports(el) {
  const R = periodRange(), rep = REPORTS[REPORT_ID], d = rep.build(R), groups = {};
  Object.keys(REPORTS).forEach(k => (groups[REPORTS[k].g] = groups[REPORTS[k].g] || []).push(k));

  el.innerHTML = `
    <div class="row g-3">
      <div class="col-lg-3">
        <div class="card-box">
          ${Object.keys(groups).map(g => `
            <h6 class="text-muted small text-uppercase mt-2">Rapports ${g.toLowerCase()}</h6>
            <div class="list-group list-group-flush mb-2">
              ${groups[g].map(k => `<a href="#" class="list-group-item list-group-item-action ${k === REPORT_ID ? 'active' : ''}" data-act="report" data-id="${k}">${REPORTS[k].l}</a>`).join('')}
            </div>
          `).join('')}
        </div>
      </div>
      <div class="col-lg-9">
        <div class="card-box">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
              <h5 class="mb-0">${rep.l}</h5>
              <small class="text-muted">Période : ${fdate(R[0])} → ${fdate(R[1])} (${PERIODS[PERIOD.key]})</small>
            </div>
            <div class="btn-group">
              <button class="btn btn-outline-success" data-act="report.csv"><i class="bi bi-file-earmark-excel"></i> Exporter Excel</button>
              <button class="btn btn-outline-danger" data-act="report.pdf"><i class="bi bi-file-earmark-pdf"></i> Imprimer / PDF</button>
            </div>
          </div>
          <div id="reportDoc">
            <h5 class="d-none d-print-block">${esc(DB.s.building.name)} — ${rep.l}</h5>
            <div class="table-responsive">
              <table class="table table-modern table-sm">
                <thead><tr>${d.cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>
                <tbody>
                  ${d.rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${d.cols.length}" class="text-center text-muted py-4">Aucune donnée sur la période sélectionnée</td></tr>`}
                  ${d.total ? `<tr class="fw-bold table-light">${d.total.map(c => `<td>${esc(c)}</td>`).join('')}</tr>` : ''}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* ===================== PARAMÈTRES ===================== */
let SET_TAB = 'building';
const simpleCfg = (key, coll, singular, cols, fields, extra = {}) => {
  const c = { key, coll, singular, rows: () => DB.s[coll], search: r => Object.values(r).join(' '), cols, fields, remove: true, ...extra };
  CRUD[key] = c;
  c.state = { q: '', page: 1 };
  return c;
};
const activeCol = { l: 'Actif', f: r => r.active ? '<span class="badge text-bg-success">Oui</span>' : '<span class="badge text-bg-secondary">Non</span>' };
const actField = { k: 'active', label: 'Statut actif', type: 'check' };

const typesCfg = simpleCfg('roomTypes', 'roomTypes', 'type de chambre', [
  { l: 'Nom', f: r => `<b>${esc(r.name)}</b>` },
  { l: 'Jour', f: r => fcfa(r.daily) },
  { l: 'Semaine', f: r => fcfa(r.weekly) },
  { l: 'Mois', f: r => fcfa(r.monthly) },
  { l: 'Capacité', f: r => r.capacity + ' pers.' }
], [
  { k: 'name', label: 'Nom du type', required: true },
  { k: 'capacity', label: 'Capacité standard', type: 'number', min: 1 },
  { k: 'daily', label: 'Tarif / jour', type: 'number', col: 4 },
  { k: 'weekly', label: 'Tarif / semaine', type: 'number', col: 4 },
  { k: 'monthly', label: 'Tarif / mois', type: 'number', col: 4 }
], {
  canRemove: r => !DB.s.rooms.some(x => x.typeId === r.id),
  defaults: () => ({ capacity: 2, daily: 0, weekly: 0, monthly: 0 })
});

const methodsCfg = simpleCfg('methods', 'methods', 'moyen de paiement', [
  { l: 'Nom', f: r => `<b>${esc(r.name)}</b>` },
  activeCol
], [
  { k: 'name', label: 'Nom du moyen de paiement', required: true, col: 8 },
  { ...actField, col: 4 }
], { remove: false, defaults: () => ({ active: true }) });

const accountsCfg = simpleCfg('accounts', 'accounts', 'compte financier', [
  { l: 'Nom', f: r => `<b>${esc(r.name)}</b>` },
  { l: 'Solde initial', f: r => fcfa(r.opening) },
  { l: 'Solde actuel', f: r => `<b>${fcfa(accountBalance(r))}</b>` },
  activeCol
], [
  { k: 'name', label: 'Intitulé du compte', required: true },
  { k: 'opening', label: 'Solde initial (FCFA)', type: 'number' },
  actField
], { remove: false, defaults: () => ({ active: true, opening: 0 }) });

const CANONICAL_ROLES = ['admin', 'manager', 'reception', 'accountant'];

const usersCfg = simpleCfg('users', 'users', 'utilisateur', [
  { l: 'Nom', f: r => `<div class="d-flex align-items-center gap-2">${avatar(r.name)}<b>${esc(r.name)}</b></div>` },
  { l: 'E-mail / Identifiant', f: r => esc(r.email) },
  { l: 'Rôle', f: r => ROLES[r.role] || r.role },
  activeCol
], [
  { k: 'name', label: 'Nom complet', required: true },
  { k: 'email', label: 'E-mail / identifiant de connexion', required: true },
  { k: 'password', label: 'Mot de passe', type: 'password', required: true },
  { k: 'role', label: 'Rôle attribué', type: 'select', options: CANONICAL_ROLES.map(k => ({ v: k, l: ROLES[k] })) },
  actField
], {
  canRemove: r => r.id !== 1 && r.id !== SESSION.id,
  defaults: () => ({ role: 'reception', active: true }),
  validate: (d, cur) => DB.s.users.some(u => u.email === d.email && (!cur || u.id !== cur.id)) ? 'Cet identifiant existe déjà.' : (cur && cur.id === 1 && !d.active ? 'Le compte propriétaire ne peut pas être désactivé.' : null)
});

ACT.settab = t => { SET_TAB = t; renderPage(); };
ACT.perm = async (v, el) => {
  const { role, mod } = el.dataset;
  if (!DB.s.perms[role]) DB.s.perms[role] = [];
  const l = DB.s.perms[role];
  if (el.checked) {
    if (!l.includes(mod)) l.push(mod);
  } else {
    DB.s.perms[role] = l.filter(x => x !== mod);
  }
  DB.save();
  try {
    if (typeof API !== 'undefined') {
      await API.savePermissions(role, DB.s.perms[role]);
    }
  } catch (e) {
    console.warn('API savePermissions error:', e);
  }
  DB.log(`Permissions ${ROLES[role]} : ${mod}`);
  toast('Permissions mises à jour');
};

ACT['data.reset'] = () => {
  const S = DB.s;
  const html = `
    <div class="modal-header bg-danger text-white">
      <h5 class="modal-title d-flex align-items-center gap-2">
        <i class="bi bi-exclamation-triangle-fill"></i> Réinitialiser les données de démonstration
      </h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <div class="alert alert-warning border-warning mb-3">
        <i class="bi bi-shield-exclamation me-1"></i>
        <b>Attention :</b> Cette opération va supprimer définitivement toutes les données fictives et opérationnelles de démonstration afin de remettre l'application à zéro pour une utilisation avec vos données réelles.
      </div>

      <div class="row g-3 mb-3">
        <div class="col-md-6">
          <div class="p-3 rounded border bg-danger-subtle border-danger-subtle h-100">
            <h6 class="text-danger fw-bold mb-2"><i class="bi bi-trash3-fill me-1"></i> Données qui seront supprimées :</h6>
            <ul class="small mb-0 ps-3">
              <li><b>Réservations et séjours :</b> ${S.reservations.length} enregistrement(s)</li>
              <li><b>Clients :</b> ${S.clients.length} fiche(s) client</li>
              <li><b>Occupations & données de test des chambres :</b> remise à l'état « Libre » des ${S.rooms.length} chambres</li>
              <li><b>Paiements et encaissements :</b> ${S.payments.length} opération(s)</li>
              <li><b>Dépenses et achats :</b> ${S.expenses.length} dépense(s), ${S.purchases.length} achat(s), ${S.suppliers.length} fournisseur(s)</li>
              <li><b>Factures :</b> ${S.invoices.length} document(s)</li>
              <li><b>Autres transactions fictives :</b> soldes initiaux de démo remis à 0 FCFA</li>
            </ul>
          </div>
        </div>
        <div class="col-md-6">
          <div class="p-3 rounded border bg-success-subtle border-success-subtle h-100">
            <h6 class="text-success fw-bold mb-2"><i class="bi bi-shield-check me-1"></i> Données qui seront conservées :</h6>
            <ul class="small mb-0 ps-3">
              <li><b>Paramètres de la résidence :</b> ${esc(S.building.name)} (coordonnées, RCCM, taxes)</li>
              <li><b>Configuration des chambres :</b> les ${S.rooms.length} chambres, leurs tarifs, capacités et équipements</li>
              <li><b>Types de chambres :</b> ${S.roomTypes.length} catégorie(s) tarifaire(s)</li>
              <li><b>Comptes utilisateurs :</b> ${S.users.length} compte(s) actif(s)</li>
              <li><b>Rôles, permissions, comptes et moyens de paiement</b></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="border rounded p-3 bg-light">
        <div class="form-check mb-3">
          <input class="form-check-input" type="checkbox" id="resetConfirmCheck">
          <label class="form-check-label small fw-semibold" for="resetConfirmCheck">
            Je confirme vouloir supprimer toutes les données de démonstration listées ci-dessus.
          </label>
        </div>
        <div>
          <label class="form-label small fw-semibold" for="resetConfirmInput">
            Sécurité anti-suppression accidentelle : saisissez <code class="text-danger fw-bold">REINITIALISER</code> pour confirmer *
          </label>
          <input type="text" class="form-control" id="resetConfirmInput" placeholder="Tapez REINITIALISER en majuscules" autocomplete="off">
        </div>
        <div id="resetModalErr" class="mt-2"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
      <button type="button" class="btn btn-danger" id="resetConfirmBtn">
        <i class="bi bi-arrow-counterclockwise me-1"></i> Confirmer la réinitialisation
      </button>
    </div>
  `;

  showModal(html, 'modal-lg');

  const btn = $('#resetConfirmBtn');
  const chk = $('#resetConfirmCheck');
  const inp = $('#resetConfirmInput');
  const errBox = $('#resetModalErr');

  if (btn) {
    btn.onclick = async () => {
      errBox.innerHTML = '';
      if (!chk || !chk.checked) {
        errBox.innerHTML = '<div class="alert alert-danger py-2 mb-0 small">Veuillez cocher la case de confirmation avant de continuer.</div>';
        return;
      }
      if (!inp || inp.value.trim() !== 'REINITIALISER') {
        errBox.innerHTML = '<div class="alert alert-danger py-2 mb-0 small">Veuillez saisir exactement le mot <b>REINITIALISER</b> en majuscules.</div>';
        return;
      }

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Réinitialisation en cours...';

      try {
        let srvRes = null;
        if (typeof API !== 'undefined') {
          srvRes = await API.resetDemoData({
            confirmation: 'REINITIALISER',
            confirm_check: true
          });
        }
        DB.clearDemoData(srvRes);
        hideModal();
        renderNotifs();
        renderPage();
        toast('Toutes les données de démonstration ont été supprimées avec succès.');
      } catch (err) {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-arrow-counterclockwise me-1"></i> Confirmer la réinitialisation';
        errBox.innerHTML = `<div class="alert alert-danger py-2 mb-0 small">${esc(err.message || 'Erreur lors de la réinitialisation.')}</div>`;
      }
    };
  }
};

document.addEventListener('submit', async e => {
  if (e.target.id !== 'bform') return;
  e.preventDefault();
  const f = e.target, o = {};
  ['name', 'address', 'city', 'phone', 'email', 'description', 'manager', 'billing', 'terms'].forEach(k => o[k] = f.elements[k].value.trim());
  o.taxRate = Number(f.elements.taxRate.value) || 0;

  if (!o.name) {
    toast('Le nom de la résidence est obligatoire.', 'danger');
    return;
  }

  const submitBtn = f.querySelector('button');
  if (submitBtn) submitBtn.disabled = true;

  try {
    if (typeof API !== 'undefined') {
      const saved = await API.updateBuilding({ ...o, tax_rate: o.taxRate });
      if (saved) {
        o.name = saved.name || o.name;
        o.address = saved.address ?? o.address;
        o.city = saved.city ?? o.city;
        o.phone = saved.phone ?? o.phone;
        o.email = saved.email ?? o.email;
        o.description = saved.description ?? o.description;
        o.manager = saved.manager ?? o.manager;
        o.billing = saved.billing ?? o.billing;
        o.taxRate = Number(saved.tax_rate ?? o.taxRate);
        o.terms = saved.terms ?? o.terms;
        window.SERVER_BUILDING = saved;
      }
    }

    Object.assign(DB.s.building, o);
    DB.save();

    // Mise à jour immédiate de l'en-tête, de la barre latérale et du titre du document
    const brandName = $('#brandName');
    if (brandName) brandName.textContent = o.name;
    const topUserSpan = $('#topUser span');
    if (topUserSpan) topUserSpan.textContent = o.name;
    document.title = o.name;

    DB.log('Informations de la résidence modifiées');
    toast('Informations enregistrées avec succès');
  } catch (err) {
    toast(err.message || 'Erreur lors de l’enregistrement des informations.', 'danger');
  } finally {
    if (submitBtn) submitBtn.disabled = false;
  }
});

const bfield = (k, l, v, col = 6, type = 'text') => `<div class="col-md-${col}"><label class="form-label small fw-semibold">${l}</label><input class="form-control" name="${k}" type="${type}" value="${esc(v)}"></div>`;

function pageSettings(el) {
  const tabs = [
    ['building', 'Résidence'],
    ['rooms', 'Chambres'],
    ['roomTypes', 'Catégories de chambres'],
    ['methods', 'Moyens de paiement'],
    ['accounts', 'Comptes financiers'],
    ['users', 'Utilisateurs'],
    ['perms', 'Rôles & permissions'],
    ['audit', 'Journal d’activité'],
    ['data', 'Réinitialisation des données']
  ];
  let body = '';
  const b = DB.s.building;

  if (SET_TAB === 'building') {
    body = `
      <div class="card-box mb-3">
        <form id="bform">
          <div class="row g-3">
            ${bfield('name', 'Nom de la résidence', b.name)}
            ${bfield('manager', 'Responsable d’établissement', b.manager)}
            ${bfield('address', 'Adresse', b.address)}
            ${bfield('city', 'Ville', b.city)}
            ${bfield('phone', 'Téléphone', b.phone)}
            ${bfield('email', 'E-mail', b.email, 6, 'email')}
            ${bfield('description', 'Description générale', b.description, 12)}
            ${bfield('billing', 'Informations de facturation / mentions légales (RCCM, etc.)', b.billing, 12)}
            ${bfield('taxRate', 'Taux de taxe par défaut (%)', b.taxRate, 3, 'number')}
            ${bfield('terms', 'Conditions de facturation par défaut', b.terms, 9)}
          </div>
          <button type="submit" class="btn btn-primary mt-3"><i class="bi bi-save me-1"></i> Enregistrer les modifications</button>
        </form>
      </div>
      ${isAdmin() ? `
      <div class="card-box border-danger-subtle">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div>
            <h6 class="text-danger mb-1"><i class="bi bi-arrow-counterclockwise me-1"></i> Réinitialiser les données de démonstration</h6>
            <p class="text-muted small mb-0">Supprime toutes les réservations, clients, paiements, dépenses, achats et factures de test tout en conservant les paramètres de la résidence, la configuration des chambres et les comptes utilisateurs.</p>
          </div>
          <button type="button" class="btn btn-outline-danger" data-act="data.reset">
            <i class="bi bi-trash3 me-1"></i> Réinitialiser les données de démonstration
          </button>
        </div>
      </div>` : ''}
    `;
  } else if (SET_TAB === 'rooms') {
    const totalRooms = DB.s.rooms.length;
    const catMap = {};
    DB.s.rooms.forEach(r => {
      const t = DB.find('roomTypes', r.typeId);
      const name = t ? t.name : 'Standard';
      catMap[name] = (catMap[name] || 0) + 1;
    });
    const catBadges = Object.entries(catMap).map(([k, v]) => `<span class="badge text-bg-light border me-1">${esc(k)} : <b>${v}</b></span>`).join('');

    body = `
      <div class="card-box mb-3">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
          <div>
            <h5 class="mb-1"><i class="bi bi-door-closed-fill text-primary me-2"></i>Configuration dynamique des chambres</h5>
            <small class="text-muted">Gérez l’ensemble des chambres de l'établissement : création, modification des tarifs personnalisés, attribution des catégories et suppression sécurisée.</small>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary" data-act="crud" data-key="rooms" data-op="add">
              <i class="bi bi-plus-lg me-1"></i> Ajouter une chambre
            </button>
            <button class="btn btn-outline-secondary" data-act="settab" data-id="roomTypes">
              <i class="bi bi-tags me-1"></i> Gérer les catégories
            </button>
          </div>
        </div>
        <div class="d-flex align-items-center flex-wrap gap-2 py-2 px-3 bg-light rounded-3 border">
          <span class="small fw-semibold text-secondary me-2"><i class="bi bi-info-circle me-1"></i> Répartition (${totalRooms} chambres) :</span>
          ${catBadges || '<span class="small text-muted">Aucune chambre enregistrée</span>'}
        </div>
      </div>
      ${crudHtml(roomsCfg)}
    `;
  } else if (['roomTypes', 'methods', 'accounts', 'users'].includes(SET_TAB)) {
    body = crudHtml(CRUD[SET_TAB]);
  } else if (SET_TAB === 'perms') {
    body = `
      <div class="card-box">
        <p class="text-muted small">Permissions par module et par rôle. L'administrateur conserve l'accès complet.</p>
        <div class="table-responsive">
          <table class="table table-modern text-center">
            <thead>
              <tr><th class="text-start">Module</th>${CANONICAL_ROLES.map(r => `<th>${ROLES[r]}</th>`).join('')}</tr>
            </thead>
            <tbody>
              ${MODULES.map(m => `
                <tr>
                  <td class="text-start">${m.label}</td>
                  ${CANONICAL_ROLES.map(r => `
                    <td>
                      <input type="checkbox" class="form-check-input" data-chg="perm" data-role="${r}" data-mod="${m.id}" ${(DB.s.perms[r] || []).includes(m.id) ? 'checked' : ''} ${r === 'admin' ? 'disabled' : ''}>
                    </td>
                  `).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } else if (SET_TAB === 'audit') {
    body = `
      <div class="card-box">
        <div class="table-responsive">
          <table class="table table-modern table-sm">
            <thead><tr><th>Date & Heure</th><th>Utilisateur</th><th>Action réalisée</th></tr></thead>
            <tbody>${DB.s.audit.slice(0, 100).map(a => `<tr><td>${fdate(a.ts)} ${a.ts.slice(11, 16)}</td><td><b>${esc(a.user)}</b></td><td>${esc(a.action)}</td></tr>`).join('')}</tbody>
          </table>
        </div>
      </div>
    `;
  } else {
    const S = DB.s;
    body = `
      <div class="card-box">
        <div class="d-flex align-items-center gap-2 mb-2">
          <i class="bi bi-database-fill-gear fs-4 text-danger"></i>
          <h5 class="mb-0">Réinitialiser les données de démonstration</h5>
        </div>
        <p class="text-muted">
          Cette fonctionnalité permet de purger l'ensemble des enregistrements fictifs générés pour les tests afin de démarrer l'exploitation réelle de votre établissement dans un état vierge.
        </p>

        <div class="row g-3 mb-4">
          <div class="col-md-3 col-6"><div class="mini-card">Réservations de test<b>${S.reservations.length}</b></div></div>
          <div class="col-md-3 col-6"><div class="mini-card">Clients enregistrés<b>${S.clients.length}</b></div></div>
          <div class="col-md-3 col-6"><div class="mini-card">Paiements & Factures<b>${S.payments.length} / ${S.invoices.length}</b></div></div>
          <div class="col-md-3 col-6"><div class="mini-card">Dépenses & Achats<b>${S.expenses.length} / ${S.purchases.length}</b></div></div>
        </div>

        <div class="alert alert-light border mb-4">
          <h6 class="fw-bold mb-2"><i class="bi bi-check2-circle text-success me-1"></i> Éléments préservés lors de la réinitialisation :</h6>
          <div class="small text-secondary">
            Les coordonnées et paramètres de la résidence (<b>${esc(S.building.name)}</b>), la configuration complète des <b>${S.rooms.length} chambres</b> (remises au statut « Libre »), les <b>${S.roomTypes.length} types de chambres</b>, les <b>${S.users.length} comptes utilisateurs</b>, les rôles, les permissions et les moyens de paiement sont intégralement conservés.
          </div>
        </div>

        <button type="button" class="btn btn-danger" data-act="data.reset">
          <i class="bi bi-arrow-counterclockwise me-1"></i> Réinitialiser les données de démonstration
        </button>
      </div>
    `;
  }

  el.innerHTML = `<ul class="nav nav-tabs mb-3 flex-wrap">${tabs.map(t => `<li class="nav-item"><a href="#" class="nav-link ${SET_TAB === t[0] ? 'active' : ''}" data-act="settab" data-id="${t[0]}">${t[1]}</a></li>`).join('')}</ul>` + body;
}
