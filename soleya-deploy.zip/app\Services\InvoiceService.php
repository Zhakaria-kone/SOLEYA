<?php
// app/Services/InvoiceService.php

namespace App\Services;

use App\Models\Invoice;
use App\Models\Reservation;
use App\Models\Client;
use App\Models\Payment;
use App\Models\AuditLog;
use App\Helpers\Format;
use Exception;

class InvoiceService
{
    private Invoice $invoiceModel;
    private Reservation $reservationModel;
    private Client $clientModel;
    private Payment $paymentModel;

    public function __construct()
    {
        $this->invoiceModel = new Invoice();
        $this->reservationModel = new Reservation();
        $this->clientModel = new Client();
        $this->paymentModel = new Payment();
    }

    /**
     * Génère une facture automatique à partir d'une réservation
     */
    public function generateFromReservation(int $reservationId, array $user): array
    {
        $res = $this->reservationModel->findWithDetails($reservationId);
        if (!$res) {
            throw new Exception("Réservation #{$reservationId} introuvable.");
        }

        // Vérifier si une facture active existe déjà pour cette réservation
        $existing = Invoice::queryOne(
            "SELECT id FROM `invoices` WHERE `reservation_id` = :rid AND `status` != 'ANNULEE' LIMIT 1",
            ['rid' => $reservationId]
        );
        if ($existing) {
            return $this->invoiceModel->findWithItems((int)$existing['id']);
        }

        $invNumber = $this->invoiceModel->nextNumber('FACTURE');
        $totalTtc = (int)$res['total_amount'];
        $paidAmount = (int)$res['paid_amount'];

        $status = 'NON_PAYEE';
        if ($paidAmount >= $totalTtc && $totalTtc > 0) {
            $status = 'PAYEE';
        } elseif ($paidAmount > 0) {
            $status = 'PARTIELLE';
        }

        $today = Format::today();
        $invoiceId = $this->invoiceModel->create([
            'number' => $invNumber,
            'client_id' => $res['client_id'],
            'reservation_id' => $reservationId,
            'type' => 'FACTURE',
            'issue_date' => $today,
            'tax_rate' => 0,
            'total_ht' => $totalTtc,
            'total_tva' => 0,
            'total_ttc' => $totalTtc,
            'status' => 'EMISE',
            'terms' => "Facture pour réservation #{$reservationId} ({$res['room_number']})"
        ]);

        // Détails de la facture
        $items = [];
        $items[] = [
            'label' => "Séjour en {$res['room_number']} ({$res['nights']} nuit(s) du " . Format::date($res['arrival_date']) . " au " . Format::date($res['departure_date']) . ")",
            'qty' => (int)$res['nights'],
            'price' => (int)$res['rate_applied']
        ];

        if ((int)$res['extra_amount'] > 0) {
            $items[] = [
                'label' => "Suppléments et prestations annexes",
                'qty' => 1,
                'price' => (int)$res['extra_amount']
            ];
        }

        if ((int)$res['discount_amount'] > 0) {
            $items[] = [
                'label' => "Remise commerciale déduite",
                'qty' => 1,
                'price' => -((int)$res['discount_amount'])
            ];
        }

        $this->invoiceModel->addItems($invoiceId, $items);

        // Lier les règlements déjà perçus pour cette réservation à cette facture
        Invoice::execute(
            "UPDATE `payments` SET `invoice_id` = :iid WHERE `reservation_id` = :rid AND `invoice_id` IS NULL",
            ['iid' => $invoiceId, 'rid' => $reservationId]
        );

        AuditLog::log("Facture émise #{$invNumber}", "Générée pour réservation #{$reservationId} ({$res['client_full_name']})", $user['name'] ?? 'Système');

        return $this->invoiceModel->findWithItems($invoiceId);
    }

    /**
     * Crée une facture libre ou acompte manuelle
     */
    public function createManual(array $data, array $user): array
    {
        $clientId = (int)($data['client_id'] ?? 0);
        $client = $this->clientModel->find($clientId);
        if (!$client) {
            throw new Exception("Veuillez sélectionner un client valide.");
        }

        $type = in_array($data['type'] ?? '', ['FACTURE', 'ACOMPTE', 'AVOIR']) ? $data['type'] : 'FACTURE';
        $items = $data['items'] ?? [];
        if (empty($items) || !is_array($items)) {
            throw new Exception("La facture doit comporter au moins une ligne de prestation.");
        }

        $totalTtc = 0;
        $validItems = [];
        foreach ($items as $it) {
            $lbl = trim($it['label'] ?? '');
            $qty = max(1, (int)($it['qty'] ?? 1));
            $price = (int)($it['price'] ?? 0);
            if ($lbl !== '') {
                $totalTtc += ($qty * $price);
                $validItems[] = [
                    'label' => $lbl,
                    'qty' => $qty,
                    'price' => $price
                ];
            }
        }

        if (empty($validItems)) {
            throw new Exception("Veuillez renseigner les lignes de la facture.");
        }

        $invNumber = $this->invoiceModel->nextNumber($type);
        $today = !empty($data['issue_date']) ? $data['issue_date'] : Format::today();
        $dueDate = !empty($data['due_date']) ? $data['due_date'] : $today;
        $notes = trim($data['notes'] ?? '');

        $invoiceId = $this->invoiceModel->create([
            'number' => $invNumber,
            'client_id' => $clientId,
            'reservation_id' => !empty($data['reservation_id']) ? (int)$data['reservation_id'] : null,
            'type' => $type,
            'issue_date' => $today,
            'tax_rate' => 0,
            'total_ht' => $totalTtc,
            'total_tva' => 0,
            'total_ttc' => $totalTtc,
            'status' => 'EMISE',
            'terms' => $notes
        ]);

        $this->invoiceModel->addItems($invoiceId, $validItems);

        AuditLog::log("Création facture {$type} #{$invNumber}", "Pour {$client['first_name']} {$client['last_name']} - " . Format::money($totalTtc), $user['name'] ?? 'Système');

        return $this->invoiceModel->findWithItems($invoiceId);
    }

    /**
     * Annule une facture
     */
    public function cancel(int $id, array $user): array
    {
        $inv = $this->invoiceModel->find($id);
        if (!$inv) {
            throw new Exception("Facture introuvable.");
        }

        if ($inv['status'] === 'ANNULEE') {
            throw new Exception("Cette facture est déjà annulée.");
        }

        $this->invoiceModel->update($id, ['status' => 'ANNULEE']);

        // Délier les paiements de la facture annulée
        Invoice::execute("UPDATE `payments` SET `invoice_id` = NULL WHERE `invoice_id` = :id", ['id' => $id]);

        AuditLog::log("Annulation facture #{$inv['number']}", "Facture annulée", $user['name'] ?? 'Système');

        return $this->invoiceModel->findWithItems($id);
    }
}
