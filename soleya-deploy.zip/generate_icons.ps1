Add-Type -AssemblyName System.Drawing

$srcPath = "C:\xampp\htdocs\soleya\assets\logo.jpg"
$destDir = "C:\xampp\htdocs\soleya\assets\icons"

if (-not (Test-Path $destDir)) {
    New-Item -ItemType Directory -Path $destDir -Force | Out-Null
}

$srcImage = [System.Drawing.Image]::FromFile($srcPath)

$sizes = @(16, 32, 72, 96, 128, 144, 152, 180, 192, 384, 512)

foreach ($size in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

    $graphics.DrawImage($srcImage, 0, 0, $size, $size)
    $graphics.Dispose()

    if ($size -eq 180) {
        $outFile = Join-Path $destDir "apple-touch-icon.png"
    } elseif ($size -eq 16 -or $size -eq 32) {
        $outFile = Join-Path $destDir "favicon-$size`x$size.png"
    } else {
        $outFile = Join-Path $destDir "icon-$size`x$size.png"
    }

    $bmp.Save($outFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Generated: $outFile"
}

# Also generate 512x512 maskable icon with safe zone padding (10% padding with clean background)
$maskableSize = 512
$maskBmp = New-Object System.Drawing.Bitmap $maskableSize, $maskableSize
$maskG = [System.Drawing.Graphics]::FromImage($maskBmp)
$maskG.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$maskG.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
$maskG.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$maskG.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

# Background fill with white/neutral
$maskG.Clear([System.Drawing.Color]::White)
# Draw logo within 80% safe zone
$padding = [int]($maskableSize * 0.10)
$drawSize = $maskableSize - ($padding * 2)
$maskG.DrawImage($srcImage, $padding, $padding, $drawSize, $drawSize)
$maskG.Dispose()

$maskOut = Join-Path $destDir "icon-512x512-maskable.png"
$maskBmp.Save($maskOut, [System.Drawing.Imaging.ImageFormat]::Png)
$maskBmp.Dispose()
Write-Host "Generated: $maskOut"

# Copy 32x32 to root favicon.ico / favicon.png
$fav32 = Join-Path $destDir "favicon-32x32.png"
Copy-Item $fav32 "C:\xampp\htdocs\soleya\favicon.png" -Force
Copy-Item $fav32 "C:\xampp\htdocs\soleya\favicon.ico" -Force
Copy-Item (Join-Path $destDir "apple-touch-icon.png") "C:\xampp\htdocs\soleya\apple-touch-icon.png" -Force

$srcImage.Dispose()
Write-Host "All icons generated successfully!"
