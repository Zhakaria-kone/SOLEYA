<?php
// tests/test_room_reduction.php - Test de réduction du nombre de chambres et de configuration dynamique

declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Models\Model;
use App\Models\Room;
use App\Models\RoomType;
use App\Controllers\RoomController;

echo "=== TEST DE CONFIGURATION ET RÉDUCTION DU NOMBRE DE CHAMBRES ===\n\n";

$passed = 0;
$failed = 0;

function check(string $label, bool $cond, string $detail = ''): void {
    global $passed, $failed;
    if ($cond) {
        echo " [OK]   {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $passed++;
    } else {
        echo " [FAIL] {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $failed++;
    }
}

// 1. Initialiser une session admin
$adminUser = Model::queryOne("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
$_SESSION['user'] = [
    'id' => (int)$adminUser['id'],
    'name' => $adminUser['name'],
    'email' => $adminUser['email'],
    'role' => 'admin'
];

function callApi(string $method, string $path, array $data = []): array {
    $script = "
        require_once 'config/app.php';
        require_once 'config/database.php';
        spl_autoload_register(function (\$c) {
            if (strpos(\$c, 'App\\\\') === 0) {
                \$p = 'app/' . str_replace('\\\\', '/', substr(\$c, 4)) . '.php';
                if (file_exists(\$p)) require_once \$p;
            }
        });
        session_start();
        \$admin = \App\Models\Model::queryOne(\"SELECT * FROM users WHERE role = 'admin' LIMIT 1\");
        \$_SESSION['user'] = [
            'id' => (int)\$admin['id'],
            'name' => \$admin['name'],
            'email' => \$admin['email'],
            'role' => 'admin'
        ];
        \$ctrl = new \App\Controllers\RoomController();
    ";

    if ($method === 'DELETE') {
        preg_match('#/rooms/(\d+)#', $path, $m);
        $id = $m[1] ?? 0;
        $script .= " \$ctrl->delete(['id' => {$id}], []); ";
    } elseif ($method === 'POST') {
        $encoded = var_export($data, true);
        $script .= " \$ctrl->store([], {$encoded}); ";
    } elseif ($method === 'PUT') {
        preg_match('#/rooms/(\d+)#', $path, $m);
        $id = $m[1] ?? 0;
        $encoded = var_export($data, true);
        $script .= " \$ctrl->update(['id' => {$id}], {$encoded}); ";
    }

    $tmp = tempnam(sys_get_temp_dir(), 'test_room_') . '.php';
    file_put_contents($tmp, "<?php\n" . $script);
    $out = shell_exec("c:\\xampp\\php\\php.exe \"{$tmp}\" 2>&1");
    @unlink($tmp);

    $json = null;
    if (preg_match('#\{.*\}#s', (string)$out, $match)) {
        $json = json_decode($match[0], true);
    }
    return $json ?: ['status' => 'error', 'raw' => $out];
}

$roomModel = new Room();
$roomsBefore = $roomModel->allWithDetails();
$countBefore = count($roomsBefore);
echo "Nombre initial de chambres : {$countBefore}\n";

// 2. Tester l'effacement d'une chambre (dernière de la liste)
$lastRoom = end($roomsBefore);
$targetDeleteId = (int)$lastRoom['id'];
$targetDeleteNum = $lastRoom['number'];

$delResp = callApi('DELETE', "/rooms/{$targetDeleteId}");
$roomsAfterDelete1 = $roomModel->allWithDetails();
$countAfterDelete1 = count($roomsAfterDelete1);

check(
    "1. Effacement réussi d'une chambre existante ({$targetDeleteNum}) pour diminuer le nombre",
    ($delResp['status'] ?? '') === 'success' && $countAfterDelete1 === $countBefore - 1,
    "Avant: {$countBefore}, Après: {$countAfterDelete1}"
);

// 3. Tester l'effacement d'une chambre ayant des réservations rattachées (ex: Chambre 101)
$roomWithRes = Model::queryOne("SELECT r.id, r.number, COUNT(res.id) AS res_count FROM rooms r JOIN reservations res ON res.room_id = r.id GROUP BY r.id LIMIT 1");
if ($roomWithRes) {
    $resRoomId = (int)$roomWithRes['id'];
    $resRoomNum = $roomWithRes['number'];
    $resNum = (int)$roomWithRes['res_count'];

    $delResp2 = callApi('DELETE', "/rooms/{$resRoomId}");
    $roomsAfterDelete2 = $roomModel->allWithDetails();
    $countAfterDelete2 = count($roomsAfterDelete2);

    check(
        "2. Effacement propre d'une chambre liée à des réservations de test ({$resRoomNum}, {$resNum} réservations)",
        ($delResp2['status'] ?? '') === 'success' && $countAfterDelete2 === $countAfterDelete1 - 1,
        "Avant: {$countAfterDelete1}, Après: {$countAfterDelete2}"
    );
}

// 4. Tester l'ajout d'une chambre personnalisée avec son prix et sa catégorie
$testNum = "Chambre Deluxe 777";
$storeResp = callApi('POST', '/rooms', [
    'number' => $testNum,
    'type_id' => 2, // Supérieure
    'daily_rate' => 38000,
    'weekly_rate' => 220000,
    'monthly_rate' => 750000,
    'capacity' => 3,
    'area' => 32,
    'equipment' => 'Lit king-size, Climatisation réversible, Minibar, Smart TV'
]);

$createdId = (int)($storeResp['data']['id'] ?? 0);
check(
    "3. Ajout d'une nouvelle chambre personnalisée ('{$testNum}', 38 000 FCFA/j)",
    ($storeResp['status'] ?? '') === 'success' && $createdId > 0,
    "ID créé: {$createdId}"
);

// 5. Tester la modification du prix et de la catégorie
$updResp = callApi('PUT', "/rooms/{$createdId}", [
    'number' => $testNum,
    'type_id' => 3, // Passage en Suite
    'daily_rate' => 55000, // Nouveau prix personnalisé
    'weekly_rate' => 320000,
    'monthly_rate' => 1100000
]);

$reloaded = $roomModel->findWithDetails($createdId);
check(
    "4. Modification du prix (55 000 FCFA) et de la catégorie (Suite) avec persistance",
    ($updResp['status'] ?? '') === 'success' && $reloaded !== null && (int)$reloaded['type_id'] === 3 && (int)$reloaded['daily_rate'] === 55000,
    "Type: '{$reloaded['type_name']}', Prix/jour: {$reloaded['daily_rate']} FCFA"
);

echo "\n=== BILAN : {$passed} SUCCÈS | {$failed} ÉCHECS ===\n";
exit($failed > 0 ? 1 : 0);
