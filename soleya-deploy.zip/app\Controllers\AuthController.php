<?php
// app/Controllers/AuthController.php

namespace App\Controllers;

use App\Models\User;
use App\Models\AuditLog;
use App\Helpers\Response;

class AuthController
{
    private User $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function login(array $routeParams, array $params): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $email = trim($params['email'] ?? '');
        $password = $params['password'] ?? '';

        if (empty($email) || empty($password)) {
            Response::error('Email et mot de passe requis.', 422);
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user || !password_verify($password, $user['password_hash'])) {
            Response::error('Identifiants incorrects. Veuillez réessayer.', 401);
        }

        $userData = [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'phone' => $user['phone'] ?? ''
        ];

        $_SESSION['user'] = $userData;

        // Récupérer les permissions du rôle
        $permissions = $user['role'] === 'admin' 
            ? ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings']
            : $this->userModel->getPermissions($user['role']);

        AuditLog::log("Connexion utilisateur", "Connexion réussie de {$user['name']} ({$user['role']})", $user['name']);

        Response::success([
            'user' => $userData,
            'permissions' => $permissions
        ], 'Connexion réussie.');
    }

    public function logout(array $routeParams, array $params): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $name = $_SESSION['user']['name'] ?? 'Utilisateur';
        AuditLog::log("Déconnexion", "Déconnexion de {$name}", $name);

        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        Response::success(null, 'Déconnexion effectuée.');
    }

    public function me(array $routeParams, array $params): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (empty($_SESSION['user'])) {
            Response::json([
                'status' => 'guest',
                'user' => null,
                'permissions' => []
            ]);
        }

        $user = $_SESSION['user'];
        $permissions = $user['role'] === 'admin'
            ? ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings']
            : $this->userModel->getPermissions($user['role']);

        Response::success([
            'user' => $user,
            'permissions' => $permissions
        ]);
    }
}
