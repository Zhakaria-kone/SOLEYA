<?php
// app/Models/Expense.php

namespace App\Models;

class Expense extends Model
{
    protected string $table = 'expenses';

    public function allWithDetails(?string $from = null, ?string $to = null): array
    {
        $where = "1=1";
        $params = [];

        if ($from && $to) {
            $where .= " AND e.expense_date BETWEEN :from AND :to";
            $params['from'] = $from;
            $params['to'] = $to;
        }

        $sql = "
            SELECT 
                e.*,
                s.name AS supplier_name,
                rm.number AS room_name,
                m.name AS method_name,
                a.name AS account_name
            FROM `expenses` e
            LEFT JOIN `suppliers` s ON e.supplier_id = s.id
            LEFT JOIN `rooms` rm ON e.room_id = rm.id
            LEFT JOIN `payment_methods` m ON e.payment_method_id = m.id
            LEFT JOIN `financial_accounts` a ON e.financial_account_id = a.id
            WHERE {$where}
            ORDER BY e.expense_date DESC, e.id DESC
        ";

        return self::query($sql, $params);
    }

    public function nextReference(): string
    {
        $year = date('Y');
        $prefix = "DEP-{$year}-";
        $row = self::queryOne("SELECT COUNT(*) AS total FROM `expenses` WHERE `reference` LIKE :prefix", ['prefix' => "{$prefix}%"]);
        $next = ((int)$row['total']) + 1;
        return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
    }
}
