<?php
// database/migrate.php
// Script d'initialisation et de migration de la base de données

require_once __DIR__ . '/../config/database.php';

$config = require __DIR__ . '/../config/database.php';

echo "=== INITIALISATION BASE DE DONNÉES RESIDENCE MANAGER ===" . PHP_EOL;

try {
    // Connexion sans base pour la créer si nécessaire
    $dsn = "mysql:host={$config['host']};port={$config['port']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);
    
    echo "1. Connexion au serveur MySQL réussie." . PHP_EOL;

    // Création de la base
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE `{$config['database']}`;");
    echo "2. Base de données '{$config['database']}' sélectionnée." . PHP_EOL;

    // Exécution du schéma DDL
    $schemaSql = file_get_contents(__DIR__ . '/schema.sql');
    if ($schemaSql) {
        $pdo->exec($schemaSql);
        echo "3. Schéma DDL (tables, contraintes, index) créé avec succès." . PHP_EOL;
    }

    // Exécution du seed de données
    $seedSql = file_get_contents(__DIR__ . '/seed.sql');
    if ($seedSql) {
        $pdo->exec($seedSql);
        echo "4. Données de démonstration et référentiels insérés avec succès." . PHP_EOL;
    }

    echo "=== MIGRATION TERMINÉE AVEC SUCCÈS ===" . PHP_EOL;

} catch (PDOException $e) {
    echo "ERREUR PDO : " . $e->getMessage() . PHP_EOL;
    exit(1);
}
