<?php
// views/auth/login.php
/**
 * Vue de connexion - RESIDENCE MANAGER
 * @var array $building
 * @var string|null $loginError
 */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($building['name'] ?? 'Residence Manager') ?> — Connexion</title>
  <link rel="manifest" href="manifest.json">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/icons/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/icons/apple-touch-icon.png">
  <meta name="theme-color" content="#0f172a">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-login">
  <div id="login" class="d-flex align-items-center justify-content-center min-vh-100 p-3">
    <form id="loginForm" method="POST" action="index.php" class="login-card shadow-lg p-4 bg-white rounded-4" style="max-width: 440px; width: 100%;">
      <input type="hidden" name="action" value="login">
      
      <div class="login-brand text-center mb-4">
        <div class="mb-3 d-flex justify-content-center">
          <img src="assets/logo.jpg" alt="Logo <?= htmlspecialchars($building['name'] ?? 'Résidence') ?>" class="rounded-3 shadow-sm border" style="width: 80px; height: 80px; object-fit: cover;">
        </div>
        <h4 class="mb-1 fw-bold"><?= htmlspecialchars($building['name'] ?? 'Residence Manager') ?></h4>
        <small class="text-muted">Gestion hôtelière & résidences meublées</small>
      </div>

      <h5 class="mb-3 fw-semibold text-center">Connexion à votre espace</h5>

      <?php if (!empty($loginError)): ?>
        <div class="alert alert-danger py-2 small mb-3">
          <i class="bi bi-exclamation-triangle-fill me-1"></i> <?= htmlspecialchars($loginError) ?>
        </div>
      <?php endif; ?>
      <div id="lErr" class="text-danger small mb-2"></div>

      <div class="mb-3">
        <label class="form-label small fw-semibold" for="lEmail">Identifiant ou e-mail</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-envelope"></i></span>
          <input id="lEmail" name="email" type="email" class="form-control" placeholder="nom@exemple.com" required autofocus autocomplete="username">
        </div>
      </div>

      <div class="mb-4">
        <label class="form-label small fw-semibold" for="lPass">Mot de passe</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input id="lPass" name="password" type="password" class="form-control" placeholder="••••••••" required autocomplete="current-password">
        </div>
      </div>

      <button type="submit" class="btn btn-gold w-100 py-2 fw-semibold">
        <i class="bi bi-box-arrow-in-right me-1"></i> Se connecter
      </button>
    </form>
  </div>

  <script>
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').catch(() => {});
      });
    }
  </script>
</body>
</html>
