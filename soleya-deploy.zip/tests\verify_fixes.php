<?php
// tests/verify_fixes.php - Vérification complète des corrections (Navigation, Persistance Résidence, Réinitialisation Démo)

declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Models\Model;
use App\Models\Building;
use App\Models\Room;
use App\Models\User;
use App\Services\FinanceService;

echo "=== VÉRIFICATION COMPLÈTE DES CORRECTIONS ===\n\n";

$passed = 0;
$failed = 0;

function check(string $label, bool $cond, string $detail = ''): void {
    global $passed, $failed;
    if ($cond) {
        echo " [OK]   {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $passed++;
    } else {
        echo " [FAIL] {$label}" . ($detail ? " ({$detail})" : "") . "\n";
        $failed++;
    }
}

$pdo = Model::getPdo();

// 1. Réparation des éventuels statuts de chambres vides en base de données
$invalidRoomsBefore = (int)$pdo->query("SELECT COUNT(*) FROM rooms WHERE status = '' OR status IS NULL")->fetchColumn();
if ($invalidRoomsBefore > 0) {
    $pdo->exec("UPDATE rooms SET status = 'LIBRE' WHERE status = '' OR status IS NULL");
}
$invalidRoomsAfter = (int)$pdo->query("SELECT COUNT(*) FROM rooms WHERE status = '' OR status IS NULL")->fetchColumn();
check(
    "1. Normalisation des statuts des chambres en base MySQL",
    $invalidRoomsAfter === 0,
    "Corrigées: {$invalidRoomsBefore}, Invalides restantes: {$invalidRoomsAfter}"
);

// Vérification de Room::allWithDetails() et FinanceService::getDashboard()
$roomModel = new Room();
$rooms = $roomModel->allWithDetails();
$validStatuses = ['LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE'];
$allValid = count($rooms) > 0;
foreach ($rooms as $r) {
    if (!in_array($r['status'], $validStatuses, true)) {
        $allValid = false;
    }
}
check(
    "2. Chargement des données Chambres (Room::allWithDetails)",
    $allValid,
    count($rooms) . " chambres chargées avec des statuts conformes"
);

$financeService = new FinanceService();
$dash = $financeService->getDashboard();
check(
    "3. Chargement des données Tableau de bord (FinanceService::getDashboard)",
    isset($dash['kpis']) && isset($dash['kpis']['occupancy_rate']),
    "Occupation: {$dash['kpis']['occupancy_rate']}%, CA: {$dash['kpis']['total_revenue']} FCFA"
);

// 2. Test de persistance des informations de la résidence (Building::saveBuilding)
$buildingModel = new Building();
$originalBuilding = $buildingModel->get();

$testName = "RÉSIDENCE SOLEYA TEST PERSISTANCE";
$testPhone = "+225 07 99 88 77 66";
$testAddress = "Cocody Riviera Golf, Abidjan";
$testTax = 18;

$savedBuilding = $buildingModel->saveBuilding([
    'name' => $testName,
    'address' => $testAddress,
    'city' => 'Abidjan, Côte d\'Ivoire',
    'phone' => $testPhone,
    'email' => 'contact@soleya-test.ci',
    'description' => 'Résidence de standing testée.',
    'manager' => 'M. Koné',
    'billing' => 'RCCM CI-ABJ-TEST-2026',
    'tax_rate' => $testTax,
    'terms' => 'Merci pour votre séjour chez Soleya.'
]);

// Relire directement depuis MySQL via une nouvelle requête
$reloadedBuilding = $buildingModel->get();
check(
    "4. Persistance MySQL des informations de la résidence après modification et rechargement",
    $reloadedBuilding['name'] === $testName
        && $reloadedBuilding['phone'] === $testPhone
        && $reloadedBuilding['address'] === $testAddress
        && (int)$reloadedBuilding['tax_rate'] === $testTax,
    "Nom relu: '{$reloadedBuilding['name']}', Tél: '{$reloadedBuilding['phone']}'"
);

// Restaurer les informations précédentes de la résidence
$buildingModel->saveBuilding($originalBuilding);
$restoredBuilding = $buildingModel->get();
check(
    "5. Restauration de l'état initial de la résidence dans MySQL",
    $restoredBuilding['name'] === $originalBuilding['name'] && $restoredBuilding['phone'] === $originalBuilding['phone'],
    "Nom: '{$restoredBuilding['name']}'"
);

// 3. Test de SettingController::getSettings() (vérifie l'absence d'erreur SQL sur users)
$usersFromSettingsQuery = Model::query("SELECT id, name, email, role, is_active FROM `users` ORDER BY id ASC");
check(
    "6. Requête SQL des paramètres utilisateurs sans erreur (4 comptes)",
    count($usersFromSettingsQuery) >= 4,
    count($usersFromSettingsQuery) . " comptes récupérés"
);

// 4. Test de la réinitialisation des données de démonstration
// Sauvegarde préalable des tables opérationnelles en mémoire pour restaurer l'état après le test
$tablesToClear = [
    'payments',
    'invoice_items',
    'invoices',
    'supplier_payments',
    'purchase_items',
    'purchases',
    'expenses',
    'reservations',
    'clients',
    'suppliers',
    'audit_logs'
];

$backupRows = [];
foreach ($tablesToClear as $t) {
    $backupRows[$t] = Model::query("SELECT * FROM {$t}");
}
$backupRooms = Model::query("SELECT id, status FROM rooms");
$backupAccounts = Model::query("SELECT id, opening_balance FROM financial_accounts");

// Exécution de la transaction de réinitialisation (identique à SettingController::resetDemoData)
Model::beginTransaction();
try {
    foreach ($tablesToClear as $t) {
        Model::execute("DELETE FROM {$t}");
    }
    Model::execute("UPDATE rooms SET status = 'LIBRE'");
    Model::execute("UPDATE financial_accounts SET opening_balance = 0");
    Model::commit();
    $resetTxOk = true;
} catch (\Throwable $e) {
    Model::rollBack();
    $resetTxOk = false;
    echo "Erreur transaction reset: " . $e->getMessage() . "\n";
}
check("7. Exécution transactionnelle de la réinitialisation des données de démonstration", $resetTxOk);

// Vérification que toutes les tables de démonstration sont vides
$demoCounts = [];
$allZero = true;
foreach ($tablesToClear as $t) {
    $c = (int)$pdo->query("SELECT COUNT(*) FROM {$t}")->fetchColumn();
    $demoCounts[$t] = $c;
    if ($c !== 0) {
        $allZero = false;
    }
}
check(
    "8. Toutes les données fictives (réservations, clients, paiements, dépenses, achats, factures) sont supprimées",
    $allZero,
    json_encode($demoCounts)
);

// Vérification que les configurations essentielles et comptes utilisateurs sont conservés
$keptBuilding = (int)$pdo->query("SELECT COUNT(*) FROM building")->fetchColumn();
$keptRooms = (int)$pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$keptLibreRooms = (int)$pdo->query("SELECT COUNT(*) FROM rooms WHERE status = 'LIBRE'")->fetchColumn();
$keptRoomTypes = (int)$pdo->query("SELECT COUNT(*) FROM room_types")->fetchColumn();
$keptUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$keptRoles = (int)$pdo->query("SELECT COUNT(*) FROM role_permissions")->fetchColumn();
$keptMethods = (int)$pdo->query("SELECT COUNT(*) FROM payment_methods")->fetchColumn();
$keptAccounts = (int)$pdo->query("SELECT COUNT(*) FROM financial_accounts")->fetchColumn();

check(
    "9. Conservation des données essentielles (Résidence, Chambres, Types, Utilisateurs, Rôles, Comptes, Modes de paiement)",
    $keptBuilding === 1
        && $keptRooms === 24
        && $keptLibreRooms === 24
        && $keptRoomTypes === 3
        && $keptUsers >= 4
        && $keptRoles >= 4
        && $keptMethods >= 8
        && $keptAccounts >= 6,
    "Chambres: {$keptRooms} (toutes LIBRE: {$keptLibreRooms}), Types: {$keptRoomTypes}, Users: {$keptUsers}, Rôles: {$keptRoles}"
);

// Restauration des données après le test unitaire (ordre inverse pour respecter les clés étrangères)
Model::beginTransaction();
try {
    foreach (array_reverse($tablesToClear) as $t) {
        foreach ($backupRows[$t] as $row) {
            $cols = array_keys($row);
            $placeholders = array_fill(0, count($cols), '?');
            $sql = "INSERT INTO {$t} (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
            Model::execute($sql, array_values($row));
        }
    }
    foreach ($backupRooms as $r) {
        $st = (!empty($r['status']) && $r['status'] !== 'DISPONIBLE') ? $r['status'] : 'LIBRE';
        Model::execute("UPDATE rooms SET status = ? WHERE id = ?", [$st, $r['id']]);
    }
    foreach ($backupAccounts as $a) {
        Model::execute("UPDATE financial_accounts SET opening_balance = ? WHERE id = ?", [$a['opening_balance'], $a['id']]);
    }
    Model::commit();
} catch (\Throwable $e) {
    Model::rollBack();
    echo "Erreur restauration post-test: " . $e->getMessage() . "\n";
}

echo "\n=== BILAN : {$passed} SUCCÈS | {$failed} ÉCHEC ===\n";
exit($failed > 0 ? 1 : 0);
