<?php
// app/Controllers/InvoiceController.php

namespace App\Controllers;

use App\Models\Invoice;
use App\Models\Client;
use App\Services\InvoiceService;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class InvoiceController
{
    private Invoice $invoiceModel;
    private Client $clientModel;
    private InvoiceService $invoiceService;

    public function __construct()
    {
        $this->invoiceModel = new Invoice();
        $this->clientModel = new Client();
        $this->invoiceService = new InvoiceService();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('invoices');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;

        $invoices = $this->invoiceModel->allWithDetails($from, $to);
        $clients = $this->clientModel->all();

        Response::success([
            'invoices' => $invoices,
            'clients' => $clients
        ]);
    }

    public function show(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('invoices');

        $id = (int)($routeParams['id'] ?? 0);
        $inv = $this->invoiceModel->findWithItems($id);
        if (!$inv) {
            Response::error('Facture introuvable.', 404);
        }

        Response::success($inv);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('invoices');

        try {
            $invoice = $this->invoiceService->createManual($params, $user);
            Response::success($invoice, 'Facture créée avec succès.', 201);
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function fromReservation(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('invoices');

        $resId = (int)($params['reservation_id'] ?? 0);
        if ($resId <= 0) {
            Response::error('Identifiant de réservation requis.', 422);
        }

        try {
            $invoice = $this->invoiceService->generateFromReservation($resId, $user);
            Response::success($invoice, 'Facture générée avec succès.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function cancel(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('invoices');

        $id = (int)($routeParams['id'] ?? 0);
        try {
            $invoice = $this->invoiceService->cancel($id, $user);
            Response::success($invoice, 'Facture annulée.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }
}
