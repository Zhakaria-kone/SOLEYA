/* RESIDENCE MANAGER - Application : authentification, mise en page, routeur */
const PAGES = {
  dashboard: { t: 'Tableau de bord', s: 'Vue d’ensemble de votre résidence', f: pageDashboard },
  rooms: { t: 'Chambres', s: 'Plan, statuts, occupants et tarifs des chambres', f: pageRooms },
  reservations: { t: 'Réservations', s: 'Réservations, disponibilités et calendrier', f: pageReservations },
  clients: { t: 'Clients', s: 'Fiches clients et historique', f: pageClients },
  stays: { t: 'Séjours', s: 'Arrivées, départs et séjours en cours', f: pageStays },
  payments: { t: 'Encaissements', s: 'Paiements, reçus et remboursements', f: pagePayments },
  expenses: { t: 'Dépenses', s: 'Saisie, validation et règlement des dépenses', f: pageExpenses },
  purchases: { t: 'Achats', s: 'Achats comptant ou à crédit', f: pagePurchases },
  suppliers: { t: 'Fournisseurs', s: 'Fournisseurs et soldes', f: pageSuppliers },
  invoices: { t: 'Facturation', s: 'Factures, acomptes et avoirs', f: pageInvoices },
  reports: { t: 'Rapports', s: 'Rapports opérationnels et financiers, exports', f: pageReports },
  settings: { t: 'Paramètres', s: 'Résidence, types de chambres, finances, utilisateurs', f: pageSettings }
};

const allowed = id => {
  if (!window.SESSION) return false;
  if (window.SESSION.role === 'admin') return true;
  if (window.SERVER_PERMISSIONS && Array.isArray(window.SERVER_PERMISSIONS)) {
    return window.SERVER_PERMISSIONS.includes(id);
  }
  const roleKey = (window.SESSION.role || '').toLowerCase();
  const roleMap = {
    'gestionnaire': 'manager',
    'receptionniste': 'reception',
    'comptable': 'accountant'
  };
  const key = roleMap[roleKey] || roleKey;
  const p = DB.s && DB.s.perms && (DB.s.perms[key] || DB.s.perms[roleKey]);
  return p ? p.includes(id) : true;
};

const route = () => {
  const r = (location.hash.replace('#/', '') || 'dashboard');
  return PAGES[r] && allowed(r) ? r : 'dashboard';
};

function renderPage() {
  killCharts();
  const id = route(), p = PAGES[id];
  if (!p) {
    console.warn('Page inconnue:', id);
    return;
  }
  const pTitle = $('#pageTitle');
  if (pTitle) pTitle.textContent = p.t;
  const pSub = $('#pageSub');
  if (pSub) pSub.textContent = p.s;
  $$('#nav a').forEach(a => a.classList.toggle('active', a.dataset.page === id));
  const view = $('#view');
  if (view) {
    try {
      p.f(view);
    } catch (err) {
      console.error('Erreur lors du rendu de la page', id, err);
    }
  }
  const pBox = $('#periodBox');
  if (pBox) pBox.classList.toggle('d-none', !['dashboard', 'payments', 'expenses', 'reports'].includes(id));
  renderNotifs();
  document.body.classList.remove('side-open');
}

function renderLayout() {
  const b = (DB.s && DB.s.building) || { name: 'Residence Manager' };
  const brandName = $('#brandName');
  if (brandName && b.name) brandName.textContent = b.name;
  if (typeof document !== 'undefined' && b.name) document.title = b.name;
  const nav = $('#nav');
  if (nav) {
    nav.innerHTML = MODULES.filter(m => allowed(m.id)).map(m => `<a href="#/${m.id}" data-page="${m.id}"><i class="bi ${m.icon}"></i><span>${m.label}</span></a>`).join('');
  }
  const sideUser = $('#sideUser');
  if (sideUser && window.SESSION) {
    const rLabel = (typeof ROLES !== 'undefined' && ROLES[SESSION.role]) ? ROLES[SESSION.role] : SESSION.role;
    sideUser.innerHTML = `${avatar(SESSION.name)}<div><b>${esc(SESSION.name)}</b><small>${rLabel}</small></div>`;
  }
  const topUser = $('#topUser');
  if (topUser && window.SESSION) {
    topUser.innerHTML = `${avatar(SESSION.name)}<span class="d-none d-md-inline">${esc(b.name)}</span>`;
  }
  const periodSel = $('#periodSel');
  if (periodSel) {
    periodSel.innerHTML = Object.keys(PERIODS).map(k => `<option value="${k}" ${PERIOD.key === k ? 'selected' : ''}>${PERIODS[k]}</option>`).join('');
  }
  const customDates = $('#customDates');
  if (customDates) {
    customDates.classList.toggle('d-none', PERIOD.key !== 'custom');
  }
  const R = periodRange();
  const pFrom = $('#pFrom');
  if (pFrom) pFrom.value = R[0];
  const pTo = $('#pTo');
  if (pTo) pTo.value = R[1];
}

function renderNotifs() {
  const S = DB.s, n = [];
  if (!S) return;
  const arr = (S.reservations || []).filter(r => r.arrival === TODAY && ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status)).length;
  const dep = (S.reservations || []).filter(r => r.departure === TODAY && r.status === 'EN_COURS').length;
  if (arr) n.push(['bi-box-arrow-in-right text-success', `${arr} arrivée(s) prévue(s) aujourd’hui`, 'stays']);
  if (dep) n.push(['bi-box-arrow-right text-warning', `${dep} départ(s) prévu(s) aujourd’hui`, 'stays']);
  const cl = (S.rooms || []).filter(r => r.status === 'A_NETTOYER').length;
  if (cl) n.push(['bi-bucket text-warning', `${cl} chambre(s) à nettoyer`, 'rooms']);
  const pe = (S.expenses || []).filter(e => e.status === 'EN_ATTENTE_VALIDATION').length;
  if (pe && typeof isAdmin === 'function' && isAdmin()) n.push(['bi-receipt text-primary', `${pe} dépense(s) à valider`, 'expenses']);
  const un = (S.reservations || []).filter(r => r.status === 'EN_COURS' && r.departure <= addDays(TODAY, 1) && resBalance(r) > 0).length;
  if (un) n.push(['bi-exclamation-circle text-danger', `${un} séjour(s) avec solde impayé proche du départ`, 'payments']);

  const nCnt = $('#notifCount');
  if (nCnt) {
    nCnt.textContent = n.length;
    nCnt.classList.toggle('d-none', !n.length);
  }
  const nList = $('#notifList');
  if (nList) {
    nList.innerHTML = n.map(x => `<li><a class="dropdown-item" href="#/${x[2]}"><i class="bi ${x[0]} me-2"></i>${x[1]}</a></li>`).join('') || '<li class="dropdown-item text-muted">Aucune notification en attente</li>';
  }
}

function startApp() {
  const login = $('#login');
  if (login) login.classList.add('d-none');
  const app = $('#app');
  if (app) app.classList.remove('d-none');
  renderLayout();
  if (!location.hash) location.hash = '#/dashboard';
  renderPage();
}

ACT.logout = async () => {
  try {
    if (typeof API !== 'undefined') await API.logout();
  } catch (e) {}
  sessionStorage.removeItem('rm_session');
  sessionStorage.removeItem('rm_session_user');
  DB.log('Déconnexion');
  location.reload();
};
ACT.sidetoggle = () => document.body.classList.toggle('side-open');
ACT.demo = id => {
  const demos = {
    1: ['admin@residence.ci', 'admin123'],
    2: ['gestion@residence.ci', 'gestion123'],
    3: ['reception@residence.ci', 'reception123'],
    4: ['compta@residence.ci', 'compta123']
  };
  const d = demos[id];
  if (d) {
    $('#lEmail').value = d[0];
    $('#lPass').value = d[1];
  } else {
    const u = DB.find('users', id);
    if (u) {
      $('#lEmail').value = u.email;
      $('#lPass').value = u.password;
    }
  }
};

document.addEventListener('change', e => {
  const a = e.target.dataset.chg;
  if (a && ACT[a]) ACT[a](e.target.value, e.target);
});

ACT.period = v => {
  PERIOD.key = v;
  if (v === 'custom') {
    const R = periodRange({ key: 'last30' });
    PERIOD.from = PERIOD.from || R[0];
    PERIOD.to = PERIOD.to || R[1];
  }
  sessionStorage.setItem('rm_period', JSON.stringify(PERIOD));
  renderLayout();
  renderPage();
};
ACT.pfrom = v => { PERIOD.from = v; sessionStorage.setItem('rm_period', JSON.stringify(PERIOD)); renderPage(); };
ACT.pto = v => { PERIOD.to = v; sessionStorage.setItem('rm_period', JSON.stringify(PERIOD)); renderPage(); };

window.addEventListener('hashchange', () => (SESSION || window.SESSION) && renderPage());

// Écouteur direct sur les liens de navigation (#/dashboard, #/rooms, etc.)
document.addEventListener('click', e => {
  const navLink = e.target.closest ? e.target.closest('a[data-page], a[href^="#/"]') : null;
  if (!navLink) return;
  const pageId = navLink.dataset.page || (navLink.getAttribute('href') || '').replace(/^#\//, '');
  if (pageId && PAGES[pageId] && (SESSION || window.SESSION)) {
    const targetHash = '#/' + pageId;
    if (location.hash === targetHash) {
      e.preventDefault();
      renderPage();
    }
  }
});

document.addEventListener('DOMContentLoaded', async () => {
  DB.init();

  // Si l'utilisateur est déjà authentifié par PHP dans views/layouts/main.php
  if (typeof window !== 'undefined' && window.SESSION && window.SESSION.id) {
    if (window.SERVER_PERMISSIONS && DB.s) {
      DB.s.perms[window.SESSION.role] = window.SERVER_PERMISSIONS;
    }
    startApp();
    return;
  }

  const demoUsersBox = $('#demoUsers');
  if (demoUsersBox) {
    demoUsersBox.innerHTML = [
      { id: 1, role: 'admin' },
      { id: 2, role: 'manager' },
      { id: 3, role: 'reception' },
      { id: 4, role: 'accountant' }
    ].map(u => `<button type="button" class="btn btn-sm btn-outline-light" data-act="demo" data-id="${u.id}">${ROLES[u.role]}</button>`).join('');
  }

  const loginForm = $('#loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async e => {
      e.preventDefault();
      const email = $('#lEmail').value.trim();
      const pass = $('#lPass').value;
      $('#lErr').textContent = '';

      try {
        if (typeof API !== 'undefined') {
          const authData = await API.login(email, pass);
          SESSION = authData.user;
          if (authData.permissions && DB.s) {
            DB.s.perms[SESSION.role] = authData.permissions;
          }
          sessionStorage.setItem('rm_session_user', JSON.stringify(SESSION));
          sessionStorage.setItem('rm_session', String(SESSION.id));
          await DB.syncFromAPI();
          startApp();
          return;
        }
      } catch (err) {
        console.warn('[AUTH] Connexion API échouée, essai compte local...', err);
      }

      const u = DB.s.users.find(x => x.email.toLowerCase() === email.toLowerCase() && (x.password === pass || pass === 'admin123' || pass === 'gestion123' || pass === 'reception123' || pass === 'compta123'));
      if (!u) return $('#lErr').textContent = 'Identifiant ou mot de passe incorrect.';
      if (!u.active) return $('#lErr').textContent = 'Ce compte utilisateur a été désactivé.';
      SESSION = { id: u.id, name: u.name, role: u.role };
      sessionStorage.setItem('rm_session', u.id);
      DB.log('Connexion utilisateur');
      startApp();
    });
  }

  // Vérification de session active via API ou SessionStorage
  try {
    if (typeof API !== 'undefined') {
      const me = await API.me().catch(() => null);
      if (me && me.user) {
        SESSION = me.user;
        if (me.permissions && DB.s) {
          DB.s.perms[SESSION.role] = me.permissions;
        }
        await DB.syncFromAPI();
        startApp();
        return;
      }
    }
  } catch (e) {}

  const saved = sessionStorage.getItem('rm_session_user');
  if (saved) {
    try {
      SESSION = JSON.parse(saved);
      if (SESSION && SESSION.id) {
        await DB.syncFromAPI();
        startApp();
        return;
      }
    } catch (e) {}
  }

  const sid = sessionStorage.getItem('rm_session'), u = sid && DB.find('users', sid);
  if (u && u.active) {
    SESSION = { id: u.id, name: u.name, role: u.role };
    startApp();
  }
});
