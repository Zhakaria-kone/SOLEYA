<?php
// app/Models/AuditLog.php

namespace App\Models;

class AuditLog extends Model
{
    protected string $table = 'audit_logs';

    public static function log(string $action, ?string $details = null, ?string $userName = null): void
    {
        $user = $userName ?: ($_SESSION['user']['name'] ?? 'Système');
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        self::execute("INSERT INTO `audit_logs` (`user_name`, `action`, `details`, `ip_address`, `created_at`) VALUES (:usr, :act, :det, :ip, NOW())", [
            'usr' => $user,
            'act' => $action,
            'det' => $details,
            'ip' => $ip
        ]);
    }

    public static function recent(int $limit = 100): array
    {
        return self::query("SELECT * FROM `audit_logs` ORDER BY id DESC LIMIT :limit", ['limit' => $limit]);
    }
}
