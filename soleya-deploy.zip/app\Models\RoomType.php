<?php
// app/Models/RoomType.php

namespace App\Models;

class RoomType extends Model
{
    protected string $table = 'room_types';
}
