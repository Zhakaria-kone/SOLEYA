<?php
// app/Controllers/ExpenseController.php

namespace App\Controllers;

use App\Models\Expense;
use App\Models\Supplier;
use App\Models\FinancialAccount;
use App\Models\PaymentMethod;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Helpers\Format;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class ExpenseController
{
    private Expense $expenseModel;
    private Supplier $supplierModel;
    private FinancialAccount $accountModel;
    private PaymentMethod $methodModel;

    public function __construct()
    {
        $this->expenseModel = new Expense();
        $this->supplierModel = new Supplier();
        $this->accountModel = new FinancialAccount();
        $this->methodModel = new PaymentMethod();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('expenses');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;

        $expenses = $this->expenseModel->allWithDetails($from, $to);
        $suppliers = $this->supplierModel->all();
        $accounts = $this->accountModel->all();
        $methods = $this->methodModel->all();

        Response::success([
            'expenses' => $expenses,
            'suppliers' => $suppliers,
            'accounts' => $accounts,
            'methods' => $methods
        ]);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('expenses');

        $desc = trim($params['label'] ?? $params['description'] ?? '');
        $amount = (int)($params['amount'] ?? 0);
        $category = trim($params['category'] ?? 'Autres');
        $date = !empty($params['expense_date']) ? $params['expense_date'] : Format::today();
        $time = !empty($params['expense_time']) ? $params['expense_time'] : date('H:i');
        $supplierId = !empty($params['supplier_id']) ? (int)$params['supplier_id'] : null;
        $roomId = !empty($params['room_id']) ? (int)$params['room_id'] : null;
        $rawStatus = $params['status'] ?? 'BROUILLON';
        if ($rawStatus === 'EN_ATTENTE') {
            $rawStatus = 'EN_ATTENTE_VALIDATION';
        }
        $status = in_array($rawStatus, ['BROUILLON', 'EN_ATTENTE_VALIDATION', 'VALIDEE', 'REJETEE', 'PAYEE', 'PARTIELLEMENT_PAYEE', 'ANNULEE'], true)
            ? $rawStatus
            : 'BROUILLON';

        if (empty($desc) || $amount <= 0) {
            Response::error('Désignation et montant valide obligatoires.', 422);
        }

        $ref = $this->expenseModel->nextReference();
        $id = $this->expenseModel->create([
            'reference' => $ref,
            'expense_date' => $date,
            'expense_time' => $time,
            'category' => $category,
            'label' => $desc,
            'amount' => $amount,
            'paid_amount' => $status === 'PAYEE' ? $amount : 0,
            'supplier_id' => $supplierId,
            'room_id' => $roomId,
            'payment_method_id' => !empty($params['payment_method_id']) ? (int)$params['payment_method_id'] : 1,
            'financial_account_id' => !empty($params['financial_account_id']) ? (int)$params['financial_account_id'] : 1,
            'status' => $status,
            'author_name' => $user['name']
        ]);

        AuditLog::log("Création dépense #{$ref}", "{$desc} - " . Format::money($amount) . " [{$status}]", $user['name']);

        $expense = $this->expenseModel->find($id);
        Response::success($expense, 'Dépense enregistrée.', 201);
    }

    public function submit(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('expenses');

        $id = (int)($routeParams['id'] ?? 0);
        $exp = $this->expenseModel->find($id);
        if (!$exp) Response::error('Dépense introuvable.', 404);

        $this->expenseModel->update($id, ['status' => 'EN_ATTENTE_VALIDATION']);
        AuditLog::log("Soumission dépense #{$exp['reference']}", "Soumise pour validation", $user['name']);

        Response::success($this->expenseModel->find($id), 'Dépense soumise à validation.');
    }

    public function validate(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        if (!in_array($user['role'], ['admin', 'manager', 'gestionnaire'])) {
            Response::error('Action réservée aux gestionnaires et administrateurs.', 403);
        }

        $id = (int)($routeParams['id'] ?? 0);
        $exp = $this->expenseModel->find($id);
        if (!$exp) Response::error('Dépense introuvable.', 404);

        $this->expenseModel->update($id, [
            'status' => 'VALIDEE'
        ]);
        AuditLog::log("Validation dépense #{$exp['reference']}", "Validée par {$user['name']}", $user['name']);

        Response::success($this->expenseModel->find($id), 'Dépense validée avec succès.');
    }

    public function reject(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        if (!in_array($user['role'], ['admin', 'manager', 'gestionnaire'])) {
            Response::error('Action réservée aux gestionnaires et administrateurs.', 403);
        }

        $id = (int)($routeParams['id'] ?? 0);
        $exp = $this->expenseModel->find($id);
        if (!$exp) Response::error('Dépense introuvable.', 404);

        $this->expenseModel->update($id, ['status' => 'REJETEE']);
        AuditLog::log("Rejet dépense #{$exp['reference']}", "Rejetée par {$user['name']}", $user['name']);

        Response::success($this->expenseModel->find($id), 'Dépense rejetée.');
    }

    public function pay(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        if (!in_array($user['role'], ['admin', 'accountant', 'comptable', 'manager', 'gestionnaire'])) {
            Response::error('Action non autorisée.', 403);
        }

        $id = (int)($routeParams['id'] ?? 0);
        $exp = $this->expenseModel->find($id);
        if (!$exp) Response::error('Dépense introuvable.', 404);

        $methodId = (int)($params['payment_method_id'] ?? $exp['payment_method_id'] ?? 1);
        $accountId = (int)($params['financial_account_id'] ?? $exp['financial_account_id'] ?? 1);
        $payAmount = isset($params['amount']) ? max(1, (int)$params['amount']) : ((int)$exp['amount'] - (int)$exp['paid_amount']);
        $newPaid = min((int)$exp['amount'], (int)$exp['paid_amount'] + $payAmount);
        $newStatus = $newPaid >= (int)$exp['amount'] ? 'PAYEE' : 'PARTIELLEMENT_PAYEE';

        $this->expenseModel->update($id, [
            'paid_amount' => $newPaid,
            'status' => $newStatus,
            'payment_method_id' => $methodId,
            'financial_account_id' => $accountId
        ]);

        AuditLog::log("Paiement dépense #{$exp['reference']}", "Dépense réglée par {$user['name']}", $user['name']);
        Response::success($this->expenseModel->find($id), 'Dépense marquée comme payée.');
    }
}
