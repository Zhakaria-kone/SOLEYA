<?php
// tests/http_test.php

$baseUrl = 'http://localhost:8080/soleya';
$cookieFile = __DIR__ . '/test_cookie.txt';
if (file_exists($cookieFile)) unlink($cookieFile);

// 1. Login
$ch = curl_init("{$baseUrl}/api.php/auth/login");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['email' => 'admin@residence.ci', 'password' => 'admin123']));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
$res = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP LOGIN ({$httpCode}): " . $res . "\n";

// 2. GET Rooms
$ch = curl_init("{$baseUrl}/api.php/rooms");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$resRooms = curl_exec($ch);
$httpCodeRooms = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$json = json_decode($resRooms, true);
echo "HTTP ROOMS ({$httpCodeRooms}) COUNT: " . (is_array($json['data'] ?? null) ? count($json['data']) : 'NULL') . "\n";
if (!empty($json['data'][0])) {
    echo "ROOM #{$json['data'][0]['number']} OCCUPANT: " . json_encode($json['data'][0]['current_occupant'], JSON_UNESCAPED_UNICODE) . "\n";
}

// 3. GET Dashboard
$ch = curl_init("{$baseUrl}/api.php/dashboard");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$resDash = curl_exec($ch);
$httpCodeDash = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$dashJson = json_decode($resDash, true);
echo "HTTP DASHBOARD ({$httpCodeDash}) STATUS: " . ($dashJson['status'] ?? 'ERROR') . "\n";
if (!empty($dashJson['data']['finance']['kpis'])) {
    echo "DASHBOARD KPIS: CA = " . $dashJson['data']['finance']['kpis']['revenue'] . " FCFA, OCCUPANCY = " . $dashJson['data']['finance']['kpis']['occupancy_rate'] . "%\n";
}

if (file_exists($cookieFile)) unlink($cookieFile);
