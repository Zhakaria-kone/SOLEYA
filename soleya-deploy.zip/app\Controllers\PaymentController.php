<?php
// app/Controllers/PaymentController.php

namespace App\Controllers;

use App\Models\Payment;
use App\Models\Reservation;
use App\Models\Client;
use App\Models\PaymentMethod;
use App\Models\FinancialAccount;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Helpers\Format;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class PaymentController
{
    private Payment $paymentModel;
    private Reservation $reservationModel;
    private PaymentMethod $methodModel;
    private FinancialAccount $accountModel;

    public function __construct()
    {
        $this->paymentModel = new Payment();
        $this->reservationModel = new Reservation();
        $this->methodModel = new PaymentMethod();
        $this->accountModel = new FinancialAccount();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('payments');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;

        $payments = $this->paymentModel->allWithDetails($from, $to);
        $methods = $this->methodModel->all();
        $accounts = $this->accountModel->allWithBalances();

        Response::success([
            'payments' => $payments,
            'methods' => $methods,
            'accounts' => $accounts
        ]);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('payments');

        $resId = !empty($params['reservation_id']) ? (int)$params['reservation_id'] : null;
        $clientId = !empty($params['client_id']) ? (int)$params['client_id'] : null;
        $amount = (int)($params['amount'] ?? 0);
        $methodId = (int)($params['payment_method_id'] ?? 1);
        $accountId = (int)($params['financial_account_id'] ?? 1);
        $transRef = trim($params['transaction_ref'] ?? '');
        $date = !empty($params['payment_date']) ? $params['payment_date'] : Format::today();
        $time = !empty($params['payment_time']) ? $params['payment_time'] : date('H:i');
        $type = in_array($params['type'] ?? '', ['PAIEMENT', 'REMBOURSEMENT']) ? $params['type'] : 'PAIEMENT';

        if ($amount <= 0) {
            Response::error('Le montant doit être supérieur à zéro.', 422);
        }

        if ($resId) {
            $res = $this->reservationModel->find($resId);
            if (!$res) {
                Response::error('Réservation introuvable.', 404);
            }
            if (!$clientId) {
                $clientId = (int)$res['client_id'];
            }
        }

        if (!$clientId) {
            Response::error('Veuillez sélectionner un client ou une réservation.', 422);
        }

        $ref = $this->paymentModel->nextReference();
        $id = $this->paymentModel->create([
            'reference' => $ref,
            'type' => $type,
            'payment_date' => $date,
            'payment_time' => $time,
            'reservation_id' => $resId,
            'client_id' => $clientId,
            'invoice_id' => !empty($params['invoice_id']) ? (int)$params['invoice_id'] : null,
            'amount' => $amount,
            'payment_method_id' => $methodId,
            'financial_account_id' => $accountId,
            'transaction_ref' => $transRef,
            'author_name' => $user['name']
        ]);

        AuditLog::log("Encaissement #{$ref}", "Montant : " . Format::money($amount) . " ({$type})", $user['name']);

        $receipt = $this->paymentModel->findReceiptData($id);
        Response::success($receipt, 'Paiement enregistré avec succès.', 201);
    }

    public function receipt(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('payments');

        $id = (int)($routeParams['id'] ?? 0);
        $receipt = $this->paymentModel->findReceiptData($id);
        if (!$receipt) {
            Response::error('Reçu introuvable.', 404);
        }

        Response::success($receipt);
    }
}
