/* RESIDENCE MANAGER - Couche de données (frontend seul, persistance localStorage) */
const STORE_KEY = 'residence_manager_front_v2';

/* ---------- Helpers generiques ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => Math.round(n || 0).toLocaleString('fr-FR').replace(/[\u202f\u00a0]/g, ' ');
const fcfa = n => fmt(n) + ' FCFA';
const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return iso(d); };
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5);
const fdate = s => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');
const fshort = s => (s ? s.slice(8, 10) + '/' + s.slice(5, 7) : '');
const TODAY = iso(new Date());

/* ---------- Referentiels ---------- */
const MODULES = [
  { id: 'dashboard', label: 'Tableau de bord', icon: 'bi-house-door-fill' },
  { id: 'rooms', label: 'Chambres', icon: 'bi-door-closed-fill' },
  { id: 'reservations', label: 'Réservations', icon: 'bi-calendar-check-fill' },
  { id: 'clients', label: 'Clients', icon: 'bi-person-fill' },
  { id: 'stays', label: 'Séjours', icon: 'bi-key-fill' },
  { id: 'payments', label: 'Encaissements', icon: 'bi-wallet2' },
  { id: 'expenses', label: 'Dépenses', icon: 'bi-receipt' },
  { id: 'purchases', label: 'Achats', icon: 'bi-cart-fill' },
  { id: 'suppliers', label: 'Fournisseurs', icon: 'bi-truck' },
  { id: 'invoices', label: 'Facturation', icon: 'bi-file-earmark-text-fill' },
  { id: 'reports', label: 'Rapports', icon: 'bi-bar-chart-fill' },
  { id: 'settings', label: 'Paramètres', icon: 'bi-gear-fill' }
];
const ROLES = {
  admin: 'Propriétaire',
  manager: 'Gestionnaire',
  gestionnaire: 'Gestionnaire',
  reception: 'Réceptionniste',
  receptionniste: 'Réceptionniste',
  accountant: 'Comptable',
  comptable: 'Comptable'
};
const isAdmin = () => Boolean((typeof window !== 'undefined' && window.SESSION && window.SESSION.role === 'admin') || (typeof SESSION !== 'undefined' && SESSION && SESSION.role === 'admin'));
const EXPENSE_CATS = ['Électricité', 'Eau', 'Internet', 'Nettoyage', 'Entretien', 'Réparation', 'Transport', 'Personnel', 'Consommables', 'Fournitures', 'Équipements', 'Autres'];

/* Noms conviviaux des chambres (sans notion d etage) */
const ROOM_NAMES = [
  'Chambre 101', 'Chambre 102', 'Chambre 103', 'Chambre 104',
  'Chambre 201', 'Chambre 202', 'Chambre 203', 'Chambre 204',
  'Chambre 301', 'Chambre 302', 'Chambre 303', 'Chambre 304',
  'Suite Orchidée', 'Suite Baobab', 'Suite Hibiscus', 'Suite Ebène',
  'Chambre Corail', 'Chambre Lagune', 'Chambre Palme', 'Chambre Safari',
  'Chambre Ivoire', 'Chambre Savane', 'Suite Royale', 'Suite Prestige'
];

/* ---------- Donnees de demonstration ---------- */
function seedState() {
  let sv = 11; const rnd = () => (sv = (sv * 9301 + 49297) % 233280) / 233280;
  const S = {
    building: {
      name: 'Résidence Prestige',
      address: 'Cocody, Riviera Palmeraie',
      city: 'Abidjan',
      phone: '+225 07 00 00 00 00',
      email: 'contact@residence-prestige.ci',
      description: 'Résidence meublée haut de gamme.',
      manager: 'Administrateur',
      billing: 'RCCM CI-ABJ-2024-B-00000 — Compte contribuable 0000000A',
      taxRate: 0,
      terms: 'Paiement à réception de facture.'
    },
    roomTypes: [
      { id: 1, name: 'Standard', daily: 25000, weekly: 150000, monthly: 500000, capacity: 2 },
      { id: 2, name: 'Confort', daily: 35000, weekly: 210000, monthly: 700000, capacity: 3 },
      { id: 3, name: 'Suite', daily: 55000, weekly: 330000, monthly: 1100000, capacity: 4 }
    ],
    rooms: [], clients: [], reservations: [], payments: [], expenses: [], suppliers: [], purchases: [], supplierPayments: [], invoices: [],
    methods: ['Espèces', 'Wave', 'Orange Money', 'MTN Mobile Money', 'Moov Money', 'Virement bancaire', 'Carte bancaire', 'Chèque'].map((n, i) => ({ id: i + 1, name: n, active: true })),
    accounts: [
      { id: 1, name: 'Caisse physique', opening: 600000, active: true },
      { id: 2, name: 'Compte Wave', opening: 250000, active: true },
      { id: 3, name: 'Compte Orange Money', opening: 150000, active: true },
      { id: 4, name: 'Compte MTN Money', opening: 50000, active: true },
      { id: 5, name: 'Compte Moov Money', opening: 0, active: true },
      { id: 6, name: 'Compte bancaire', opening: 1800000, active: true }
    ],
    users: [
      { id: 1, name: 'Administrateur', email: 'admin@residence.ci', password: 'admin123', role: 'admin', active: true },
      { id: 2, name: 'Awa Gestionnaire', email: 'gestion@residence.ci', password: 'gestion123', role: 'manager', active: true },
      { id: 3, name: 'Koffi Réception', email: 'reception@residence.ci', password: 'reception123', role: 'reception', active: true },
      { id: 4, name: 'Mariam Comptable', email: 'compta@residence.ci', password: 'compta123', role: 'accountant', active: true }
    ],
    perms: {
      admin: MODULES.map(m => m.id),
      manager: ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'reports'],
      reception: ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'invoices'],
      accountant: ['dashboard', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports']
    },
    audit: [], seq: {}
  };

  const equip = [
    'Climatisation, Wi-Fi, TV, Réfrigérateur',
    'Climatisation, Wi-Fi, TV, Kitchenette',
    'Climatisation, Wi-Fi, TV, Kitchenette, Balcon'
  ];

  for (let i = 0; i < ROOM_NAMES.length; i++) {
    const t = S.roomTypes[i < 8 ? 0 : i < 16 ? 1 : 2];
    S.rooms.push({
      id: i + 1,
      number: ROOM_NAMES[i],
      typeId: t.id,
      capacity: t.capacity,
      area: 20 + t.id * 8,
      daily: t.daily,
      weekly: t.weekly,
      monthly: t.monthly,
      status: 'LIBRE',
      equipment: equip[t.id - 1],
      description: `${ROOM_NAMES[i]} (${t.name}) équipée tout confort.`
    });
  }

  const roomByName = n => S.rooms.find(r => r.number === n);
  const people = [
    ['Marie', 'Dupont'], ['Jean Baptiste', 'Koffi'], ['Aminata', 'Traoré'], ['Yao', 'Kouassi'],
    ['Fatoumata', 'Diallo'], ['Eric', 'N’Guessan'], ['Salimata', 'Bamba'], ['Serge', 'Konan'],
    ['Mariam', 'Touré'], ['Christelle', 'Yao'], ['Ibrahim', 'Coulibaly'], ['Awa', 'Ouattara'],
    ['Franck', 'Kouamé'], ['Nadège', 'Soro']
  ];

  people.forEach((p, i) => S.clients.push({
    id: i + 1,
    first: p[0],
    last: p[1],
    phone: '+225 07 ' + String(10 + i * 7).padStart(2, '0') + ' ' + String(20 + i * 3) + ' ' + String(30 + i * 5) + ' ' + String(40 + i * 2),
    email: (p[0].split(' ')[0] + '.' + p[1]).toLowerCase().replace(/[’']/g, '') + '@mail.com',
    address: 'Abidjan',
    nationality: i % 5 === 4 ? 'Malienne' : 'Ivoirienne',
    idType: i % 3 === 0 ? 'Passeport' : 'CNI',
    idNumber: 'CI' + (100000 + i * 7311),
    notes: '',
    createdAt: addDays(TODAY, -90 + i * 3)
  }));

  S.suppliers = [
    { id: 1, name: 'Fournisseur ABC', phone: '+225 01 02 03 04 05', email: 'abc@fourn.ci', address: 'Yopougon', nature: 'Produits d’entretien' },
    { id: 2, name: 'CIE', phone: '+225 27 21 00 00 00', email: '', address: 'Abidjan', nature: 'Électricité' },
    { id: 3, name: 'SODECI', phone: '+225 27 21 11 11 11', email: '', address: 'Abidjan', nature: 'Eau' },
    { id: 4, name: 'Électro Plus', phone: '+225 05 05 05 05 05', email: 'contact@electroplus.ci', address: 'Marcory', nature: 'Équipements, réparations' },
    { id: 5, name: 'Linge & Confort', phone: '+225 07 08 09 10 11', email: '', address: 'Treichville', nature: 'Linge de maison' }
  ];

  const nid = c => (S.seq[c] = (S[c].reduce((m, x) => Math.max(m, x.id), 0)) + 1);
  const accOfMethod = mid => ({ 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 }[mid] || 6);

  const addRes = (roomN, ci, a, d, status, pct, extra = 0, disc = 0) => {
    const r = roomByName(roomN);
    const nights = Math.max(1, diffDays(a, d));
    const res = {
      id: nid('reservations'),
      clientId: ci,
      roomId: r.id,
      arrival: a,
      departure: d,
      guests: 1 + (ci % 2),
      rate: r.daily,
      nights,
      discount: disc,
      extra,
      total: nights * r.daily + extra - disc,
      deposit: 0,
      status,
      notes: '',
      createdAt: addDays(a, -3)
    };
    S.reservations.push(res);
    const paid = Math.round(res.total * pct / 100 / 500) * 500;
    if (paid > 0) {
      const mid = 1 + Math.floor(rnd() * 5);
      res.deposit = paid;
      S.payments.push({
        id: nid('payments'),
        ref: '',
        type: 'PAIEMENT',
        date: status === 'CONFIRMEE' || status === 'EN_ATTENTE' ? addDays(TODAY, -1) : a,
        time: '1' + Math.floor(rnd() * 8) + ':' + String(10 + Math.floor(rnd() * 49)),
        resId: res.id,
        clientId: ci,
        invoiceId: null,
        amount: paid,
        methodId: mid,
        accountId: accOfMethod(mid),
        txRef: '',
        author: 'Administrateur'
      });
    }
    return res;
  };

  /* Sejours en cours */
  const occ = [
    ['Chambre 101', 1, -3, 3], ['Chambre 103', 2, -2, 4], ['Chambre 201', 3, -4, 2],
    ['Chambre 203', 4, -1, 5], ['Chambre 302', 5, -2, 3], ['Suite Orchidée', 6, -3, 2],
    ['Suite Ebène', 7, -5, 3], ['Chambre Corail', 8, -2, 4], ['Chambre Palme', 9, -1, 6],
    ['Chambre Safari', 10, -4, 2], ['Chambre Ivoire', 11, -1, 4], ['Suite Royale', 12, -3, 5]
  ];
  occ.forEach((o, i) => addRes(o[0], o[1], addDays(TODAY, o[2]), addDays(TODAY, o[3]), 'EN_COURS', i % 3 === 0 ? 100 : 60));

  /* Reservations a venir */
  addRes('Chambre 104', 13, addDays(TODAY, 1), addDays(TODAY, 4), 'CONFIRMEE', 30);
  addRes('Chambre 202', 2, addDays(TODAY, 1), addDays(TODAY, 6), 'CONFIRMEE', 30);
  addRes('Chambre 301', 3, addDays(TODAY, 2), addDays(TODAY, 5), 'EN_ATTENTE', 0);
  addRes('Suite Baobab', 4, addDays(TODAY, 3), addDays(TODAY, 8), 'CONFIRMEE', 40);
  addRes('Chambre Lagune', 1, addDays(TODAY, 4), addDays(TODAY, 9), 'CONFIRMEE', 20);

  /* Sejours termines */
  for (let k = 0; k < 14; k++) {
    const r = S.rooms[(k * 3 + 1) % S.rooms.length];
    const dur = 2 + (k % 4);
    const end = addDays(TODAY, -6 - k * 3);
    addRes(r.number, (k % people.length) + 1, addDays(end, -dur), end, 'TERMINEE', 100, k % 4 === 0 ? 5000 : 0, 0);
  }

  /* Statuts operationnels */
  S.rooms.forEach(r => { r.status = 'LIBRE'; });
  occ.forEach(o => { const r = roomByName(o[0]); if (r) r.status = 'OCCUPEE'; });
  ['Chambre 104', 'Chambre 202', 'Suite Baobab'].forEach(n => { const r = roomByName(n); if (r) r.status = 'RESERVEE'; });
  const clR = roomByName('Chambre 204'); if (clR) clR.status = 'A_NETTOYER';
  const mR = roomByName('Chambre 304'); if (mR) mR.status = 'MAINTENANCE';

  /* References paiements */
  S.payments.sort((a, b) => a.date.localeCompare(b.date)).forEach((p, i) => {
    p.ref = 'PAY-' + p.date.slice(0, 4) + '-' + String(i + 1).padStart(4, '0');
  });

  /* Factures */
  S.reservations.filter(r => r.status === 'TERMINEE' || (r.status === 'EN_COURS' && r.id % 2 === 0)).forEach((r, i) => {
    const inv = {
      id: nid('invoices'),
      number: 'FAC-' + TODAY.slice(0, 4) + '-' + String(i + 1).padStart(3, '0'),
      type: 'FACTURE',
      date: r.status === 'TERMINEE' ? r.departure : r.arrival,
      clientId: r.clientId,
      resId: r.id,
      items: reservationLines(S, r),
      taxRate: 0,
      status: 'EMISE',
      terms: S.building.terms
    };
    S.invoices.push(inv);
    S.payments.filter(p => p.resId === r.id).forEach(p => { p.invoiceId = inv.id; });
  });

  /* Depenses */
  const ex = [
    ['Électricité', 'Facture électricité', 185000, 2, 'PAYEE', 2],
    ['Eau', 'Facture SODECI', 62000, 3, 'PAYEE', 6],
    ['Internet', 'Abonnement fibre optique', 45000, 0, 'PAYEE', 9],
    ['Nettoyage', 'Produits d’entretien écologiques', 38500, 1, 'PAYEE', 4],
    ['Personnel', 'Salaires ménage et accueil', 150000, 0, 'PAYEE', 15],
    ['Réparation', 'Réparation climatiseur Chambre 304', 95000, 4, 'VALIDEE', 3],
    ['Fournitures', 'Draps et serviettes coton', 120000, 5, 'EN_ATTENTE_VALIDATION', 2],
    ['Transport', 'Course logistique fournisseur', 7500, 0, 'BROUILLON', 1],
    ['Entretien', 'Jardinage et espaces verts', 25000, 0, 'REJETEE', 11],
    ['Électricité', 'Facture électricité mois précédent', 172000, 2, 'PAYEE', 28],
    ['Eau', 'Facture eau mois précédent', 58000, 3, 'PAYEE', 31],
    ['Consommables', 'Savons d’accueil, papier hygiénique', 33000, 1, 'PAYEE', 20]
  ];
  ex.forEach((e, i) => {
    const id = nid('expenses');
    const mid = e[4] === 'PAYEE' ? (i % 2 ? 1 : 2) : 1;
    const date = addDays(TODAY, -e[5]);
    S.expenses.push({
      id,
      ref: 'DEP-' + date.slice(0, 4) + '-' + String(i + 1).padStart(4, '0'),
      date,
      time: '1' + (i % 6) + ':' + String(10 + i * 3),
      category: e[0],
      label: e[1],
      amount: e[2],
      supplierId: e[3] || '',
      methodId: mid,
      accountId: accOfMethod(mid),
      roomId: '',
      status: e[4],
      paidAmount: e[4] === 'PAYEE' ? e[2] : 0,
      author: 'Administrateur'
    });
  });

  /* Achats */
  const pu = [
    [1, 4, [['Produits d’entretien', 10, 3850]], 38500, 38500, 'EXPLOITATION'],
    [5, 12, [['Draps 2 places', 20, 8500], ['Serviettes de bain', 40, 2500]], 270000, 100000, 'EXPLOITATION'],
    [4, 20, [['Climatiseur split inverter', 1, 285000]], 285000, 0, 'IMMOBILISATION'],
    [1, 25, [['Désodorisants diffuseurs', 30, 1200]], 36000, 36000, 'EXPLOITATION']
  ];
  pu.forEach((p, i) => {
    const date = addDays(TODAY, -p[1]);
    const id = nid('purchases');
    S.purchases.push({
      id,
      ref: 'ACH-' + date.slice(0, 4) + '-' + String(i + 1).padStart(4, '0'),
      supplierId: p[0],
      date,
      items: p[2].map(x => ({ label: x[0], qty: x[1], price: x[2] })),
      terms: p[4] >= p[3] ? 'Comptant' : 'À crédit',
      kind: p[5],
      author: 'Administrateur'
    });
    if (p[4] > 0) {
      S.supplierPayments.push({
        id: nid('supplierPayments'),
        purchaseId: id,
        date,
        amount: p[4],
        accountId: 1,
        methodId: 1
      });
    }
  });

  S.audit.push({
    ts: new Date().toISOString(),
    user: 'Système',
    action: 'Initialisation des données de la résidence'
  });
  return S;
}

/* ---------- Store ---------- */
const DB = {
  init() {
    this.s = seedState();
    if (typeof window !== 'undefined' && window.SERVER_ROOMS && Array.isArray(window.SERVER_ROOMS)) {
      this.hydrateFromServer();
    } else {
      try {
        const local = JSON.parse(localStorage.getItem(STORE_KEY));
        if (local) this.s = local;
      } catch (e) {}
    }
  },
  hydrateFromServer() {
    if (window.SERVER_BUILDING) {
      this.s.building = {
        name: window.SERVER_BUILDING.name || 'Résidence Prestige',
        address: window.SERVER_BUILDING.address || '',
        city: window.SERVER_BUILDING.city || '',
        phone: window.SERVER_BUILDING.phone || '',
        email: window.SERVER_BUILDING.email || '',
        description: window.SERVER_BUILDING.description || '',
        manager: window.SERVER_BUILDING.manager || '',
        billing: window.SERVER_BUILDING.billing || '',
        taxRate: Number(window.SERVER_BUILDING.tax_rate ?? window.SERVER_BUILDING.taxRate ?? 0),
        terms: window.SERVER_BUILDING.terms || ''
      };
    }
    if (window.SERVER_ROOM_TYPES && Array.isArray(window.SERVER_ROOM_TYPES) && window.SERVER_ROOM_TYPES.length) {
      this.s.roomTypes = window.SERVER_ROOM_TYPES.map(t => ({
        id: Number(t.id),
        name: t.name,
        daily: Number(t.daily_rate ?? t.daily ?? 25000),
        weekly: Number(t.weekly_rate ?? t.weekly ?? 150000),
        monthly: Number(t.monthly_rate ?? t.monthly ?? 500000),
        capacity: Number(t.capacity || 2)
      }));
    }
    if (window.SERVER_ROOMS && Array.isArray(window.SERVER_ROOMS)) {
      this.s.rooms = window.SERVER_ROOMS.map(r => {
        const rawSt = r.status;
        const normSt = (!rawSt || rawSt === 'DISPONIBLE' || !['LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE'].includes(rawSt))
          ? 'LIBRE'
          : rawSt;
        return {
          id: Number(r.id),
          number: r.number,
          typeId: Number(r.type_id || r.room_type_id || 1),
          capacity: Number(r.capacity || 2),
          area: r.area != null ? Number(r.area) : 25,
          daily: Number(r.daily_rate ?? r.daily ?? 25000),
          weekly: Number(r.weekly_rate ?? r.weekly ?? (Number(r.daily_rate || 25000) * 6)),
          monthly: Number(r.monthly_rate ?? r.monthly ?? (Number(r.daily_rate || 25000) * 20)),
          status: normSt,
          equipment: r.equipment || 'Climatisation, Wi-Fi, TV',
          description: r.description || '',
          current_occupant: r.current_occupant || null,
          upcoming_reservation: r.upcoming_reservation || null
        };
      });
    }
    if (window.SERVER_CLIENTS && Array.isArray(window.SERVER_CLIENTS)) {
      this.s.clients = window.SERVER_CLIENTS.map(c => ({
        id: Number(c.id),
        first: c.first_name || c.first || '',
        last: c.last_name || c.last || '',
        phone: c.phone || '',
        email: c.email || '',
        address: c.address || 'Abidjan',
        nationality: c.nationality || 'Ivoirienne',
        idType: c.id_type || c.idType || (c.id_card_number ? 'CNI / Passeport' : 'CNI'),
        idNumber: c.id_number || c.id_card_number || c.idNumber || '',
        notes: c.notes || '',
        createdAt: c.created_at ? String(c.created_at).slice(0, 10) : TODAY
      }));
    }
    if (window.SERVER_RESERVATIONS && Array.isArray(window.SERVER_RESERVATIONS)) {
      this.s.reservations = window.SERVER_RESERVATIONS.map(r => ({
        id: Number(r.id),
        clientId: Number(r.client_id),
        roomId: Number(r.room_id),
        arrival: r.arrival_date,
        departure: r.departure_date,
        guests: Number(r.guests || 1),
        rate: Number(r.rate_applied),
        nights: Number(r.nights),
        discount: Number(r.discount_amount || 0),
        extra: Number(r.extra_amount || 0),
        total: Number(r.total_amount),
        deposit: Number(r.deposit_amount || 0),
        status: r.status,
        notes: r.notes || '',
        createdAt: r.created_at ? String(r.created_at).slice(0, 10) : r.arrival_date
      }));
    }
    if (window.SERVER_PAYMENTS && Array.isArray(window.SERVER_PAYMENTS)) {
      this.s.payments = window.SERVER_PAYMENTS.map(p => ({
        id: Number(p.id),
        ref: p.reference,
        type: p.type,
        date: p.payment_date,
        time: p.payment_time || '12:00',
        resId: p.reservation_id ? Number(p.reservation_id) : null,
        clientId: Number(p.client_id),
        invoiceId: p.invoice_id ? Number(p.invoice_id) : null,
        amount: Number(p.amount),
        methodId: Number(p.payment_method_id),
        accountId: Number(p.financial_account_id),
        txRef: p.transaction_ref || '',
        transRef: p.transaction_ref || '',
        author: p.author_name || 'Administrateur'
      }));
    }
    if (window.SERVER_EXPENSES && Array.isArray(window.SERVER_EXPENSES)) {
      this.s.expenses = window.SERVER_EXPENSES.map(e => ({
        id: Number(e.id),
        ref: e.reference,
        date: e.expense_date,
        time: e.expense_time || '10:00',
        category: e.category,
        label: e.label || e.description || '',
        amount: Number(e.amount),
        paidAmount: e.paid_amount != null ? Number(e.paid_amount) : (e.status === 'PAYEE' ? Number(e.amount) : 0),
        supplierId: e.supplier_id ? Number(e.supplier_id) : '',
        roomId: e.room_id ? Number(e.room_id) : '',
        methodId: e.payment_method_id ? Number(e.payment_method_id) : 1,
        accountId: e.financial_account_id ? Number(e.financial_account_id) : 1,
        status: e.status,
        author: e.author_name || e.created_by || 'Administrateur'
      }));
    }
    if (window.SERVER_PURCHASES && Array.isArray(window.SERVER_PURCHASES)) {
      this.s.purchases = window.SERVER_PURCHASES.map(pu => ({
        id: Number(pu.id),
        ref: pu.reference,
        supplierId: Number(pu.supplier_id),
        date: pu.purchase_date,
        kind: pu.kind || 'EXPLOITATION',
        terms: pu.terms || 'Comptant',
        items: Array.isArray(pu.items) ? pu.items.map(it => ({
          label: it.label,
          qty: Number(it.quantity ?? it.qty ?? 1),
          price: Number(it.unit_price ?? it.price ?? 0)
        })) : [],
        author: pu.author_name || 'Administrateur'
      }));
    }
    if (window.SERVER_SUPPLIER_PAYMENTS && Array.isArray(window.SERVER_SUPPLIER_PAYMENTS)) {
      this.s.supplierPayments = window.SERVER_SUPPLIER_PAYMENTS.map(sp => ({
        id: Number(sp.id),
        purchaseId: Number(sp.purchase_id),
        date: sp.payment_date,
        amount: Number(sp.amount),
        accountId: Number(sp.financial_account_id || 1),
        methodId: Number(sp.payment_method_id || 1)
      }));
    } else if (window.SERVER_PURCHASES && Array.isArray(window.SERVER_PURCHASES)) {
      this.s.supplierPayments = [];
    }
    if (window.SERVER_SUPPLIERS && Array.isArray(window.SERVER_SUPPLIERS)) {
      this.s.suppliers = window.SERVER_SUPPLIERS.map(s => ({
        id: Number(s.id),
        name: s.name,
        phone: s.phone || '',
        email: s.email || '',
        address: s.address || '',
        nature: s.nature || s.category || ''
      }));
    }
    if (window.SERVER_INVOICES && Array.isArray(window.SERVER_INVOICES)) {
      this.s.invoices = window.SERVER_INVOICES.map(inv => {
        const items = Array.isArray(inv.items) && inv.items.length
          ? inv.items.map(it => ({
              label: it.label,
              qty: Number(it.quantity ?? it.qty ?? 1),
              price: Number(it.unit_price ?? it.price ?? 0)
            }))
          : (Number(inv.total_ht || inv.total_ttc || 0) > 0
              ? [{ label: `Facture ${inv.number}`, qty: 1, price: Number(inv.total_ht || inv.total_ttc || 0) }]
              : []);
        return {
          id: Number(inv.id),
          number: inv.number,
          type: inv.type,
          date: inv.issue_date,
          clientId: Number(inv.client_id),
          resId: inv.reservation_id ? Number(inv.reservation_id) : null,
          taxRate: Number(inv.tax_rate || 0),
          status: inv.status,
          terms: inv.terms || '',
          items
        };
      });
    }
    if (window.SERVER_ACCOUNTS && Array.isArray(window.SERVER_ACCOUNTS) && window.SERVER_ACCOUNTS.length) {
      this.s.accounts = window.SERVER_ACCOUNTS.map(a => ({
        id: Number(a.id),
        name: a.name,
        opening: Number(a.opening_balance ?? a.opening ?? 0),
        active: Boolean(Number(a.is_active ?? a.active ?? 1))
      }));
    }
    if (window.SERVER_METHODS && Array.isArray(window.SERVER_METHODS) && window.SERVER_METHODS.length) {
      this.s.methods = window.SERVER_METHODS.map(m => ({
        id: Number(m.id),
        name: m.name,
        active: Boolean(Number(m.is_active ?? m.active ?? 1))
      }));
    }
    if (window.SERVER_USERS && Array.isArray(window.SERVER_USERS) && window.SERVER_USERS.length) {
      this.s.users = window.SERVER_USERS.map(u => ({
        id: Number(u.id),
        name: u.name,
        email: u.email,
        password: '',
        role: u.role,
        active: Boolean(Number(u.is_active ?? u.active ?? 1))
      }));
    }
    if (window.SERVER_ROLE_PERMISSIONS && typeof window.SERVER_ROLE_PERMISSIONS === 'object') {
      Object.assign(this.s.perms, window.SERVER_ROLE_PERMISSIONS);
    }
    if (window.SERVER_AUDIT && Array.isArray(window.SERVER_AUDIT)) {
      this.s.audit = window.SERVER_AUDIT.map(a => ({
        ts: a.created_at ? String(a.created_at).replace(' ', 'T') : new Date().toISOString(),
        user: a.user_name || a.user || 'Système',
        action: a.details ? `${a.action} — ${a.details}` : a.action
      }));
    }
    this.save();
  },
  save() { localStorage.setItem(STORE_KEY, JSON.stringify(this.s)); },
  clearDemoData(srvData = null) {
    this.s.reservations = [];
    this.s.clients = [];
    this.s.payments = [];
    this.s.expenses = [];
    this.s.purchases = [];
    this.s.supplierPayments = [];
    this.s.suppliers = [];
    this.s.invoices = [];

    if (srvData && Array.isArray(srvData.rooms)) {
      window.SERVER_ROOMS = srvData.rooms;
    }
    this.s.rooms.forEach(r => {
      r.status = 'LIBRE';
      r.current_occupant = null;
      r.upcoming_reservation = null;
    });

    if (srvData && Array.isArray(srvData.financial_accounts)) {
      window.SERVER_ACCOUNTS = srvData.financial_accounts;
    }
    this.s.accounts.forEach(a => {
      a.opening = 0;
    });

    if (srvData && Array.isArray(srvData.audit_logs)) {
      window.SERVER_AUDIT = srvData.audit_logs;
      this.s.audit = srvData.audit_logs.map(a => ({
        ts: a.created_at ? String(a.created_at).replace(' ', 'T') : new Date().toISOString(),
        user: a.user_name || 'Administrateur',
        action: a.details ? `${a.action} — ${a.details}` : a.action
      }));
    } else {
      this.s.audit = [{
        ts: new Date().toISOString(),
        user: (window.SESSION && SESSION.name) || 'Administrateur',
        action: 'Réinitialisation des données de démonstration'
      }];
    }

    window.SERVER_CLIENTS = [];
    window.SERVER_RESERVATIONS = [];
    window.SERVER_PAYMENTS = [];
    window.SERVER_EXPENSES = [];
    window.SERVER_PURCHASES = [];
    window.SERVER_SUPPLIER_PAYMENTS = [];
    window.SERVER_SUPPLIERS = [];
    window.SERVER_INVOICES = [];

    this.save();
  },
  reset() {
    this.clearDemoData();
  },
  next(c) { return this.s[c].reduce((m, x) => Math.max(m, x.id), 0) + 1; },
  find(c, id) { return this.s[c].find(x => String(x.id) === String(id)); },
  add(c, o) { o.id = this.next(c); this.s[c].push(o); this.save(); return o; },
  upd(c, id, patch) { const o = this.find(c, id); if (o) Object.assign(o, patch); this.save(); return o; },
  del(c, id) { this.s[c] = this.s[c].filter(x => String(x.id) !== String(id)); this.save(); },
  log(action) {
    this.s.audit.unshift({
      ts: new Date().toISOString(),
      user: (window.SESSION && SESSION.name) || 'Système',
      action
    });
    this.s.audit = this.s.audit.slice(0, 300);
    this.save();
  },
  ref(prefix, coll) {
    const y = TODAY.slice(0, 4);
    const n = this.s[coll].filter(x => (x.ref || x.number || '').startsWith(prefix + '-' + y)).length + 1;
    return `${prefix}-${y}-${String(n).padStart(4, '0')}`;
  },
  async syncFromAPI() {
    if (typeof API === 'undefined') return;
    try {
      const [rooms, clients, reservations, payments, expenses, purchases, suppliers, invoices, settings] = await Promise.all([
        API.getRooms().catch(() => null),
        API.getClients().catch(() => null),
        API.getReservations().catch(() => null),
        API.getPayments().catch(() => null),
        API.getExpenses().catch(() => null),
        API.getPurchases().catch(() => null),
        API.getSuppliers().catch(() => null),
        API.getInvoices().catch(() => null),
        API.getSettings().catch(() => null)
      ]);

      if (rooms && Array.isArray(rooms)) {
        this.s.rooms = rooms.map(r => {
          const rawSt = r.status;
          const normSt = (!rawSt || rawSt === 'DISPONIBLE' || !['LIBRE', 'RESERVEE', 'OCCUPEE', 'A_NETTOYER', 'MAINTENANCE'].includes(rawSt))
            ? 'LIBRE'
            : rawSt;
          return {
            id: Number(r.id),
            number: r.number,
            typeId: Number(r.type_id || r.room_type_id || 1),
            capacity: Number(r.capacity || 2),
            area: r.area != null ? Number(r.area) : 25,
            daily: Number(r.daily_rate || 25000),
            weekly: Number(r.weekly_rate || (Number(r.daily_rate || 25000) * 6)),
            monthly: Number(r.monthly_rate || (Number(r.daily_rate || 25000) * 20)),
            status: normSt,
            equipment: r.equipment || 'Climatisation, Wi-Fi, TV',
            description: r.description || '',
            current_occupant: r.current_occupant || null,
            upcoming_reservation: r.upcoming_reservation || null
          };
        });
      }

      if (clients && Array.isArray(clients)) {
        this.s.clients = clients.map(c => ({
          id: Number(c.id),
          first: c.first_name,
          last: c.last_name,
          phone: c.phone,
          email: c.email || '',
          address: c.address || 'Abidjan',
          nationality: c.nationality || 'Ivoirienne',
          idType: c.id_type || (c.id_card_number ? 'CNI / Passeport' : 'CNI'),
          idNumber: c.id_number || c.id_card_number || '',
          notes: c.notes || '',
          createdAt: c.created_at ? String(c.created_at).slice(0, 10) : TODAY
        }));
      }

      if (reservations && Array.isArray(reservations)) {
        this.s.reservations = reservations.map(r => ({
          id: Number(r.id),
          clientId: Number(r.client_id),
          roomId: Number(r.room_id),
          arrival: r.arrival_date,
          departure: r.departure_date,
          guests: Number(r.guests || 1),
          rate: Number(r.rate_applied),
          nights: Number(r.nights),
          discount: Number(r.discount_amount || 0),
          extra: Number(r.extra_amount || 0),
          total: Number(r.total_amount),
          deposit: Number(r.deposit_amount || 0),
          status: r.status,
          notes: r.notes || '',
          createdAt: r.created_at ? String(r.created_at).slice(0, 10) : r.arrival_date
        }));
      }

      if (payments && payments.payments) {
        this.s.payments = payments.payments.map(p => ({
          id: Number(p.id),
          ref: p.reference,
          type: p.type,
          date: p.payment_date,
          time: p.payment_time || '12:00',
          resId: p.reservation_id ? Number(p.reservation_id) : null,
          clientId: Number(p.client_id),
          invoiceId: p.invoice_id ? Number(p.invoice_id) : null,
          amount: Number(p.amount),
          methodId: Number(p.payment_method_id),
          accountId: Number(p.financial_account_id),
          txRef: p.transaction_ref || '',
          transRef: p.transaction_ref || '',
          author: p.author_name || 'Administrateur'
        }));
      }

      if (expenses && expenses.expenses) {
        this.s.expenses = expenses.expenses.map(e => ({
          id: Number(e.id),
          ref: e.reference,
          date: e.expense_date,
          time: e.expense_time || '10:00',
          category: e.category,
          label: e.label || e.description || '',
          amount: Number(e.amount),
          paidAmount: e.paid_amount != null ? Number(e.paid_amount) : (e.status === 'PAYEE' ? Number(e.amount) : 0),
          supplierId: e.supplier_id ? Number(e.supplier_id) : '',
          roomId: e.room_id ? Number(e.room_id) : '',
          methodId: e.payment_method_id ? Number(e.payment_method_id) : 1,
          accountId: e.financial_account_id ? Number(e.financial_account_id) : 1,
          status: e.status,
          author: e.author_name || e.created_by || 'Administrateur'
        }));
      }

      if (purchases && purchases.purchases) {
        this.s.purchases = purchases.purchases.map(pu => ({
          id: Number(pu.id),
          ref: pu.reference,
          supplierId: Number(pu.supplier_id),
          date: pu.purchase_date,
          kind: pu.kind || 'EXPLOITATION',
          terms: pu.terms || 'Comptant',
          items: Array.isArray(pu.items) ? pu.items.map(it => ({
            label: it.label,
            qty: Number(it.quantity),
            price: Number(it.unit_price)
          })) : [],
          author: pu.author_name || 'Administrateur'
        }));
        if (Array.isArray(purchases.supplier_payments)) {
          this.s.supplierPayments = purchases.supplier_payments.map(sp => ({
            id: Number(sp.id),
            purchaseId: Number(sp.purchase_id),
            date: sp.payment_date,
            amount: Number(sp.amount),
            accountId: Number(sp.financial_account_id || 1),
            methodId: Number(sp.payment_method_id || 1)
          }));
        }
      }

      if (suppliers && Array.isArray(suppliers)) {
        this.s.suppliers = suppliers.map(s => ({
          id: Number(s.id),
          name: s.name,
          phone: s.phone || '',
          email: s.email || '',
          address: s.address || '',
          nature: s.nature || s.category || ''
        }));
      }

      if (invoices && invoices.invoices) {
        this.s.invoices = invoices.invoices.map(inv => {
          const items = Array.isArray(inv.items) && inv.items.length
            ? inv.items.map(it => ({
                label: it.label,
                qty: Number(it.quantity),
                price: Number(it.unit_price)
              }))
            : (Number(inv.total_ht || inv.total_ttc || 0) > 0
                ? [{ label: `Facture ${inv.number}`, qty: 1, price: Number(inv.total_ht || inv.total_ttc || 0) }]
                : []);
          return {
            id: Number(inv.id),
            number: inv.number,
            type: inv.type,
            date: inv.issue_date,
            clientId: Number(inv.client_id),
            resId: inv.reservation_id ? Number(inv.reservation_id) : null,
            taxRate: Number(inv.tax_rate || 0),
            status: inv.status,
            terms: inv.terms || '',
            items
          };
        });
      }

      if (settings) {
        if (settings.building) {
          this.s.building = {
            name: settings.building.name,
            address: settings.building.address,
            city: settings.building.city,
            phone: settings.building.phone,
            email: settings.building.email,
            description: settings.building.description,
            manager: settings.building.manager,
            billing: settings.building.billing,
            taxRate: Number(settings.building.tax_rate || 0),
            terms: settings.building.terms
          };
          window.SERVER_BUILDING = settings.building;
        }
        if (Array.isArray(settings.room_types) && settings.room_types.length) {
          this.s.roomTypes = settings.room_types.map(t => ({
            id: Number(t.id),
            name: t.name,
            daily: Number(t.daily_rate ?? t.daily ?? 25000),
            weekly: Number(t.weekly_rate ?? t.weekly ?? 150000),
            monthly: Number(t.monthly_rate ?? t.monthly ?? 500000),
            capacity: Number(t.capacity || 2)
          }));
        }
        if (Array.isArray(settings.financial_accounts) && settings.financial_accounts.length) {
          this.s.accounts = settings.financial_accounts.map(a => ({
            id: Number(a.id),
            name: a.name,
            opening: Number(a.opening_balance ?? a.opening ?? 0),
            active: Boolean(Number(a.is_active ?? a.active ?? 1))
          }));
        }
        if (Array.isArray(settings.payment_methods) && settings.payment_methods.length) {
          this.s.methods = settings.payment_methods.map(m => ({
            id: Number(m.id),
            name: m.name,
            active: Boolean(Number(m.is_active ?? m.active ?? 1))
          }));
        }
        if (Array.isArray(settings.users) && settings.users.length) {
          this.s.users = settings.users.map(u => ({
            id: Number(u.id),
            name: u.name,
            email: u.email,
            password: '',
            role: u.role,
            active: Boolean(Number(u.is_active ?? u.active ?? 1))
          }));
        }
        if (settings.role_permissions && typeof settings.role_permissions === 'object') {
          Object.assign(this.s.perms, settings.role_permissions);
        }
        if (Array.isArray(settings.audit_logs)) {
          this.s.audit = settings.audit_logs.map(a => ({
            ts: a.created_at ? String(a.created_at).replace(' ', 'T') : new Date().toISOString(),
            user: a.user_name || 'Système',
            action: a.details ? `${a.action} — ${a.details}` : a.action
          }));
        }
      }

      this.save();
    } catch (e) {
      console.warn('[API] syncFromAPI fallback local:', e);
    }
  }
};

/* ---------- Calculs metier ---------- */
const clientName = id => { const c = DB.find('clients', id); return c ? c.first + ' ' + c.last : '—'; };
const roomNum = id => { const r = DB.find('rooms', id); return r ? r.number : '—'; };
const methodName = id => (DB.find('methods', id) || {}).name || '—';
const accountName = id => (DB.find('accounts', id) || {}).name || '—';
const supplierName = id => (DB.find('suppliers', id) || {}).name || '—';

/* Recherche de l occupant actuel ou prochain */
const getCurrentOccupant = roomId => {
  if (!DB.s) return null;
  const room = DB.find('rooms', roomId);
  if (room && room.current_occupant) {
    const o = room.current_occupant;
    return {
      type: 'current',
      client: {
        first: o.first_name,
        last: o.last_name,
        phone: o.phone || o.client_phone,
        email: o.email
      },
      reservation: {
        id: o.reservation_id,
        arrival: o.arrival_date,
        departure: o.departure_date,
        nights: o.nights,
        total: o.total_amount
      },
      label: o.client_name || `${o.first_name} ${o.last_name}`,
      period: `Du ${fdate(o.arrival_date)} au ${fdate(o.departure_date)}`
    };
  }
  const current = DB.s.reservations.find(r => r.roomId === Number(roomId) && r.status === 'EN_COURS');
  if (current) {
    const c = DB.find('clients', current.clientId);
    return {
      type: 'current',
      client: c,
      reservation: current,
      label: c ? `${c.first} ${c.last}` : 'Occupant inconnu',
      period: `Du ${fdate(current.arrival)} au ${fdate(current.departure)}`
    };
  }
  const nextRes = DB.s.reservations
    .filter(r => r.roomId === Number(roomId) && ['CONFIRMEE', 'EN_ATTENTE'].includes(r.status) && r.departure >= TODAY)
    .sort((a, b) => a.arrival.localeCompare(b.arrival))[0];
  if (nextRes) {
    const c = DB.find('clients', nextRes.clientId);
    return {
      type: 'upcoming',
      client: c,
      reservation: nextRes,
      label: c ? `${c.first} ${c.last}` : 'Client réservé',
      period: `Réservé du ${fdate(nextRes.arrival)} au ${fdate(nextRes.departure)}`
    };
  }
  return null;
};

const resTotal = r => (r.nights || 0) * (r.rate || 0) + (r.extra || 0) - (r.discount || 0);
const resPaid = r => DB.s.payments.filter(p => p.resId === r.id).reduce((a, p) => a + p.amount, 0);
const resBalance = r => resTotal(r) - resPaid(r);
const reservationLines = (S, r) => {
  const room = S.rooms.find(x => x.id === r.roomId);
  const rName = room ? room.number : `Chambre #${r.roomId}`;
  const l = [{ label: `Séjour ${rName} du ${fdate(r.arrival)} au ${fdate(r.departure)}`, qty: r.nights, price: r.rate }];
  if (r.extra) l.push({ label: 'Frais supplémentaires', qty: 1, price: r.extra });
  if (r.discount) l.push({ label: 'Remise exceptionnelle', qty: 1, price: -r.discount });
  return l;
};
const invTotals = i => {
  const ht = i.items.reduce((a, x) => a + x.qty * x.price, 0);
  const tva = Math.round(ht * (i.taxRate || 0) / 100);
  return { ht, tva, ttc: ht + tva };
};
const invPaid = i => DB.s.payments.filter(p => p.invoiceId === i.id).reduce((a, p) => a + p.amount, 0);
const invBalance = i => (i.status === 'ANNULEE' ? 0 : (i.type === 'AVOIR' ? 0 : invTotals(i).ttc - invPaid(i)));
const purchTotal = p => p.items.reduce((a, x) => a + x.qty * x.price, 0);
const purchPaid = p => DB.s.supplierPayments.filter(x => x.purchaseId === p.id).reduce((a, x) => a + x.amount, 0);
const accountBalance = a => a.opening + DB.s.payments.filter(p => p.accountId === a.id).reduce((s, p) => s + p.amount, 0)
  - DB.s.expenses.filter(e => e.accountId === a.id).reduce((s, e) => s + (e.paidAmount || 0), 0)
  - DB.s.supplierPayments.filter(p => p.accountId === a.id).reduce((s, p) => s + p.amount, 0);
const treasury = () => DB.s.accounts.reduce((a, x) => a + accountBalance(x), 0);
const overlap = (roomId, a, d, exceptId) => DB.s.reservations.find(r => r.roomId === Number(roomId) && r.id !== exceptId && ['CONFIRMEE', 'EN_COURS'].includes(r.status) && a < r.departure && r.arrival < d);

function syncRoom(roomId) {
  const r = DB.find('rooms', roomId);
  if (!r || ['MAINTENANCE', 'A_NETTOYER'].includes(r.status)) return;
  const rs = DB.s.reservations.filter(x => x.roomId === r.id);
  if (rs.some(x => x.status === 'EN_COURS')) r.status = 'OCCUPEE';
  else if (rs.some(x => ['CONFIRMEE', 'EN_ATTENTE'].includes(x.status) && x.departure > TODAY && x.arrival <= addDays(TODAY, 3))) r.status = 'RESERVEE';
  else r.status = 'LIBRE';
  DB.save();
}
