<?php
// index.php - Front Controller MVC en PHP 8.2 pour RESIDENCE MANAGER

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';

// PSR-4 Autoloader
spl_autoload_register(function (string $class) {
    if (strpos($class, 'App\\') === 0) {
        $path = __DIR__ . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    } elseif (strpos($class, 'Routes\\') === 0) {
        $path = __DIR__ . '/routes/' . str_replace('\\', '/', substr($class, 7)) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

use App\Models\Building;
use App\Models\User;
use App\Models\Room;
use App\Models\RoomType;
use App\Models\Client;
use App\Models\Reservation;
use App\Models\Payment;
use App\Models\Expense;
use App\Models\Purchase;
use App\Models\Supplier;
use App\Models\Invoice;
use App\Models\FinancialAccount;
use App\Models\PaymentMethod;
use App\Models\AuditLog;
use App\Models\Model;
use App\Services\FinanceService;

$loginError = null;

// Traitement POST direct pour la connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $userModel = new User();
    $user = $userModel->findByEmail($email);

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'phone' => $user['phone'] ?? ''
        ];
        AuditLog::log("Connexion utilisateur", "Connexion réussie de {$user['name']} ({$user['role']})", $user['name']);
        header('Location: index.php');
        exit;
    } else {
        $loginError = 'Identifiant ou mot de passe incorrect.';
    }
}

// Traitement déconnexion PHP
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    if (!empty($_SESSION['user']['name'])) {
        AuditLog::log("Déconnexion", "Déconnexion de {$_SESSION['user']['name']}", $_SESSION['user']['name']);
    }
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    header('Location: index.php');
    exit;
}

// Données de l'établissement
$buildingModel = new Building();
$building = $buildingModel->get();

// Utilisateur courant en session
$currentUser = $_SESSION['user'] ?? null;

// Si non authentifié, afficher la vue de connexion PHP
if (!$currentUser) {
    require __DIR__ . '/views/auth/login.php';
    exit;
}

// Utilisateur authentifié : charger les données depuis MySQL pour rendu et hydratation serveur
$userModel = new User();
$allModules = ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings'];
$permissions = ($currentUser['role'] === 'admin')
    ? $allModules
    : $userModel->getPermissions($currentUser['role']);

// Données serveur MySQL
$roomModel = new Room();
$rooms = $roomModel->allWithDetails();

$roomTypeModel = new RoomType();
$roomTypes = $roomTypeModel->all('id ASC');

$clientModel = new Client();
$clients = $clientModel->allWithStats();

$resModel = new Reservation();
$reservations = $resModel->allWithDetails();

$payModel = new Payment();
$payments = $payModel->allWithDetails();

$expModel = new Expense();
$expenses = $expModel->allWithDetails();

$purModel = new Purchase();
$purchases = $purModel->allWithDetails();

$supplierPayments = Model::query("SELECT * FROM `supplier_payments` ORDER BY `payment_date` DESC, `id` DESC");

$supModel = new Supplier();
$suppliers = $supModel->allWithBalances();

$invModel = new Invoice();
$invoices = $invModel->allWithDetails();

$accModel = new FinancialAccount();
$accounts = $accModel->allWithBalances();

$mthModel = new PaymentMethod();
$methods = $mthModel->all('id ASC');

$usersList = User::query("SELECT id, name, email, role, is_active FROM `users` ORDER BY id ASC");
$rolePermissions = [
    'admin' => $allModules,
    'manager' => $userModel->getPermissions('manager'),
    'reception' => $userModel->getPermissions('reception'),
    'accountant' => $userModel->getPermissions('accountant'),
];
$rolePermissions['gestionnaire'] = $rolePermissions['manager'];
$rolePermissions['receptionniste'] = $rolePermissions['reception'];
$rolePermissions['comptable'] = $rolePermissions['accountant'];

$auditLogs = AuditLog::recent(100);

$financeService = new FinanceService();
$dashboardData = $financeService->getDashboard();

// Rendu du layout principal PHP
require __DIR__ . '/views/layouts/main.php';
