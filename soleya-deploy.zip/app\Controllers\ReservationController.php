<?php
// app/Controllers/ReservationController.php

namespace App\Controllers;

use App\Models\Reservation;
use App\Services\ReservationService;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Exception;

class ReservationController
{
    private Reservation $reservationModel;
    private ReservationService $reservationService;

    public function __construct()
    {
        $this->reservationModel = new Reservation();
        $this->reservationService = new ReservationService();
    }

    public function index(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $from = $params['from'] ?? null;
        $to = $params['to'] ?? null;
        $status = $params['status'] ?? null;

        $reservations = $this->reservationModel->allWithDetails($from, $to, $status);
        Response::success($reservations);
    }

    public function show(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $id = (int)($routeParams['id'] ?? 0);
        $res = $this->reservationModel->findWithDetails($id);
        if (!$res) {
            Response::error('Réservation introuvable.', 404);
        }

        Response::success($res);
    }

    public function store(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        try {
            $created = $this->reservationService->create($params, $user);
            Response::success($created, 'Réservation enregistrée avec succès.', 201);
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function checkin(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $id = (int)($routeParams['id'] ?? 0);
        try {
            $updated = $this->reservationService->checkin($id, $user);
            Response::success($updated, 'Check-in effectué avec succès.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function checkout(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $id = (int)($routeParams['id'] ?? 0);
        try {
            $updated = $this->reservationService->checkout($id, $user);
            Response::success($updated, 'Check-out enregistré. La chambre est désormais à nettoyer.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function extend(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $id = (int)($routeParams['id'] ?? 0);
        $newDeparture = $params['departure_date'] ?? '';

        if (empty($newDeparture)) {
            Response::error('Veuillez spécifier la nouvelle date de départ.', 422);
        }

        try {
            $updated = $this->reservationService->extend($id, $newDeparture, $user);
            Response::success($updated, 'Séjour prolongé avec succès.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }

    public function cancel(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('reservations');

        $id = (int)($routeParams['id'] ?? 0);
        try {
            $updated = $this->reservationService->cancel($id, $user);
            Response::success($updated, 'Réservation annulée.');
        } catch (Exception $e) {
            Response::error($e->getMessage(), 422);
        }
    }
}
