<?php
// app/Middleware/RoleMiddleware.php

namespace App\Middleware;

use App\Helpers\Response;
use App\Models\User;

class RoleMiddleware
{
    public static function checkPermission(string $module): void
    {
        $user = AuthMiddleware::check();

        if ($user['role'] === 'admin') {
            return; // L'administrateur conserve tous les droits
        }

        $userModel = new User();
        $perms = $userModel->getPermissions($user['role']);

        if (!in_array($module, $perms, true)) {
            Response::error("Accès refusé : vous n'avez pas la permission d'accéder au module '{$module}'.", 403);
        }
    }

    public static function requireAdmin(): void
    {
        $user = AuthMiddleware::check();
        if ($user['role'] !== 'admin') {
            Response::error('Action réservée exclusivement à l’administrateur.', 403);
        }
    }
}
