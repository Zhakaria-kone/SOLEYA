<?php
// app/Controllers/SettingController.php

namespace App\Controllers;

use App\Models\Model;
use App\Models\Building;
use App\Models\Room;
use App\Models\RoomType;
use App\Models\PaymentMethod;
use App\Models\FinancialAccount;
use App\Models\User;
use App\Models\AuditLog;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;
use Throwable;

class SettingController
{
    private Building $buildingModel;
    private Room $roomModel;
    private RoomType $roomTypeModel;
    private PaymentMethod $methodModel;
    private FinancialAccount $accountModel;
    private User $userModel;

    public function __construct()
    {
        $this->buildingModel = new Building();
        $this->roomModel = new Room();
        $this->roomTypeModel = new RoomType();
        $this->methodModel = new PaymentMethod();
        $this->accountModel = new FinancialAccount();
        $this->userModel = new User();
    }

    private function normalizeRole(string $role): string
    {
        $map = [
            'admin' => 'admin',
            'manager' => 'manager',
            'gestionnaire' => 'manager',
            'reception' => 'reception',
            'receptionniste' => 'reception',
            'accountant' => 'accountant',
            'comptable' => 'accountant'
        ];
        return $map[strtolower(trim($role))] ?? 'reception';
    }

    public function getSettings(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $building = $this->buildingModel->get();
        $rooms = $this->roomModel->allWithDetails();
        $roomTypes = $this->roomTypeModel->all('id ASC');
        $methods = $this->methodModel->all('id ASC');
        $accounts = $this->accountModel->allWithBalances();
        $users = User::query("SELECT id, name, email, role, is_active FROM `users` ORDER BY id ASC");

        $allModules = ['dashboard', 'rooms', 'reservations', 'clients', 'stays', 'payments', 'expenses', 'purchases', 'suppliers', 'invoices', 'reports', 'settings'];
        $rolePermissions = [
            'admin' => $allModules,
            'manager' => $this->userModel->getPermissions('manager'),
            'reception' => $this->userModel->getPermissions('reception'),
            'accountant' => $this->userModel->getPermissions('accountant'),
        ];
        $rolePermissions['gestionnaire'] = $rolePermissions['manager'];
        $rolePermissions['receptionniste'] = $rolePermissions['reception'];
        $rolePermissions['comptable'] = $rolePermissions['accountant'];

        Response::success([
            'building' => $building,
            'rooms' => $rooms,
            'room_types' => $roomTypes,
            'payment_methods' => $methods,
            'financial_accounts' => $accounts,
            'users' => $users,
            'role_permissions' => $rolePermissions,
            'audit_logs' => AuditLog::recent(100)
        ]);
    }

    public function updateBuilding(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $building = $this->buildingModel->get();

        $taxRate = array_key_exists('tax_rate', $params)
            ? (int)$params['tax_rate']
            : (array_key_exists('taxRate', $params) ? (int)$params['taxRate'] : (int)($building['tax_rate'] ?? 0));

        $data = [
            'name' => trim((string)($params['name'] ?? $building['name'] ?? 'Résidence Prestige')),
            'address' => trim((string)($params['address'] ?? $building['address'] ?? '')),
            'city' => trim((string)($params['city'] ?? $building['city'] ?? '')),
            'phone' => trim((string)($params['phone'] ?? $building['phone'] ?? '')),
            'email' => trim((string)($params['email'] ?? $building['email'] ?? '')),
            'description' => trim((string)($params['description'] ?? $building['description'] ?? '')),
            'manager' => trim((string)($params['manager'] ?? $building['manager'] ?? '')),
            'billing' => trim((string)($params['billing'] ?? $building['billing'] ?? '')),
            'tax_rate' => max(0, $taxRate),
            'terms' => trim((string)($params['terms'] ?? $building['terms'] ?? ''))
        ];

        if ($data['name'] === '') {
            Response::error('Le nom de la résidence est obligatoire.', 422);
        }

        $updated = $this->buildingModel->saveBuilding($data);

        AuditLog::log("Paramètres résidence", "Informations de l’établissement mises à jour ({$updated['name']})", $user['name']);

        Response::success($updated, 'Informations de l’établissement enregistrées.');
    }

    public function saveRoomType(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $id = !empty($params['id']) ? (int)$params['id'] : (!empty($routeParams['id']) ? (int)$routeParams['id'] : null);
        $name = trim((string)($params['name'] ?? ''));
        $daily = max(0, (int)($params['daily_rate'] ?? $params['daily'] ?? $params['base_price'] ?? 0));
        $weekly = max(0, (int)($params['weekly_rate'] ?? $params['weekly'] ?? ($daily * 6)));
        $monthly = max(0, (int)($params['monthly_rate'] ?? $params['monthly'] ?? ($daily * 20)));
        $capacity = max(1, (int)($params['capacity'] ?? 2));

        if ($name === '') {
            Response::error('Le nom du type de chambre est obligatoire.', 422);
        }

        $payload = [
            'name' => $name,
            'daily_rate' => $daily,
            'weekly_rate' => $weekly,
            'monthly_rate' => $monthly,
            'capacity' => $capacity
        ];

        if ($id) {
            $this->roomTypeModel->update($id, $payload);
            AuditLog::log("Modification catégorie", "Type {$name} mis à jour", $user['name']);
        } else {
            $id = $this->roomTypeModel->create($payload);
            AuditLog::log("Création catégorie", "Nouveau type de chambre {$name}", $user['name']);
        }

        Response::success($this->roomTypeModel->find($id), 'Catégorie enregistrée.');
    }

    public function deleteRoomType(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = (int)($routeParams['id'] ?? $params['id'] ?? 0);
        $rt = $this->roomTypeModel->find($id);
        if (!$rt) {
            Response::error('Type de chambre introuvable.', 404);
        }

        $used = Room::queryOne("SELECT id FROM `rooms` WHERE `type_id` = :id LIMIT 1", ['id' => $id]);
        if ($used) {
            Response::error('Impossible de supprimer ce type car des chambres y sont rattachées.', 422);
        }

        $this->roomTypeModel->delete($id);
        AuditLog::log("Suppression catégorie", "Type {$rt['name']} supprimé", $user['name']);

        Response::success(null, 'Catégorie supprimée.');
    }

    public function savePaymentMethod(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $id = !empty($params['id']) ? (int)$params['id'] : (!empty($routeParams['id']) ? (int)$routeParams['id'] : null);
        $name = trim((string)($params['name'] ?? ''));
        $active = isset($params['is_active']) ? (int)(bool)$params['is_active'] : (isset($params['active']) ? (int)(bool)$params['active'] : 1);

        if ($name === '') {
            Response::error('Nom du moyen de paiement obligatoire.', 422);
        }

        if ($id) {
            $this->methodModel->update($id, ['name' => $name, 'is_active' => $active]);
            AuditLog::log("Modification moyen de paiement", "Moyen {$name} mis à jour", $user['name']);
        } else {
            $id = $this->methodModel->create(['name' => $name, 'is_active' => $active]);
            AuditLog::log("Création moyen de paiement", "Nouveau moyen {$name}", $user['name']);
        }

        Response::success($this->methodModel->find($id), 'Moyen de paiement enregistré.');
    }

    public function saveFinancialAccount(array $routeParams, array $params): void
    {
        $user = AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $id = !empty($params['id']) ? (int)$params['id'] : (!empty($routeParams['id']) ? (int)$routeParams['id'] : null);
        $name = trim((string)($params['name'] ?? ''));
        $opening = (int)($params['opening_balance'] ?? $params['opening'] ?? $params['initial_balance'] ?? 0);
        $active = isset($params['is_active']) ? (int)(bool)$params['is_active'] : (isset($params['active']) ? (int)(bool)$params['active'] : 1);

        if ($name === '') {
            Response::error('Nom du compte obligatoire.', 422);
        }

        $payload = [
            'name' => $name,
            'opening_balance' => $opening,
            'is_active' => $active
        ];

        if ($id) {
            $this->accountModel->update($id, $payload);
            AuditLog::log("Modification compte", "Compte {$name} mis à jour", $user['name']);
        } else {
            $id = $this->accountModel->create($payload);
            AuditLog::log("Création compte", "Nouveau compte de trésorerie {$name}", $user['name']);
        }

        Response::success($this->accountModel->find($id), 'Compte financier enregistré.');
    }

    public function saveUser(array $routeParams, array $params): void
    {
        $admin = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = !empty($params['id']) ? (int)$params['id'] : (!empty($routeParams['id']) ? (int)$routeParams['id'] : null);
        $name = trim((string)($params['name'] ?? ''));
        $email = trim((string)($params['email'] ?? ''));
        $role = $this->normalizeRole((string)($params['role'] ?? 'reception'));
        $password = (string)($params['password'] ?? '');
        $active = isset($params['is_active']) ? (int)(bool)$params['is_active'] : (isset($params['active']) ? (int)(bool)$params['active'] : 1);

        if ($name === '' || $email === '') {
            Response::error('Nom et email obligatoires.', 422);
        }

        if ($id) {
            if ($id === 1 && !$active) {
                Response::error('Le compte propriétaire principal ne peut pas être désactivé.', 422);
            }
            $data = [
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'is_active' => $active
            ];
            if ($password !== '') {
                $data['password_hash'] = password_hash($password, PASSWORD_BCRYPT);
            }
            $this->userModel->update($id, $data);
            AuditLog::log("Modification utilisateur", "Mise à jour du compte {$name} ({$role})", $admin['name']);
        } else {
            if ($password === '') {
                Response::error('Mot de passe requis pour un nouvel utilisateur.', 422);
            }
            $dup = $this->userModel->findByEmail($email);
            if ($dup) {
                Response::error('Cet email est déjà utilisé par un autre utilisateur.', 422);
            }
            $id = $this->userModel->create([
                'name' => $name,
                'email' => $email,
                'password_hash' => password_hash($password, PASSWORD_BCRYPT),
                'role' => $role,
                'is_active' => $active
            ]);
            AuditLog::log("Création utilisateur", "Nouvel utilisateur {$name} ({$role})", $admin['name']);
        }

        $res = User::queryOne("SELECT id, name, email, role, is_active FROM `users` WHERE `id` = :id", ['id' => $id]);
        Response::success($res, 'Utilisateur enregistré.');
    }

    public function deleteUser(array $routeParams, array $params): void
    {
        $admin = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $id = (int)($routeParams['id'] ?? $params['id'] ?? 0);
        if ($id === 1 || $id === (int)$admin['id']) {
            Response::error('Impossible de supprimer ce compte utilisateur.', 422);
        }

        $u = $this->userModel->find($id);
        if (!$u) {
            Response::error('Utilisateur introuvable.', 404);
        }

        $this->userModel->delete($id);
        AuditLog::log("Suppression utilisateur", "Compte {$u['name']} supprimé", $admin['name']);

        Response::success(null, 'Utilisateur supprimé.');
    }

    public function savePermissions(array $routeParams, array $params): void
    {
        $admin = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $rawRole = (string)($params['role'] ?? '');
        $role = $this->normalizeRole($rawRole);
        $modules = $params['modules'] ?? [];

        if (!in_array($role, ['manager', 'reception', 'accountant'], true)) {
            Response::error('Rôle non modifiable.', 422);
        }

        $this->userModel->setPermissions($role, (array)$modules);
        AuditLog::log("Mise à jour permissions", "Permissions modifiées pour le rôle {$role}", $admin['name']);

        Response::success(['role' => $role, 'modules' => $modules], 'Permissions mises à jour.');
    }

    public function getAuditLogs(array $routeParams, array $params): void
    {
        AuthMiddleware::check();
        RoleMiddleware::checkPermission('settings');

        $limit = min(200, max(10, (int)($params['limit'] ?? 50)));
        $logs = AuditLog::recent($limit);

        Response::success($logs);
    }

    /**
     * Réinitialise toutes les données de démonstration dans une transaction SQL atomique,
     * tout en conservant les paramètres de la résidence, la configuration des chambres,
     * les comptes utilisateurs, les rôles et les configurations essentielles.
     */
    public function resetDemoData(array $routeParams, array $params): void
    {
        $admin = AuthMiddleware::check();
        RoleMiddleware::requireAdmin();

        $confirmation = trim((string)($params['confirmation'] ?? ''));
        $confirmCheck = !empty($params['confirm_check']);

        if ($confirmation !== 'REINITIALISER' || !$confirmCheck) {
            Response::error('Confirmation de sécurité requise : veuillez cocher la case de confirmation et saisir exactement REINITIALISER.', 422);
        }

        try {
            Model::beginTransaction();

            // Comptage préalable pour le rapport de réinitialisation
            $counts = [
                'reservations' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `reservations`")['c'] ?? 0),
                'clients' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `clients`")['c'] ?? 0),
                'payments' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `payments`")['c'] ?? 0),
                'invoices' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `invoices`")['c'] ?? 0),
                'expenses' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `expenses`")['c'] ?? 0),
                'purchases' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `purchases`")['c'] ?? 0),
                'suppliers' => (int)(Model::queryOne("SELECT COUNT(*) AS c FROM `suppliers`")['c'] ?? 0),
            ];

            // 1. Suppression des encaissements et remboursements fictifs
            Model::execute("DELETE FROM `payments`");

            // 2. Suppression des lignes de factures et des factures
            Model::execute("DELETE FROM `invoice_items`");
            Model::execute("DELETE FROM `invoices`");

            // 3. Suppression des réservations et séjours
            Model::execute("DELETE FROM `reservations`");

            // 4. Suppression des dépenses d'exploitation
            Model::execute("DELETE FROM `expenses`");

            // 5. Suppression des règlements fournisseurs, lignes d'achats, achats et fournisseurs de démo
            Model::execute("DELETE FROM `supplier_payments`");
            Model::execute("DELETE FROM `purchase_items`");
            Model::execute("DELETE FROM `purchases`");
            Model::execute("DELETE FROM `suppliers`");

            // 6. Suppression des clients de démonstration
            Model::execute("DELETE FROM `clients`");

            // 7. Remise à l'état LIBRE de toutes les chambres (sans supprimer les chambres ni leur configuration)
            Model::execute("UPDATE `rooms` SET `status` = 'LIBRE'");

            // 8. Remise à zéro des soldes initiaux fictifs des comptes financiers (en conservant les comptes)
            Model::execute("UPDATE `financial_accounts` SET `opening_balance` = 0");

            // 9. Nettoyage de l'historique d'audit de démonstration et journalisation de la réinitialisation
            Model::execute("DELETE FROM `audit_logs`");
            AuditLog::log(
                "Réinitialisation des données de démonstration",
                sprintf(
                    "Remise à zéro effectuée (%d réservations, %d clients, %d paiements, %d factures, %d dépenses, %d achats supprimés). Configuration et chambres conservées.",
                    $counts['reservations'],
                    $counts['clients'],
                    $counts['payments'],
                    $counts['invoices'],
                    $counts['expenses'],
                    $counts['purchases']
                ),
                $admin['name']
            );

            Model::commit();

            $roomModel = new Room();
            Response::success([
                'deleted_counts' => $counts,
                'building' => $this->buildingModel->get(),
                'rooms' => $roomModel->allWithDetails(),
                'financial_accounts' => $this->accountModel->allWithBalances(),
                'audit_logs' => AuditLog::recent(50)
            ], 'Toutes les données de démonstration ont été supprimées avec succès.');
        } catch (Throwable $e) {
            try {
                Model::rollBack();
            } catch (Throwable $rollbackErr) {
            }
            Response::error('Erreur lors de la réinitialisation des données : ' . $e->getMessage(), 500);
        }
    }
}
