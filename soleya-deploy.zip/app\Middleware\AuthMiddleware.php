<?php
// app/Middleware/AuthMiddleware.php

namespace App\Middleware;

use App\Helpers\Response;

class AuthMiddleware
{
    public static function check(): array
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (empty($_SESSION['user']) || empty($_SESSION['user']['id'])) {
            Response::error('Non authentifié. Veuillez vous connecter.', 401);
        }

        return $_SESSION['user'];
    }
}
