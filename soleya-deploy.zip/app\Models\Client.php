<?php
// app/Models/Client.php

namespace App\Models;

class Client extends Model
{
    protected string $table = 'clients';

    public function allWithStats(): array
    {
        $sql = "
            SELECT 
                c.*,
                COUNT(DISTINCT r.id) AS stays_count,
                COALESCE(SUM(DISTINCT CASE WHEN r.status NOT IN ('ANNULEE', 'NO_SHOW') THEN r.total_amount ELSE 0 END), 0) AS total_billed,
                COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.client_id = c.id), 0) AS total_paid
            FROM `clients` c
            LEFT JOIN `reservations` r ON c.id = r.client_id
            GROUP BY c.id
            ORDER BY c.id DESC
        ";
        $clients = self::query($sql);
        foreach ($clients as &$client) {
            $client['balance_due'] = max(0, (int)$client['total_billed'] - (int)$client['total_paid']);
            $client['full_name'] = $client['first_name'] . ' ' . $client['last_name'];
        }
        return $clients;
    }

    public function findWithHistory(int $id): ?array
    {
        $client = $this->find($id);
        if (!$client) return null;

        $client['full_name'] = $client['first_name'] . ' ' . $client['last_name'];

        // Réservations
        $sqlRes = "
            SELECT r.*, rm.number AS room_name,
                   COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.reservation_id = r.id), 0) AS paid_amount
            FROM `reservations` r
            INNER JOIN `rooms` rm ON r.room_id = rm.id
            WHERE r.client_id = :id
            ORDER BY r.arrival_date DESC
        ";
        $client['reservations'] = self::query($sqlRes, ['id' => $id]);

        // Paiements
        $sqlPay = "
            SELECT p.*, m.name AS method_name, a.name AS account_name
            FROM `payments` p
            LEFT JOIN `payment_methods` m ON p.payment_method_id = m.id
            LEFT JOIN `financial_accounts` a ON p.financial_account_id = a.id
            WHERE p.client_id = :id
            ORDER BY p.payment_date DESC, p.id DESC
        ";
        $client['payments'] = self::query($sqlPay, ['id' => $id]);

        // Factures
        $sqlInv = "
            SELECT i.*,
                   COALESCE((SELECT SUM(p.amount) FROM `payments` p WHERE p.invoice_id = i.id), 0) AS paid_amount
            FROM `invoices` i
            WHERE i.client_id = :id
            ORDER BY i.issue_date DESC
        ";
        $client['invoices'] = self::query($sqlInv, ['id' => $id]);

        // Calcul du solde global
        $totalBilled = 0;
        foreach ($client['reservations'] as $r) {
            if (!in_array($r['status'], ['ANNULEE', 'NO_SHOW'])) {
                $totalBilled += (int)$r['total_amount'];
            }
        }
        $totalPaid = 0;
        foreach ($client['payments'] as $p) {
            $totalPaid += (int)$p['amount'];
        }
        $client['total_billed'] = $totalBilled;
        $client['total_paid'] = $totalPaid;
        $client['balance_due'] = max(0, $totalBilled - $totalPaid);

        return $client;
    }

    public function findDuplicatePhone(string $phone, ?int $exceptId = null): ?array
    {
        $cleanPhone = preg_replace('/\s+/', '', $phone);
        $sql = "SELECT id, first_name, last_name, phone FROM `clients` WHERE REPLACE(phone, ' ', '') = :phone";
        $params = ['phone' => $cleanPhone];
        if ($exceptId !== null) {
            $sql .= " AND id != :except_id";
            $params['except_id'] = $exceptId;
        }
        $sql .= " LIMIT 1";
        return self::queryOne($sql, $params);
    }
}
